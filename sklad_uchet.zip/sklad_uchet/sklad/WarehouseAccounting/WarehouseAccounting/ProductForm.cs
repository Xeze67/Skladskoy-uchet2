﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace WarehouseAccounting
{
    /// <summary>Диалог добавления и изменения товара.</summary>
    internal sealed class ProductForm : Form
    {
        private readonly TextBox txtSku = new TextBox();
        private readonly TextBox txtTitle = new TextBox();
        private readonly ComboBox cmbCategory = new ComboBox();
        private readonly ComboBox cmbUnit = new ComboBox();
        private readonly NumericUpDown numPrice = new NumericUpDown();
        private readonly NumericUpDown numMin = new NumericUpDown();
        private readonly NumericUpDown numInitial = new NumericUpDown();
        private readonly Button btnOk = new Button();
        private readonly Button btnCancel = new Button();

        private readonly ProductData existing;

        /// <summary>Заполненные данные товара (после нажатия «Сохранить»).</summary>
        public ProductData Result { get; private set; }

        /// <summary>Начальный остаток (только для нового товара); если больше нуля — создаётся приход.</summary>
        public int InitialQty { get; private set; }

        public ProductForm(ProductData existingProduct)
        {
            existing = existingProduct;
            bool isNew = existing == null;

            Text = isNew ? "Новый товар" : "Изменение товара";
            Font = new Font("Segoe UI", 9.5f);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterParent;
            ClientSize = new Size(560, 480);

            var tt = new ToolTip { AutoPopDelay = 10000, InitialDelay = 200, IsBalloon = true, ToolTipTitle = "Подсказка" };

            int y = 16;
            AddRow("Артикул (код товара) *", txtSku, ref y);
            txtSku.MaxLength = 30;
            tt.SetToolTip(txtSku, "Уникальный артикул, шифр или штрихкод товара (например: EL-1001, ФАЙРИ-01, 46012345).");

            AddRow("Наименование товара *", txtTitle, ref y);
            txtTitle.MaxLength = 150;
            tt.SetToolTip(txtTitle, "Полное торговое наименование товара (например: Моющее средство Fairy Лимон 500 мл).");

            cmbCategory.DropDownStyle = ComboBoxStyle.DropDownList;
            AddRow("Категория товара", cmbCategory, ref y);
            tt.SetToolTip(cmbCategory, "Раздел или группа товаров. Новые категории можно создавать через меню «Категории».");

            cmbUnit.DropDownStyle = ComboBoxStyle.DropDown;
            cmbUnit.MaxLength = 15;
            cmbUnit.Items.AddRange(new object[] { "шт", "уп", "кг", "л", "м", "коробка", "рулон", "канистра" });
            AddRow("Единица измерения *", cmbUnit, ref y);
            tt.SetToolTip(cmbUnit, "В чём измеряется товар на складе: штуки, упаковки, литры, килограммы и т.д.");

            numPrice.DecimalPlaces = 2;
            numPrice.Maximum = 10000000;
            numPrice.Minimum = 0;
            AddRow("Цена за единицу, руб.", numPrice, ref y);
            tt.SetToolTip(numPrice, "Отпускная или учётная цена за 1 единицу товара в рублях.");

            numMin.Maximum = 1000000;
            numMin.Minimum = 0;
            AddRow("Минимальный остаток (лимит)", numMin, ref y);
            tt.SetToolTip(numMin, "Порог минимального запаса: если товара останется меньше или ровно столько, он подсветится красным и попадёт в отчёт на закупку.");

            if (isNew)
            {
                numInitial.Maximum = 1000000;
                numInitial.Minimum = 0;
                AddRow("Начальный остаток на складе", numInitial, ref y);
                tt.SetToolTip(numInitial, "Сколько единиц этого товара уже физически лежит на складе прямо сейчас. Программа автоматически создаст начальный приход.");
            }

            // Понятная панель с подсказками
            var pnlHelp = new Panel
            {
                Left = 15,
                Top = y + 10,
                Width = 525,
                Height = 88,
                BackColor = Color.FromArgb(243, 246, 252),
                BorderStyle = BorderStyle.FixedSingle
            };
            var lblHelp = new Label
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(10, 8, 10, 8),
                Font = new Font("Segoe UI", 9f),
                ForeColor = Color.FromArgb(30, 50, 80),
                Text = "💡 Подсказка по заполнению полей:\n" +
                       "• Артикул — уникальный шифр или код товара (например: ФАЙРИ-500, EL-1001).\n" +
                       "• Мин. остаток — порог: если останется меньше, товар подсветится красным.\n" +
                       "• Начальный остаток — сколько товара уже на складе (будет оформлен приход)."
            };
            pnlHelp.Controls.Add(lblHelp);
            Controls.Add(pnlHelp);

            btnOk.Text = "Сохранить в базу";
            btnOk.Font = new Font(Font, FontStyle.Bold);
            btnOk.SetBounds(270, y + 110, 155, 34);
            btnOk.Click += OnOk;

            btnCancel.Text = "Отмена";
            btnCancel.SetBounds(435, y + 110, 105, 34);
            btnCancel.DialogResult = DialogResult.Cancel;

            Controls.Add(btnOk);
            Controls.Add(btnCancel);
            AcceptButton = btnOk;
            CancelButton = btnCancel;
            ClientSize = new Size(560, y + 160);

            cmbCategory.Items.Add(new Category(0, "(без категории)"));
            foreach (Category c in Db.GetCategories()) cmbCategory.Items.Add(c);
            cmbCategory.SelectedIndex = 0;
            cmbUnit.Text = "шт";

            if (!isNew) Fill();
        }

        private void AddRow(string caption, Control editor, ref int y)
        {
            Label lbl = new Label { Text = caption, Left = 15, Top = y + 4, Width = 215, TextAlign = ContentAlignment.MiddleLeft };
            editor.SetBounds(235, y, 305, 26);
            Controls.Add(lbl);
            Controls.Add(editor);
            y += 38;
        }

        private void Fill()
        {
            txtSku.Text = existing.Sku;
            txtTitle.Text = existing.Title;
            cmbUnit.Text = existing.UnitName;
            numPrice.Value = existing.Price;
            numMin.Value = existing.MinStock;

            for (int i = 0; i < cmbCategory.Items.Count; i++)
            {
                Category c = (Category)cmbCategory.Items[i];
                if ((existing.CategoryId.HasValue && c.Id == existing.CategoryId.Value) ||
                    (!existing.CategoryId.HasValue && c.Id == 0))
                {
                    cmbCategory.SelectedIndex = i;
                    break;
                }
            }
        }

        private void OnOk(object sender, EventArgs e)
        {
            string sku = txtSku.Text.Trim();
            string title = txtTitle.Text.Trim();
            string unit = cmbUnit.Text.Trim();

            if (sku.Length == 0 || title.Length == 0 || unit.Length == 0)
            {
                MessageBox.Show(this, "Заполните обязательные поля: артикул, название и единицу измерения.",
                    Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                int exceptId = existing == null ? 0 : existing.Id;
                if (Db.SkuExists(sku, exceptId))
                {
                    MessageBox.Show(this, "Товар с таким артикулом уже существует.",
                        Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка при работе с базой данных:\n" + ex.Message,
                    Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            Category selected = (Category)cmbCategory.SelectedItem;
            Result = new ProductData
            {
                Id = existing == null ? 0 : existing.Id,
                Sku = sku,
                Title = title,
                UnitName = unit,
                CategoryId = selected.Id == 0 ? (int?)null : selected.Id,
                Price = numPrice.Value,
                MinStock = (int)numMin.Value,
                Quantity = existing == null ? 0 : existing.Quantity
            };
            InitialQty = existing == null ? (int)numInitial.Value : 0;
            DialogResult = DialogResult.OK;
        }
    }
}
