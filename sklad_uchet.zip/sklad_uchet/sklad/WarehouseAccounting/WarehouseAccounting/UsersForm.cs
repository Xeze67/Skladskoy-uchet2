using System;
using System.Collections.Generic;
using System.Drawing;
using System.Windows.Forms;

namespace WarehouseAccounting
{
    /// <summary>
    /// Окно управления пользователями системы (доступно только Администратору).
    /// Позволяет просматривать список, добавлять сотрудников, менять роли, сбрасывать пароли и удалять учетные записи.
    /// </summary>
    internal sealed class UsersForm : Form
    {
        private readonly UserRecord currentUser;
        private readonly DataGridView grid = new DataGridView();
        private readonly Button btnAdd = new Button();
        private readonly Button btnToggleRole = new Button();
        private readonly Button btnResetPass = new Button();
        private readonly Button btnDelete = new Button();
        private readonly Button btnClose = new Button();

        public UsersForm(UserRecord adminUser)
        {
            currentUser = adminUser;

            Text = "Управление пользователями системы";
            Font = new Font("Segoe UI", 9.5f);
            MinimumSize = new Size(620, 420);
            Size = new Size(650, 450);
            StartPosition = FormStartPosition.CenterParent;
            ShowInTaskbar = false;

            var panelTop = new Panel { Dock = DockStyle.Top, Height = 48, Padding = new Padding(10, 8, 10, 8) };
            btnAdd.Text = "Добавить пользователя";
            btnAdd.SetBounds(10, 8, 170, 32);
            btnAdd.Click += OnAddUser;

            btnToggleRole.Text = "Сменить роль";
            btnToggleRole.SetBounds(190, 8, 130, 32);
            btnToggleRole.Click += OnToggleRole;

            btnResetPass.Text = "Сменить пароль";
            btnResetPass.SetBounds(330, 8, 140, 32);
            btnResetPass.Click += OnResetPassword;

            btnDelete.Text = "Удалить";
            btnDelete.SetBounds(480, 8, 100, 32);
            btnDelete.Click += OnDeleteUser;

            panelTop.Controls.AddRange(new Control[] { btnAdd, btnToggleRole, btnResetPass, btnDelete });

            var panelBottom = new Panel { Dock = DockStyle.Bottom, Height = 48, Padding = new Padding(10, 8, 10, 8) };
            var lblHint = new Label
            {
                Text = "* Нельзя удалить собственную учётную запись или последнего администратора.",
                AutoSize = true,
                ForeColor = Color.DimGray,
                Left = 10,
                Top = 15
            };
            btnClose.Text = "Закрыть";
            btnClose.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnClose.SetBounds(panelBottom.Width - 110, 8, 100, 32);
            btnClose.DialogResult = DialogResult.OK;
            panelBottom.Controls.AddRange(new Control[] { lblHint, btnClose });

            grid.Dock = DockStyle.Fill;
            grid.ReadOnly = true;
            grid.AllowUserToAddRows = false;
            grid.AllowUserToDeleteRows = false;
            grid.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            grid.MultiSelect = false;
            grid.RowHeadersVisible = false;
            grid.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            grid.BackgroundColor = Color.White;

            Controls.Add(grid);
            Controls.Add(panelTop);
            Controls.Add(panelBottom);

            CancelButton = btnClose;

            Reload();
        }

        private void Reload()
        {
            var list = Db.GetAllUsers();
            grid.Columns.Clear();
            grid.Columns.Add("Id", "ID");
            grid.Columns.Add("Name", "Логин / Имя пользователя");
            grid.Columns.Add("Role", "Роль в системе");

            grid.Columns["Id"].Width = 60;
            grid.Columns["Role"].Width = 140;

            foreach (var u in list)
            {
                int rowIdx = grid.Rows.Add(u.Id, u.Name, u.Role);
                if (u.Id == currentUser.Id)
                {
                    grid.Rows[rowIdx].DefaultCellStyle.Font = new Font(grid.Font, FontStyle.Bold);
                }
            }
        }

        private UserRecord GetSelectedUser()
        {
            if (grid.CurrentRow == null) return null;
            int id = Convert.ToInt32(grid.CurrentRow.Cells["Id"].Value);
            string name = Convert.ToString(grid.CurrentRow.Cells["Name"].Value);
            string role = Convert.ToString(grid.CurrentRow.Cells["Role"].Value);
            return new UserRecord { Id = id, Name = name, Role = role };
        }

        private void OnAddUser(object sender, EventArgs e)
        {
            using (var dlg = new Form())
            {
                dlg.Text = "Новый пользователь";
                dlg.Font = Font;
                dlg.FormBorderStyle = FormBorderStyle.FixedDialog;
                dlg.MaximizeBox = false;
                dlg.MinimizeBox = false;
                dlg.StartPosition = FormStartPosition.CenterParent;
                dlg.ClientSize = new Size(360, 240);

                var lbl1 = new Label { Text = "Логин (имя пользователя):", Left = 15, Top = 15, Width = 330 };
                var txtName = new TextBox { Left = 15, Top = 38, Width = 330, MaxLength = 50 };

                var lbl2 = new Label { Text = "Пароль (от 6 символов):", Left = 15, Top = 70, Width = 330 };
                var txtPass = new TextBox { Left = 15, Top = 93, Width = 330, UseSystemPasswordChar = true };

                var lbl3 = new Label { Text = "Роль:", Left = 15, Top = 125, Width = 330 };
                var cmbRole = new ComboBox { Left = 15, Top = 148, Width = 330, DropDownStyle = ComboBoxStyle.DropDownList };
                cmbRole.Items.AddRange(new object[] { Roles.Keeper, Roles.Admin });
                cmbRole.SelectedIndex = 0;

                var btnOk = new Button { Text = "Создать", Left = 150, Top = 190, Width = 95, Height = 32 };
                var btnCancel = new Button { Text = "Отмена", Left = 250, Top = 190, Width = 95, Height = 32, DialogResult = DialogResult.Cancel };

                btnOk.Click += delegate
                {
                    string name = txtName.Text.Trim();
                    string pass = txtPass.Text;

                    if (name.Length < 3)
                    {
                        MessageBox.Show(dlg, "Имя пользователя должно быть не менее 3 символов.", dlg.Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    if (pass.Length < 6)
                    {
                        MessageBox.Show(dlg, "Пароль должен быть не менее 6 символов.", dlg.Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    if (Db.GetUser(name) != null)
                    {
                        MessageBox.Show(dlg, "Пользователь с таким именем уже существует.", dlg.Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    try
                    {
                        Db.CreateUser(name, CryptoHelper.HashPassword(pass), cmbRole.SelectedItem.ToString());
                        dlg.DialogResult = DialogResult.OK;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(dlg, "Ошибка создания пользователя:\n" + ex.Message, dlg.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                };

                dlg.Controls.AddRange(new Control[] { lbl1, txtName, lbl2, txtPass, lbl3, cmbRole, btnOk, btnCancel });
                dlg.AcceptButton = btnOk;
                dlg.CancelButton = btnCancel;

                if (dlg.ShowDialog(this) == DialogResult.OK)
                {
                    Reload();
                }
            }
        }

        private void OnToggleRole(object sender, EventArgs e)
        {
            var u = GetSelectedUser();
            if (u == null) return;

            if (u.Id == currentUser.Id)
            {
                MessageBox.Show(this, "Вы не можете изменить роль собственной учётной записи.", Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            string newRole = u.Role == Roles.Admin ? Roles.Keeper : Roles.Admin;
            string msg = $"Изменить роль пользователя «{u.Name}» на «{newRole}»?";
            if (MessageBox.Show(this, msg, Text, MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;

            try
            {
                Db.UpdateUserRole(u.Id, newRole);
                Reload();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка:\n" + ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void OnResetPassword(object sender, EventArgs e)
        {
            var u = GetSelectedUser();
            if (u == null) return;

            using (var dlg = new Form())
            {
                dlg.Text = $"Смена пароля: {u.Name}";
                dlg.Font = Font;
                dlg.FormBorderStyle = FormBorderStyle.FixedDialog;
                dlg.MaximizeBox = false;
                dlg.MinimizeBox = false;
                dlg.StartPosition = FormStartPosition.CenterParent;
                dlg.ClientSize = new Size(340, 180);

                var lbl = new Label { Text = "Новый пароль (от 6 символов):", Left = 15, Top = 15, Width = 310 };
                var txt = new TextBox { Left = 15, Top = 40, Width = 310, UseSystemPasswordChar = true };

                var lbl2 = new Label { Text = "Повтор пароля:", Left = 15, Top = 72, Width = 310 };
                var txt2 = new TextBox { Left = 15, Top = 97, Width = 310, UseSystemPasswordChar = true };

                var btnOk = new Button { Text = "Сохранить", Left = 130, Top = 135, Width = 95, Height = 32 };
                var btnCancel = new Button { Text = "Отмена", Left = 230, Top = 135, Width = 95, Height = 32, DialogResult = DialogResult.Cancel };

                btnOk.Click += delegate
                {
                    if (txt.Text.Length < 6)
                    {
                        MessageBox.Show(dlg, "Пароль должен быть не менее 6 символов.", dlg.Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }
                    if (txt.Text != txt2.Text)
                    {
                        MessageBox.Show(dlg, "Пароли не совпадают.", dlg.Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        return;
                    }

                    try
                    {
                        Db.UpdateUserPassword(u.Id, CryptoHelper.HashPassword(txt.Text));
                        MessageBox.Show(dlg, "Пароль успешно изменён.", dlg.Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                        dlg.DialogResult = DialogResult.OK;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(dlg, "Ошибка сохранения пароля:\n" + ex.Message, dlg.Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                };

                dlg.Controls.AddRange(new Control[] { lbl, txt, lbl2, txt2, btnOk, btnCancel });
                dlg.AcceptButton = btnOk;
                dlg.CancelButton = btnCancel;

                dlg.ShowDialog(this);
            }
        }

        private void OnDeleteUser(object sender, EventArgs e)
        {
            var u = GetSelectedUser();
            if (u == null) return;

            if (u.Id == currentUser.Id)
            {
                MessageBox.Show(this, "Нельзя удалить самого себя.", Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Проверяем, не последний ли это администратор
            if (u.Role == Roles.Admin)
            {
                int adminCount = 0;
                foreach (var user in Db.GetAllUsers())
                {
                    if (user.Role == Roles.Admin) adminCount++;
                }
                if (adminCount <= 1)
                {
                    MessageBox.Show(this, "Нельзя удалить единственного администратора системы.", Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }
            }

            string msg = $"Вы действительно хотите удалить пользователя «{u.Name}» ({u.Role})?";
            if (MessageBox.Show(this, msg, Text, MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;

            try
            {
                Db.DeleteUser(u.Id);
                Reload();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Не удалось удалить пользователя (возможно, по нему есть записанные движения склада):\n" + ex.Message,
                    Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
