using System;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WarehouseAccounting
{
    /// <summary>
    /// Главное окно системы: вкладки «Товары», «Журнал движений», «Отчёт по складу».
    /// Поддерживает прямое редактирование товаров и сохранение изменений напрямую в базу данных Access.
    /// </summary>
    internal sealed class MainForm : Form
    {
        private readonly UserRecord user;

        private readonly ToolStrip toolStrip = new ToolStrip();
        private readonly StatusStrip statusStrip = new StatusStrip();
        private readonly ToolStripStatusLabel statusUser = new ToolStripStatusLabel();
        private readonly ToolStripStatusLabel statusSummary = new ToolStripStatusLabel();
        private readonly ToolStripStatusLabel statusDb = new ToolStripStatusLabel();
        private readonly TabControl tabs = new TabControl();

        // Кнопка сохранения в ToolStrip
        private ToolStripButton btnSave;

        // Вкладка «Товары»
        private readonly DataGridView gridProducts = new DataGridView();
        private readonly TextBox txtSearch = new TextBox();
        private readonly ComboBox cmbCategory = new ComboBox();
        private readonly CheckBox chkLow = new CheckBox();
        private readonly Button btnSaveInline = new Button();
        private readonly ContextMenuStrip ctxProducts = new ContextMenuStrip();
        private DataTable productsTable;
        private bool hasUnsavedChanges;

        // Вкладка «Журнал»
        private readonly DataGridView gridMoves = new DataGridView();
        private readonly DateTimePicker dtFrom = new DateTimePicker();
        private readonly DateTimePicker dtTo = new DateTimePicker();
        private readonly ComboBox cmbMoveType = new ComboBox();
        private readonly Button btnFilterToday = new Button();
        private readonly Button btnFilterWeek = new Button();
        private readonly Button btnFilterMonth = new Button();
        private readonly Button btnFilterAll = new Button();
        private int? filterProductId = null;
        private readonly Label lblFilterProductInfo = new Label();

        // Вкладка «Отчёт»
        private readonly TextBox txtReport = new TextBox();
        private readonly DateTimePicker dtRepFrom = new DateTimePicker();
        private readonly DateTimePicker dtRepTo = new DateTimePicker();
        private readonly Button btnCopyReport = new Button();
        private readonly Button btnSaveReport = new Button();

        private bool loading = true;

        public bool LogoutRequested { get; private set; }

        public MainForm(UserRecord currentUser)
        {
            user = currentUser;

            Text = $"Складской учёт (Microsoft Access) — [{Db.ActiveDbPath}]";
            Font = new Font("Segoe UI", 9.5f);
            MinimumSize = new Size(1000, 620);
            Size = new Size(1180, 720);
            StartPosition = FormStartPosition.CenterScreen;
            KeyPreview = true;

            BuildTabs();
            BuildToolStrip();
            BuildStatusStrip();
            BuildContextMenu();

            Controls.Add(tabs);
            Controls.Add(toolStrip);
            Controls.Add(statusStrip);

            LoadCategoryFilter();
            loading = false;

            RefreshProducts();
            RefreshMoves();
            RefreshReport();
        }

        // ───────────── Интерфейс ─────────────

        private void BuildToolStrip()
        {
            toolStrip.Dock = DockStyle.Top;
            toolStrip.GripStyle = ToolStripGripStyle.Hidden;
            toolStrip.Padding = new Padding(8, 6, 8, 6);
            toolStrip.Font = new Font("Segoe UI", 9.5f);

            toolStrip.Items.Add(MakeButton("Новый товар (Ctrl+N)", delegate { AddProduct(); }));
            toolStrip.Items.Add(MakeButton("Изменить", delegate { EditProduct(); }));
            ToolStripButton del = MakeButton("Удалить", delegate { DeleteProduct(); });
            del.Enabled = user.IsAdmin;
            toolStrip.Items.Add(del);

            toolStrip.Items.Add(new ToolStripSeparator());

            // Кнопка быстрого сохранения изменений
            btnSave = new ToolStripButton("💾 Сохранить изменения (Ctrl+S)", null, delegate { SaveChanges(); });
            btnSave.DisplayStyle = ToolStripItemDisplayStyle.Text;
            btnSave.Font = new Font(toolStrip.Font, FontStyle.Bold);
            btnSave.ForeColor = Color.FromArgb(16, 124, 65);
            btnSave.ToolTipText = "Сохранить все изменения сразу в базу данных Microsoft Access (Ctrl+S)";
            toolStrip.Items.Add(btnSave);

            toolStrip.Items.Add(new ToolStripSeparator());
            toolStrip.Items.Add(MakeButton("Приход (+) (Ctrl+I)", delegate { RegisterMovement(true); }));
            toolStrip.Items.Add(MakeButton("Расход (-) (Ctrl+O)", delegate { RegisterMovement(false); }));

            toolStrip.Items.Add(new ToolStripSeparator());
            toolStrip.Items.Add(MakeButton("Категории", delegate { OpenCategories(); }));

            if (user.IsAdmin)
            {
                toolStrip.Items.Add(MakeButton("Пользователи", delegate { OpenUsers(); }));
            }

            toolStrip.Items.Add(MakeButton("База данных...", delegate { OpenDbInfo(); }));
            toolStrip.Items.Add(MakeButton("📂 Папка с БД", delegate { OpenDbFolder(); }));
            toolStrip.Items.Add(new ToolStripSeparator());
            toolStrip.Items.Add(MakeButton("Экспорт в Excel/CSV", delegate { ExportCurrent(); }));

            toolStrip.Items.Add(new ToolStripSeparator());
            var btnLogout = MakeButton("Сменить пользователя", delegate
            {
                LogoutRequested = true;
                Close();
            });
            btnLogout.Alignment = ToolStripItemAlignment.Right;
            toolStrip.Items.Add(btnLogout);
        }

        private void OpenDbFolder()
        {
            try
            {
                string p = Db.ActiveDbPath;
                if (!string.IsNullOrEmpty(p) && File.Exists(p))
                {
                    Process.Start("explorer.exe", $"/select,\"{p}\"");
                }
                else
                {
                    Process.Start("explorer.exe", Db.BaseDirectory);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Не удалось открыть проводник:\n" + ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private static ToolStripButton MakeButton(string text, EventHandler handler)
        {
            var b = new ToolStripButton(text);
            b.DisplayStyle = ToolStripItemDisplayStyle.Text;
            b.Click += handler;
            return b;
        }

        private void BuildStatusStrip()
        {
            statusStrip.Dock = DockStyle.Bottom;
            statusStrip.Font = new Font("Segoe UI", 9f);

            statusUser.Text = $"Сотрудник: {user.Name} ({user.Role})";
            statusUser.BorderSides = ToolStripStatusLabelBorderSides.Right;

            statusSummary.Spring = true;
            statusSummary.TextAlign = ContentAlignment.MiddleLeft;
            statusSummary.Text = "Готово";

            string prov = Db.ActiveProvider ?? "OLEDB";
            string arch = Environment.Is64BitProcess ? "x64" : "x86";
            statusDb.Text = $"📂 БД: {Db.ActiveDbPath} [{prov} {arch}]";
            statusDb.ToolTipText = "Кликните, чтобы показать файл базы данных в Проводнике Windows";
            statusDb.IsLink = true;
            statusDb.Click += delegate { OpenDbFolder(); };

            statusStrip.Items.AddRange(new ToolStripItem[] { statusUser, statusSummary, statusDb });
        }

        private void BuildContextMenu()
        {
            var mSave = new ToolStripMenuItem("💾 Сохранить изменения в БД (Ctrl+S)", null, delegate { SaveChanges(); });
            mSave.Font = new Font(Font, FontStyle.Bold);
            mSave.ForeColor = Color.FromArgb(16, 124, 65);

            var mEdit = new ToolStripMenuItem("Изменить карточку товара...", null, delegate { EditProduct(); });
            var mIn = new ToolStripMenuItem("Оприходовать товар (+)...", null, delegate { RegisterMovement(true); });
            var mOut = new ToolStripMenuItem("Списать товар (-)...", null, delegate { RegisterMovement(false); });
            var mHistory = new ToolStripMenuItem("История движений по товару", null, delegate { FilterBySelectedProduct(); });
            var mDel = new ToolStripMenuItem("Удалить товар", null, delegate { DeleteProduct(); }) { Enabled = user.IsAdmin };

            ctxProducts.Items.AddRange(new ToolStripItem[]
            {
                mSave, new ToolStripSeparator(),
                mEdit, new ToolStripSeparator(),
                mIn, mOut, new ToolStripSeparator(),
                mHistory, new ToolStripSeparator(),
                mDel
            });
            gridProducts.ContextMenuStrip = ctxProducts;
        }

        private void BuildTabs()
        {
            tabs.Dock = DockStyle.Fill;

            var pageProducts = new TabPage("Товары на складе");
            var pageMoves = new TabPage("Журнал движений");
            var pageReport = new TabPage("Сводный отчёт");

            // --- 1. Товары ---
            ConfigureGrid(gridProducts, true);
            gridProducts.DoubleClick += delegate { EditProduct(); };
            gridProducts.DataBindingComplete += delegate { FormatProductsGrid(); };
            gridProducts.CellValueChanged += OnProductsCellValueChanged;

            var filterPanel = new Panel { Dock = DockStyle.Top, Height = 46, Padding = new Padding(10, 8, 10, 8) };
            var lblSearch = new Label { Text = "Поиск:", Left = 10, Top = 12, Width = 50 };
            txtSearch.SetBounds(65, 9, 200, 26);
            txtSearch.TextChanged += delegate { CheckPendingSaveThenRefreshProducts(); };

            var lblCat = new Label { Text = "Категория:", Left = 275, Top = 12, Width = 75 };
            cmbCategory.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbCategory.SetBounds(355, 9, 190, 26);
            cmbCategory.SelectedIndexChanged += delegate { CheckPendingSaveThenRefreshProducts(); };

            chkLow.Text = "Только с низким остатком";
            chkLow.SetBounds(555, 11, 190, 24);
            chkLow.CheckedChanged += delegate { CheckPendingSaveThenRefreshProducts(); };

            btnSaveInline.Text = "💾 Сохранить изменения в БД";
            btnSaveInline.Font = new Font(Font, FontStyle.Bold);
            btnSaveInline.ForeColor = Color.FromArgb(16, 124, 65);
            btnSaveInline.SetBounds(filterPanel.Width - 235, 8, 225, 30);
            btnSaveInline.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnSaveInline.Click += delegate { SaveChanges(); };

            filterPanel.Controls.AddRange(new Control[] { lblSearch, txtSearch, lblCat, cmbCategory, chkLow, btnSaveInline });
            pageProducts.Controls.Add(gridProducts);
            pageProducts.Controls.Add(filterPanel);

            // --- 2. Журнал движений ---
            ConfigureGrid(gridMoves, false);

            var movesPanel = new Panel { Dock = DockStyle.Top, Height = 46, Padding = new Padding(10, 8, 10, 8) };
            var lblFrom = new Label { Text = "Период с:", Left = 10, Top = 12, Width = 65 };
            dtFrom.Format = DateTimePickerFormat.Short;
            dtFrom.Value = DateTime.Today.AddDays(-30);
            dtFrom.SetBounds(78, 9, 105, 26);
            dtFrom.ValueChanged += delegate { RefreshMoves(); };

            var lblTo = new Label { Text = "по:", Left = 190, Top = 12, Width = 28 };
            dtTo.Format = DateTimePickerFormat.Short;
            dtTo.Value = DateTime.Today;
            dtTo.SetBounds(220, 9, 105, 26);
            dtTo.ValueChanged += delegate { RefreshMoves(); };

            var lblType = new Label { Text = "Тип:", Left = 335, Top = 12, Width = 35 };
            cmbMoveType.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbMoveType.Items.AddRange(new object[] { "Все операции", "Только приход", "Только расход" });
            cmbMoveType.SelectedIndex = 0;
            cmbMoveType.SetBounds(375, 9, 140, 26);
            cmbMoveType.SelectedIndexChanged += delegate { RefreshMoves(); };

            // Кнопки быстрых фильтров
            SetupQuickFilterBtn(btnFilterToday, "Сегодня", 525, delegate
            {
                dtFrom.Value = DateTime.Today;
                dtTo.Value = DateTime.Today;
            });
            SetupQuickFilterBtn(btnFilterWeek, "7 дней", 605, delegate
            {
                dtFrom.Value = DateTime.Today.AddDays(-7);
                dtTo.Value = DateTime.Today;
            });
            SetupQuickFilterBtn(btnFilterMonth, "30 дней", 675, delegate
            {
                dtFrom.Value = DateTime.Today.AddDays(-30);
                dtTo.Value = DateTime.Today;
            });
            SetupQuickFilterBtn(btnFilterAll, "Все", 745, delegate
            {
                dtFrom.Value = new DateTime(2020, 1, 1);
                dtTo.Value = DateTime.Today;
            });

            lblFilterProductInfo.Text = "";
            lblFilterProductInfo.ForeColor = Color.DarkBlue;
            lblFilterProductInfo.Font = new Font(Font, FontStyle.Bold);
            lblFilterProductInfo.SetBounds(810, 12, 280, 24);
            lblFilterProductInfo.Cursor = Cursors.Hand;
            lblFilterProductInfo.Click += delegate
            {
                filterProductId = null;
                lblFilterProductInfo.Text = "";
                RefreshMoves();
            };

            movesPanel.Controls.AddRange(new Control[]
            {
                lblFrom, dtFrom, lblTo, dtTo, lblType, cmbMoveType,
                btnFilterToday, btnFilterWeek, btnFilterMonth, btnFilterAll,
                lblFilterProductInfo
            });
            pageMoves.Controls.Add(gridMoves);
            pageMoves.Controls.Add(movesPanel);

            // --- 3. Сводный отчёт ---
            var reportPanel = new Panel { Dock = DockStyle.Top, Height = 46, Padding = new Padding(10, 8, 10, 8) };
            var lblRepFrom = new Label { Text = "Период оборота с:", Left = 10, Top = 12, Width = 125 };
            dtRepFrom.Format = DateTimePickerFormat.Short;
            dtRepFrom.Value = DateTime.Today.AddDays(-30);
            dtRepFrom.SetBounds(140, 9, 105, 26);
            dtRepFrom.ValueChanged += delegate { RefreshReport(); };

            var lblRepTo = new Label { Text = "по:", Left = 255, Top = 12, Width = 28 };
            dtRepTo.Format = DateTimePickerFormat.Short;
            dtRepTo.Value = DateTime.Today;
            dtRepTo.SetBounds(285, 9, 105, 26);
            dtRepTo.ValueChanged += delegate { RefreshReport(); };

            btnCopyReport.Text = "Копировать текст";
            btnCopyReport.SetBounds(410, 8, 140, 28);
            btnCopyReport.Click += delegate
            {
                if (!string.IsNullOrEmpty(txtReport.Text))
                {
                    Clipboard.SetText(txtReport.Text);
                    MessageBox.Show(this, "Текст отчёта скопирован в буфер обмена.", Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            };

            btnSaveReport.Text = "Сохранить в файл...";
            btnSaveReport.SetBounds(560, 8, 150, 28);
            btnSaveReport.Click += OnSaveReportFile;

            reportPanel.Controls.AddRange(new Control[] { lblRepFrom, dtRepFrom, lblRepTo, dtRepTo, btnCopyReport, btnSaveReport });

            txtReport.Dock = DockStyle.Fill;
            txtReport.Multiline = true;
            txtReport.ReadOnly = true;
            txtReport.ScrollBars = ScrollBars.Vertical;
            txtReport.Font = new Font("Consolas", 10.5f);
            txtReport.BackColor = Color.White;
            txtReport.Padding = new Padding(10);

            pageReport.Controls.Add(txtReport);
            pageReport.Controls.Add(reportPanel);

            tabs.TabPages.AddRange(new[] { pageProducts, pageMoves, pageReport });
        }

        private static void SetupQuickFilterBtn(Button btn, string text, int left, EventHandler click)
        {
            btn.Text = text;
            btn.SetBounds(left, 8, 65, 28);
            btn.FlatStyle = FlatStyle.System;
            btn.Click += click;
        }

        private static void ConfigureGrid(DataGridView g, bool allowEdit)
        {
            g.Dock = DockStyle.Fill;
            g.ReadOnly = !allowEdit;
            g.AllowUserToAddRows = false;
            g.AllowUserToDeleteRows = false;
            g.AllowUserToResizeRows = false;
            g.SelectionMode = allowEdit ? DataGridViewSelectionMode.CellSelect : DataGridViewSelectionMode.FullRowSelect;
            g.MultiSelect = false;
            g.RowHeadersVisible = false;
            g.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            g.BackgroundColor = Color.White;
            g.BorderStyle = BorderStyle.None;
            g.AlternatingRowsDefaultCellStyle.BackColor = Color.FromArgb(248, 249, 250);
            if (allowEdit)
            {
                g.EditMode = DataGridViewEditMode.EditOnKeystrokeOrF2;
            }
        }

        private void LoadCategoryFilter()
        {
            cmbCategory.Items.Clear();
            cmbCategory.Items.Add(new Category(0, "Все категории"));
            foreach (Category c in Db.GetCategories()) cmbCategory.Items.Add(c);
            cmbCategory.SelectedIndex = 0;
        }

        // ───────────── Загрузка и сохранение данных ─────────────

        private void CheckPendingSaveThenRefreshProducts()
        {
            if (hasUnsavedChanges)
            {
                var dr = MessageBox.Show(this,
                    "В таблице товаров есть несохранённые изменения.\nСохранить их в базу данных Access перед обновлением списка?",
                    "Несохранённые изменения", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dr == DialogResult.Yes)
                {
                    SaveChangesSilent();
                }
            }
            RefreshProducts();
        }

        private void RefreshProducts()
        {
            if (loading) return;
            try
            {
                string search = txtSearch.Text;
                Category cat = cmbCategory.SelectedItem as Category;
                int? catId = (cat == null || cat.Id == 0) ? (int?)null : cat.Id;
                bool lowOnly = chkLow.Checked;

                productsTable = Db.GetProducts(search, catId, lowOnly);
                gridProducts.DataSource = productsTable;

                SetHeader(gridProducts, "Product_id", null);
                SetHeader(gridProducts, "Sku", "Артикул");
                SetHeader(gridProducts, "Title", "Наименование товара");
                SetHeader(gridProducts, "CategoryName", "Категория");
                SetHeader(gridProducts, "UnitName", "Ед. изм.");
                SetHeader(gridProducts, "Price", "Цена (руб.)");
                SetHeader(gridProducts, "Quantity", "Остаток (склад)");
                SetHeader(gridProducts, "MinStock", "Мин. остаток");
                SetHeader(gridProducts, "Total", "Сумма (руб.)");

                // Защищаем расчетные поля от прямого ввода
                if (gridProducts.Columns.Contains("Product_id")) gridProducts.Columns["Product_id"].ReadOnly = true;
                if (gridProducts.Columns.Contains("Quantity"))
                {
                    gridProducts.Columns["Quantity"].ReadOnly = true;
                    gridProducts.Columns["Quantity"].DefaultCellStyle.BackColor = Color.FromArgb(245, 247, 250);
                }
                if (gridProducts.Columns.Contains("Total"))
                {
                    gridProducts.Columns["Total"].ReadOnly = true;
                    gridProducts.Columns["Total"].DefaultCellStyle.BackColor = Color.FromArgb(245, 247, 250);
                    gridProducts.Columns["Total"].DefaultCellStyle.Format = "N2";
                }
                if (gridProducts.Columns.Contains("Price"))
                {
                    gridProducts.Columns["Price"].DefaultCellStyle.Format = "N2";
                }

                // Сброс индикатора несохранённых изменений
                hasUnsavedChanges = false;
                if (btnSave != null)
                {
                    btnSave.Text = "💾 Сохранить изменения (Ctrl+S)";
                    btnSave.ForeColor = Color.FromArgb(16, 124, 65);
                }

                UpdateStatusSummary();
            }
            catch (Exception ex)
            {
                ShowDbError(ex);
            }
        }

        private void UpdateStatusSummary()
        {
            if (productsTable == null) return;
            int totalCount = productsTable.Rows.Count;
            long totalQty = 0;
            decimal totalSum = 0;
            int lowCount = 0;
            foreach (DataRow r in productsTable.Rows)
            {
                if (r.RowState == DataRowState.Deleted) continue;
                int q = r["Quantity"] == DBNull.Value ? 0 : Convert.ToInt32(r["Quantity"]);
                int m = r["MinStock"] == DBNull.Value ? 0 : Convert.ToInt32(r["MinStock"]);
                decimal t = r["Total"] == DBNull.Value ? 0 : Convert.ToDecimal(r["Total"]);
                totalQty += q;
                totalSum += t;
                if (q <= m) lowCount++;
            }

            statusSummary.Text = $"Товаров: {totalCount} | Всего единиц: {totalQty} | Сумма склада: {totalSum:N2} руб. | Требуют заказа: {lowCount}";
        }

        private void OnProductsCellValueChanged(object sender, DataGridViewCellEventArgs e)
        {
            if (loading || e.RowIndex < 0) return;

            hasUnsavedChanges = true;
            if (btnSave != null)
            {
                btnSave.Text = "💾 Сохранить изменения * (Ctrl+S)";
                btnSave.ForeColor = Color.Firebrick;
            }
            statusSummary.Text = "⚠️ Есть несохранённые изменения! Нажмите «Сохранить изменения» (Ctrl+S) для записи в базу данных.";

            // Пересчёт суммы строки при изменении цены
            try
            {
                DataGridViewRow row = gridProducts.Rows[e.RowIndex];
                if (row.Cells["Price"].Value != null && row.Cells["Quantity"].Value != null)
                {
                    decimal price = Convert.ToDecimal(row.Cells["Price"].Value);
                    int qty = Convert.ToInt32(row.Cells["Quantity"].Value);
                    row.Cells["Total"].Value = price * qty;
                }
            }
            catch { }
        }

        /// <summary>
        /// Сохраняет все изменённые записи напрямую в базу данных Microsoft Access.
        /// </summary>
        private void SaveChanges()
        {
            try
            {
                if (gridProducts.IsCurrentCellInEditMode)
                {
                    gridProducts.EndEdit();
                }
                if (gridProducts.DataSource != null)
                {
                    BindingContext[gridProducts.DataSource]?.EndCurrentEdit();
                }

                if (productsTable != null)
                {
                    int updated = Db.SaveProductChanges(productsTable);
                    hasUnsavedChanges = false;
                    btnSave.Text = "💾 Сохранить изменения (Ctrl+S)";
                    btnSave.ForeColor = Color.FromArgb(16, 124, 65);

                    RefreshProducts();
                    RefreshReport();

                    string msg = updated > 0
                        ? $"Все изменения успешно сохранены напрямую в базу данных Microsoft Access!\nЗаписей обновлено: {updated}."
                        : "База данных актуальна: все текущие данные уже сохранены.";

                    MessageBox.Show(this, msg, "Сохранение в базу данных Access", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            catch (Exception ex)
            {
                ShowDbError(ex);
            }
        }

        private void SaveChangesSilent()
        {
            try
            {
                if (gridProducts.IsCurrentCellInEditMode)
                {
                    gridProducts.EndEdit();
                }
                if (gridProducts.DataSource != null)
                {
                    BindingContext[gridProducts.DataSource]?.EndCurrentEdit();
                }

                if (productsTable != null)
                {
                    Db.SaveProductChanges(productsTable);
                    hasUnsavedChanges = false;
                }
            }
            catch { }
        }

        private void FormatProductsGrid()
        {
            foreach (DataGridViewRow row in gridProducts.Rows)
            {
                if (row.Cells["Quantity"].Value == null || row.Cells["MinStock"].Value == null) continue;
                if (row.Cells["Quantity"].Value == DBNull.Value || row.Cells["MinStock"].Value == DBNull.Value) continue;

                int qty = Convert.ToInt32(row.Cells["Quantity"].Value);
                int min = Convert.ToInt32(row.Cells["MinStock"].Value);

                if (qty == 0)
                {
                    row.DefaultCellStyle.BackColor = Color.MistyRose; // Нет на складе
                }
                else if (qty <= min)
                {
                    row.DefaultCellStyle.BackColor = Color.FromArgb(255, 248, 220); // Заканчивается
                }
            }
        }

        private static void SetHeader(DataGridView g, string column, string header)
        {
            if (!g.Columns.Contains(column)) return;
            if (header == null) g.Columns[column].Visible = false;
            else g.Columns[column].HeaderText = header;
        }

        private void RefreshMoves()
        {
            if (loading) return;
            try
            {
                DateTime from = dtFrom.Value.Date;
                DateTime to = dtTo.Value.Date.AddDays(1).AddSeconds(-1);

                string type = null;
                if (cmbMoveType.SelectedIndex == 1) type = Db.In;
                else if (cmbMoveType.SelectedIndex == 2) type = Db.Out;

                gridMoves.DataSource = Db.GetMovements(from, to, type, filterProductId);

                SetHeader(gridMoves, "Movement_id", null);
                SetHeader(gridMoves, "MoveDate", "Дата и время");
                SetHeader(gridMoves, "Sku", "Артикул");
                SetHeader(gridMoves, "Title", "Товар");
                SetHeader(gridMoves, "TypeName", "Операция");
                SetHeader(gridMoves, "Qty", "Количество");
                SetHeader(gridMoves, "Counterparty", "Контрагент (поставщик/получатель)");
                SetHeader(gridMoves, "Note", "Примечание");
                SetHeader(gridMoves, "UserName", "Сотрудник");

                if (gridMoves.Columns.Contains("MoveDate"))
                    gridMoves.Columns["MoveDate"].DefaultCellStyle.Format = "dd.MM.yyyy HH:mm";

                foreach (DataGridViewRow row in gridMoves.Rows)
                {
                    bool income = Convert.ToString(row.Cells["TypeName"].Value) == "Приход";
                    row.DefaultCellStyle.BackColor = income ? Color.FromArgb(240, 253, 244) : Color.FromArgb(254, 242, 242);
                }
            }
            catch (Exception ex)
            {
                ShowDbError(ex);
            }
        }

        private void FilterBySelectedProduct()
        {
            int? id = SelectedProductId();
            if (id == null) return;

            filterProductId = id;
            ProductData p = Db.GetProduct(id.Value);
            lblFilterProductInfo.Text = $"Фильтр: {p.Sku} (сброс ✕)";
            tabs.SelectedIndex = 1; // переключаемся на вкладку «Журнал»
            RefreshMoves();
        }

        private void RefreshReport()
        {
            if (loading) return;
            try
            {
                DataTable products = Db.GetProducts(null, null, false);
                int positions = products.Rows.Count;
                long totalQty = 0;
                decimal totalValue = 0;
                var low = new List<string>();

                foreach (DataRow r in products.Rows)
                {
                    int qty = Convert.ToInt32(r["Quantity"]);
                    int min = Convert.ToInt32(r["MinStock"]);
                    totalQty += qty;
                    totalValue += Convert.ToDecimal(r["Total"]);
                    if (qty <= min)
                    {
                        int need = min - qty;
                        string status = qty == 0 ? "ОТСУТСТВУЕТ" : $"остаток {qty} {r["UnitName"]}";
                        low.Add($"  [!] {r["Sku"],-10} {r["Title"],-32} | {status} (мин. {min}, не хватает: {need})");
                    }
                }

                DateTime from = dtRepFrom.Value.Date;
                DateTime to = dtRepTo.Value.Date.AddDays(1).AddSeconds(-1);
                int[] turnover = Db.GetTurnover(from, to);

                var sb = new StringBuilder();
                sb.AppendLine("╔═══════════════════════════════════════════════════════════════════════╗");
                sb.AppendLine("║                     СВОДНЫЙ ОТЧЁТ ПО СКЛАДУ                           ║");
                sb.AppendLine("╚═══════════════════════════════════════════════════════════════════════╝");
                sb.AppendLine($"Сформирован: {DateTime.Now:dd.MM.yyyy HH:mm}   |   Сотрудник: {user.Name} ({user.Role})");
                sb.AppendLine($"База данных: {Path.GetFileName(Db.ActiveDbPath)}   |   Драйвер: {Db.ActiveProvider}");
                sb.AppendLine(new string('-', 73));
                sb.AppendLine($"1. ОБЩЕЕ СОСТОЯНИЕ СКЛАДА:");
                sb.AppendLine($"   - Всего наименований товаров:      {positions}");
                sb.AppendLine($"   - Общее количество единиц:         {totalQty}");
                sb.AppendLine($"   - Общая стоимость товарного запаса:{totalValue:N2} руб.");
                sb.AppendLine($"   - Позиций с низким остатком:       {low.Count}");
                sb.AppendLine();
                sb.AppendLine($"2. ТОВАРЫ, ТРЕБУЮЩИЕ СРОЧНОГО ЗАКАЗА / ПОПОЛНЕНИЯ:");
                if (low.Count > 0)
                {
                    foreach (string s in low) sb.AppendLine(s);
                }
                else
                {
                    sb.AppendLine("   Все товары в наличии в достаточном объёме (выше минимального порога).");
                }
                sb.AppendLine();
                sb.AppendLine($"3. ОБОРОТ СКЛАДА ЗА ПЕРИОД {from:dd.MM.yyyy} — {dtRepTo.Value:dd.MM.yyyy}:");
                sb.AppendLine($"   - Поступило на склад (приход):     {turnover[0]} ед.");
                sb.AppendLine($"   - Отгружено со склада (расход):    {turnover[1]} ед.");
                sb.AppendLine($"   - Баланс оборота:                  {(turnover[0] - turnover[1]):+0;-0;0} ед.");
                sb.AppendLine(new string('=', 73));

                txtReport.Text = sb.ToString();
            }
            catch (Exception ex)
            {
                ShowDbError(ex);
            }
        }

        private void OnSaveReportFile(object sender, EventArgs e)
        {
            using (var dlg = new SaveFileDialog())
            {
                dlg.Filter = "Текстовый отчёт (*.txt)|*.txt";
                dlg.FileName = $"Складской_Отчёт_{DateTime.Now:yyyyMMdd_HHmm}.txt";
                if (dlg.ShowDialog(this) == DialogResult.OK)
                {
                    try
                    {
                        File.WriteAllText(dlg.FileName, txtReport.Text, Encoding.UTF8);
                        MessageBox.Show(this, "Отчёт успешно сохранён:\n" + dlg.FileName, Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, "Ошибка сохранения отчёта:\n" + ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void RefreshAll()
        {
            RefreshProducts();
            RefreshMoves();
            RefreshReport();
        }

        // ───────────── Действия ─────────────

        private int? SelectedProductId()
        {
            DataGridViewRow row = gridProducts.CurrentRow;
            if (row == null || row.Cells["Product_id"].Value == null || row.Cells["Product_id"].Value == DBNull.Value) return null;
            return Convert.ToInt32(row.Cells["Product_id"].Value);
        }

        private void AddProduct()
        {
            using (var form = new ProductForm(null))
            {
                if (form.ShowDialog(this) != DialogResult.OK) return;
                try
                {
                    int id = Db.AddProduct(form.Result);
                    if (form.InitialQty > 0)
                    {
                        Db.AddMovement(id, Db.In, form.InitialQty, DateTime.Now, "Начальный остаток", "Создание карточки товара", user.Id);
                    }
                }
                catch (Exception ex)
                {
                    ShowDbError(ex);
                    return;
                }
            }
            RefreshAll();
        }

        private void EditProduct()
        {
            int? id = SelectedProductId();
            if (id == null)
            {
                MessageBox.Show(this, "Выберите товар в таблице.", Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                ProductData data = Db.GetProduct(id.Value);
                if (data == null) return;
                using (var form = new ProductForm(data))
                {
                    if (form.ShowDialog(this) != DialogResult.OK) return;
                    Db.UpdateProduct(form.Result);
                }
            }
            catch (Exception ex)
            {
                ShowDbError(ex);
                return;
            }
            RefreshAll();
        }

        private void DeleteProduct()
        {
            if (!user.IsAdmin)
            {
                MessageBox.Show(this, "Удалять товары может только администратор.", Text,
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int? id = SelectedProductId();
            if (id == null)
            {
                MessageBox.Show(this, "Выберите товар в таблице.", Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                string title = "товар";
                if (gridProducts.CurrentRow != null && gridProducts.CurrentRow.Cells["Title"].Value != null)
                {
                    title = "«" + gridProducts.CurrentRow.Cells["Title"].Value.ToString() + "»";
                }

                int moves = Db.MovementCountForProduct(id.Value);
                string prompt = moves > 0
                    ? $"Вы действительно хотите удалить {title}?\n\nВнимание: по данному товару в базе зафиксировано движений на складе ({moves} шт.).\nВсе связанные движения также будут удалены из базы данных!"
                    : $"Вы действительно хотите удалить {title} из базы данных?";

                if (MessageBox.Show(this, prompt, "Подтверждение удаления",
                        MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) != DialogResult.Yes)
                {
                    return;
                }

                Db.DeleteProduct(id.Value);
                hasUnsavedChanges = false;
                if (btnSave != null)
                {
                    btnSave.Text = "💾 Сохранить изменения (Ctrl+S)";
                    btnSave.ForeColor = Color.FromArgb(16, 124, 65);
                }
            }
            catch (Exception ex)
            {
                ShowDbError(ex);
                return;
            }
            RefreshAll();
            MessageBox.Show(this, "Товар успешно удалён из базы данных.", Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void RegisterMovement(bool income)
        {
            try
            {
                using (var form = new MovementForm(income, user.Id, SelectedProductId()))
                {
                    if (form.ShowDialog(this) != DialogResult.OK) return;
                }
            }
            catch (Exception ex)
            {
                ShowDbError(ex);
                return;
            }
            RefreshAll();
        }

        private void OpenCategories()
        {
            using (var form = new CategoriesForm(user.IsAdmin))
            {
                form.ShowDialog(this);
            }
            loading = true;
            LoadCategoryFilter();
            loading = false;
            RefreshProducts();
        }

        private void OpenUsers()
        {
            using (var form = new UsersForm(user))
            {
                form.ShowDialog(this);
            }
        }

        private void OpenDbInfo()
        {
            using (var form = new DbInfoForm())
            {
                form.ShowDialog(this);
                if (form.DatabaseSwitched)
                {
                    string prov = Db.ActiveProvider ?? "OLEDB";
                    string arch = Environment.Is64BitProcess ? "x64" : "x86";
                    Text = $"Складской учёт (Microsoft Access) — [{Db.ActiveDbPath}]";
                    statusDb.Text = $"📂 БД: {Db.ActiveDbPath} [{prov} {arch}]";
                    loading = true;
                    LoadCategoryFilter();
                    loading = false;
                    RefreshAll();
                }
            }
        }

        private void ExportCurrent()
        {
            DataGridView grid;
            string defaultName;
            if (tabs.SelectedIndex == 1)
            {
                grid = gridMoves;
                defaultName = "movements.csv";
            }
            else if (tabs.SelectedIndex == 0)
            {
                grid = gridProducts;
                defaultName = "products.csv";
            }
            else
            {
                MessageBox.Show(this, "Экспорт доступен на вкладках «Товары» и «Журнал движений». Для отчёта используйте кнопку «Сохранить в файл».",
                    Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            using (var dlg = new SaveFileDialog())
            {
                dlg.Filter = "CSV (Excel) (*.csv)|*.csv";
                dlg.FileName = defaultName;
                if (dlg.ShowDialog(this) != DialogResult.OK) return;

                try
                {
                    List<DataGridViewColumn> cols = grid.Columns.Cast<DataGridViewColumn>()
                        .Where(c => c.Visible).OrderBy(c => c.DisplayIndex).ToList();

                    var sb = new StringBuilder();
                    sb.AppendLine(string.Join(";", cols.Select(c => Csv(c.HeaderText))));
                    foreach (DataGridViewRow row in grid.Rows)
                    {
                        sb.AppendLine(string.Join(";", cols.Select(c => Csv(row.Cells[c.Index].FormattedValue))));
                    }
                    File.WriteAllText(dlg.FileName, sb.ToString(), new UTF8Encoding(true));
                    MessageBox.Show(this, "Данные успешно выгружены:\n" + dlg.FileName, Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Не удалось сохранить файл:\n" + ex.Message, Text,
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private static string Csv(object value)
        {
            string s = value == null ? "" : value.ToString();
            if (s.IndexOfAny(new[] { ';', '"', '\r', '\n' }) >= 0) s = "\"" + s.Replace("\"", "\"\"") + "\"";
            return s;
        }

        private void ShowDbError(Exception ex)
        {
            MessageBox.Show(this, "Ошибка при работе с базой данных Access:\n" + ex.Message, Text,
                MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        // ───────────── Защита при закрытии и горячие клавиши ─────────────

        protected override void OnFormClosing(FormClosingEventArgs e)
        {
            if (hasUnsavedChanges)
            {
                var dr = MessageBox.Show(this,
                    "В таблице товаров есть несохранённые изменения.\nСохранить их в базу данных перед выходом?",
                    "Несохранённые изменения", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);

                if (dr == DialogResult.Yes)
                {
                    SaveChangesSilent();
                }
                else if (dr == DialogResult.Cancel)
                {
                    e.Cancel = true;
                    return;
                }
            }
            base.OnFormClosing(e);
        }

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            switch (keyData)
            {
                case Keys.Control | Keys.S:
                    SaveChanges();
                    return true;
                case Keys.Control | Keys.F:
                    tabs.SelectedIndex = 0;
                    txtSearch.Focus();
                    return true;
                case Keys.Control | Keys.N:
                    AddProduct();
                    return true;
                case Keys.Control | Keys.I:
                    RegisterMovement(true);
                    return true;
                case Keys.Control | Keys.O:
                    RegisterMovement(false);
                    return true;
                case Keys.F5:
                    RefreshAll();
                    return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }
    }
}
