﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace WarehouseAccounting
{
    /// <summary>Справочник категорий: добавление, переименование, удаление (удаление — только администратор).</summary>
    internal sealed class CategoriesForm : Form
    {
        private readonly ListBox lst = new ListBox();
        private readonly TextBox txtName = new TextBox();
        private readonly Button btnAdd = new Button();
        private readonly Button btnRename = new Button();
        private readonly Button btnDelete = new Button();
        private readonly Button btnClose = new Button();

        public CategoriesForm(bool isAdmin)
        {
            Text = "Категории товаров";
            Font = new Font("Segoe UI", 9.5f);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterParent;
            ClientSize = new Size(420, 330);

            lst.SetBounds(15, 15, 260, 250);
            lst.SelectedIndexChanged += delegate
            {
                Category c = lst.SelectedItem as Category;
                if (c != null) txtName.Text = c.Name;
            };

            Label lbl = new Label { Text = "Название категории", Left = 15, Top = 275, Width = 200 };
            txtName.SetBounds(15, 297, 260, 26);
            txtName.MaxLength = 100;

            btnAdd.Text = "Добавить";
            btnAdd.SetBounds(290, 15, 115, 32);
            btnAdd.Click += OnAdd;

            btnRename.Text = "Переименовать";
            btnRename.SetBounds(290, 55, 115, 32);
            btnRename.Click += OnRename;

            btnDelete.Text = "Удалить";
            btnDelete.SetBounds(290, 95, 115, 32);
            btnDelete.Enabled = isAdmin;
            btnDelete.Click += OnDelete;

            btnClose.Text = "Закрыть";
            btnClose.SetBounds(290, 291, 115, 32);
            btnClose.DialogResult = DialogResult.Cancel;
            CancelButton = btnClose;

            Controls.AddRange(new Control[] { lst, lbl, txtName, btnAdd, btnRename, btnDelete, btnClose });
            Reload();
        }

        private void Reload()
        {
            lst.Items.Clear();
            foreach (Category c in Db.GetCategories()) lst.Items.Add(c);
        }

        private bool CheckName(int exceptId, out string name)
        {
            name = txtName.Text.Trim();
            if (name.Length == 0)
            {
                MessageBox.Show(this, "Введите название категории.", Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (Db.CategoryNameExists(name, exceptId))
            {
                MessageBox.Show(this, "Категория с таким названием уже есть.", Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            return true;
        }

        private void OnAdd(object sender, EventArgs e)
        {
            string name;
            if (!CheckName(0, out name)) return;
            Db.AddCategory(name);
            txtName.Clear();
            Reload();
        }

        private void OnRename(object sender, EventArgs e)
        {
            Category c = lst.SelectedItem as Category;
            if (c == null)
            {
                MessageBox.Show(this, "Выберите категорию в списке.", Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            string name;
            if (!CheckName(c.Id, out name)) return;
            Db.RenameCategory(c.Id, name);
            Reload();
        }

        private void OnDelete(object sender, EventArgs e)
        {
            Category c = lst.SelectedItem as Category;
            if (c == null)
            {
                MessageBox.Show(this, "Выберите категорию в списке.", Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }
            int used = Db.CategoryProductCount(c.Id);
            string prompt = used > 0
                ? $"В категории «{c.Name}» находится товаров: {used} шт.\nПри удалении категории данные товары останутся в базе (без категории).\n\nУдалить категорию «{c.Name}»?"
                : $"Удалить категорию «{c.Name}»?";

            if (MessageBox.Show(this, prompt, Text,
                    MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;
            Db.DeleteCategory(c.Id);
            txtName.Clear();
            Reload();
        }
    }
}
