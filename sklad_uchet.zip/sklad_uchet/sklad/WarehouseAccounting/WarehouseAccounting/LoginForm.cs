using System;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace WarehouseAccounting
{
    /// <summary>Окно входа и регистрации. Первый зарегистрированный пользователь становится администратором.</summary>
    internal sealed class LoginForm : Form
    {
        private const int MaxAttempts = 5;

        private readonly Label lblTitle = new Label();
        private readonly Label lblInfo = new Label();
        private readonly Label lblName = new Label();
        private readonly Label lblPass = new Label();
        private readonly Label lblConfirm = new Label();
        private readonly Label lblCapsLock = new Label();
        private readonly Label lblDbInfo = new Label();
        private readonly TextBox txtName = new TextBox();
        private readonly TextBox txtPass = new TextBox();
        private readonly TextBox txtConfirm = new TextBox();
        private readonly Button btnPrimary = new Button();
        private readonly Button btnSwitch = new Button();

        private bool registerMode;
        private bool firstRun;
        private int failedAttempts;

        public UserRecord User { get; private set; }

        public LoginForm()
        {
            Text = "Складской учёт — Авторизация";
            Font = new Font("Segoe UI", 9.5f);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(400, 360);

            lblTitle.Text = "Складской учёт";
            lblTitle.Font = new Font("Segoe UI", 16f, FontStyle.Bold);
            lblTitle.ForeColor = Color.FromArgb(24, 76, 120);
            lblTitle.SetBounds(25, 15, 350, 34);

            lblInfo.SetBounds(25, 52, 350, 40);
            lblInfo.ForeColor = Color.DimGray;

            lblName.Text = "Имя пользователя (логин):";
            lblName.SetBounds(25, 96, 350, 20);
            txtName.SetBounds(25, 118, 350, 26);
            txtName.MaxLength = 50;

            lblPass.Text = "Пароль:";
            lblPass.SetBounds(25, 150, 350, 20);
            txtPass.SetBounds(25, 172, 350, 26);
            txtPass.UseSystemPasswordChar = true;
            txtPass.MaxLength = 128;
            txtPass.KeyDown += OnPasswordKeyDown;

            lblCapsLock.Text = "Внимание: включен Caps Lock!";
            lblCapsLock.ForeColor = Color.Firebrick;
            lblCapsLock.Font = new Font(Font, FontStyle.Bold);
            lblCapsLock.SetBounds(25, 200, 350, 18);
            lblCapsLock.Visible = Control.IsKeyLocked(Keys.CapsLock);

            lblConfirm.Text = "Повторите пароль:";
            lblConfirm.SetBounds(25, 200, 350, 20);
            txtConfirm.SetBounds(25, 222, 350, 26);
            txtConfirm.UseSystemPasswordChar = true;
            txtConfirm.MaxLength = 128;
            txtConfirm.KeyDown += OnPasswordKeyDown;

            btnPrimary.SetBounds(25, 260, 210, 36);
            btnPrimary.BackColor = Color.FromArgb(30, 110, 180);
            btnPrimary.ForeColor = Color.White;
            btnPrimary.FlatStyle = FlatStyle.System;
            btnPrimary.Click += OnPrimaryClick;

            btnSwitch.SetBounds(245, 260, 130, 36);
            btnSwitch.FlatStyle = FlatStyle.System;
            btnSwitch.Click += delegate { SetMode(!registerMode); };

            lblDbInfo.SetBounds(25, 310, 350, 40);
            lblDbInfo.Font = new Font("Segoe UI", 8f);
            lblDbInfo.ForeColor = Color.Gray;
            string dbName = Path.GetFileName(Db.ActiveDbPath);
            string prov = Db.ActiveProvider ?? "OLEDB";
            string arch = Environment.Is64BitProcess ? "x64" : "x86";
            lblDbInfo.Text = $"База: Microsoft Access ({dbName})\nДвижок: {prov} [{arch}]";

            Controls.AddRange(new Control[]
            {
                lblTitle, lblInfo, lblName, txtName, lblPass, txtPass,
                lblCapsLock, lblConfirm, txtConfirm, btnPrimary, btnSwitch, lblDbInfo
            });
            AcceptButton = btnPrimary;

            firstRun = Db.CountUsers() == 0;
            SetMode(firstRun);
        }

        private void OnPasswordKeyDown(object sender, KeyEventArgs e)
        {
            lblCapsLock.Visible = Control.IsKeyLocked(Keys.CapsLock) && !registerMode;
        }

        private void SetMode(bool register)
        {
            registerMode = register;
            lblConfirm.Visible = register;
            txtConfirm.Visible = register;
            lblCapsLock.Visible = !register && Control.IsKeyLocked(Keys.CapsLock);
            txtPass.Text = "";
            txtConfirm.Text = "";

            if (register)
            {
                btnPrimary.Text = "Зарегистрироваться";
                btnSwitch.Text = "Ко входу";
                btnSwitch.Visible = !firstRun;
                lblInfo.Text = firstRun
                    ? "Первый запуск: создайте учётную запись администратора системы."
                    : "Регистрация учётной записи администратора.";
                ClientSize = new Size(400, 360);
                btnPrimary.Top = 260;
                btnSwitch.Top = 260;
                lblDbInfo.Top = 310;
            }
            else
            {
                btnPrimary.Text = "Войти в систему";
                btnSwitch.Text = "Регистрация";
                btnSwitch.Visible = true;
                lblInfo.Text = "Вход: admin / admin123";
                txtName.Text = "admin";
                txtPass.Text = "admin123";
                ClientSize = new Size(400, 310);
                btnPrimary.Top = 215;
                btnSwitch.Top = 215;
                lblDbInfo.Top = 265;
            }

            txtName.Focus();
        }

        private void OnPrimaryClick(object sender, EventArgs e)
        {
            try
            {
                if (registerMode) DoRegister();
                else DoLogin();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка при работе с базой данных Access:\n" + ex.Message,
                    Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void DoLogin()
        {
            string name = txtName.Text.Trim();
            UserRecord user = name.Length == 0 ? null : Db.GetUser(name);

            if (user == null || !CryptoHelper.Verify(txtPass.Text, user.Hash))
            {
                failedAttempts++;
                if (failedAttempts >= MaxAttempts)
                {
                    MessageBox.Show(this, "Слишком много неудачных попыток входа. Программа будет закрыта в целях безопасности.",
                        Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    DialogResult = DialogResult.Cancel;
                    return;
                }
                MessageBox.Show(this, $"Неверное имя пользователя или пароль.\nОсталось попыток: {MaxAttempts - failedAttempts}",
                    Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPass.Clear();
                txtPass.Focus();
                return;
            }

            User = user;
            DialogResult = DialogResult.OK;
        }

        private void DoRegister()
        {
            string name = txtName.Text.Trim();
            string error = ValidateName(name);
            if (error == null) error = ValidatePassword(txtPass.Text, txtConfirm.Text);
            if (error != null)
            {
                MessageBox.Show(this, error, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (Db.GetUser(name) != null)
            {
                MessageBox.Show(this, "Пользователь с таким логином уже существует в базе.",
                    Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            bool first = Db.CountUsers() == 0;
            string role = Roles.Admin;
            int id = Db.CreateUser(name, CryptoHelper.HashPassword(txtPass.Text), role);

            if (first)
            {
                try
                {
                    Db.SeedDemoData(id);
                }
                catch { }
            }

            User = new UserRecord { Id = id, Name = name, Role = role };
            DialogResult = DialogResult.OK;
        }

        private static string ValidateName(string name)
        {
            if (name.Length < 3 || name.Length > 50)
                return "Имя пользователя должно содержать от 3 до 50 символов.";

            foreach (char ch in name)
            {
                if (!(char.IsLetterOrDigit(ch) || ch == '.' || ch == '-' || ch == '_'))
                    return "Имя может содержать только буквы, цифры, точку, дефис и подчёркивание.";
            }
            return null;
        }

        private static string ValidatePassword(string pass, string confirm)
        {
            if (pass.Length < 6 || pass.Length > 128)
                return "Пароль должен содержать не менее 6 символов.";
            if (pass != confirm)
                return "Введённые пароли не совпадают.";
            return null;
        }
    }
}
