using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Windows.Forms;

namespace WarehouseAccounting
{
    /// <summary>
    /// Окно информации о базе данных Microsoft Access, системной диагностики, смены файла и резервного копирования.
    /// Позволяет мгновенно увидеть активный драйвер OLE DB, путь к файлу базы, проверить целостность,
    /// создать резервную копию или подключить другой файл базы данных.
    /// </summary>
    internal sealed class DbInfoForm : Form
    {
        private readonly TextBox txtInfo = new TextBox();
        private readonly Button btnBackup = new Button();
        private readonly Button btnSwitchDb = new Button();
        private readonly Button btnOpenFolder = new Button();
        private readonly Button btnClose = new Button();

        public bool DatabaseSwitched { get; private set; }

        public DbInfoForm()
        {
            Text = "Диагностика базы данных Access и системы";
            Font = new Font("Segoe UI", 9.5f);
            MinimumSize = new Size(760, 520);
            Size = new Size(780, 540);
            StartPosition = FormStartPosition.CenterParent;
            ShowInTaskbar = false;

            var panelBottom = new Panel { Dock = DockStyle.Bottom, Height = 52, Padding = new Padding(12, 10, 12, 10) };

            btnBackup.Text = "Резервная копия...";
            btnBackup.SetBounds(12, 10, 160, 32);
            btnBackup.Click += OnBackup;

            btnSwitchDb.Text = "Выбрать файл БД...";
            btnSwitchDb.SetBounds(180, 10, 160, 32);
            btnSwitchDb.Click += OnSwitchDb;

            btnOpenFolder.Text = "Папка с базой";
            btnOpenFolder.SetBounds(348, 10, 130, 32);
            btnOpenFolder.Click += OnOpenFolder;

            btnClose.Text = "Закрыть";
            btnClose.Anchor = AnchorStyles.Top | AnchorStyles.Right;
            btnClose.SetBounds(panelBottom.Width - 112, 10, 100, 32);
            btnClose.DialogResult = DialogResult.OK;

            panelBottom.Controls.AddRange(new Control[] { btnBackup, btnSwitchDb, btnOpenFolder, btnClose });

            txtInfo.Dock = DockStyle.Fill;
            txtInfo.Multiline = true;
            txtInfo.ReadOnly = true;
            txtInfo.ScrollBars = ScrollBars.Vertical;
            txtInfo.Font = new Font("Consolas", 10f);
            txtInfo.BackColor = Color.White;

            Controls.Add(txtInfo);
            Controls.Add(panelBottom);

            CancelButton = btnClose;

            ReloadInfo();
        }

        private void ReloadInfo()
        {
            txtInfo.Text = Db.GetDiagnosticInfo();
        }

        private void OnBackup(object sender, EventArgs e)
        {
            using (var dlg = new SaveFileDialog())
            {
                string ext = Db.ActiveFormat ?? ".accdb";
                dlg.Filter = $"Файл базы Access (*{ext})|*{ext}|Все файлы (*.*)|*.*";
                dlg.FileName = $"WarehouseDB_Backup_{DateTime.Now:yyyyMMdd_HHmm}{ext}";

                if (dlg.ShowDialog(this) == DialogResult.OK)
                {
                    try
                    {
                        Db.BackupDatabase(dlg.FileName);
                        MessageBox.Show(this, "Резервная копия базы данных успешно создана:\n" + dlg.FileName,
                            Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(this, "Не удалось создать резервную копию:\n" + ex.Message,
                            Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void OnSwitchDb(object sender, EventArgs e)
        {
            using (var dlg = new OpenFileDialog())
            {
                dlg.Title = "Выберите файл базы данных Microsoft Access";
                dlg.Filter = "Базы данных Access (*.accdb;*.mdb)|*.accdb;*.mdb|Все файлы (*.*)|*.*";
                if (dlg.ShowDialog(this) == DialogResult.OK)
                {
                    if (Db.SwitchDatabase(dlg.FileName, out string err))
                    {
                        DatabaseSwitched = true;
                        ReloadInfo();
                        MessageBox.Show(this, "База данных успешно переключена на файл:\n" + dlg.FileName,
                            Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show(this, "Не удалось открыть выбранную базу данных:\n" + err,
                            Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void OnOpenFolder(object sender, EventArgs e)
        {
            try
            {
                string path = Db.ActiveDbPath;
                if (!string.IsNullOrEmpty(path) && File.Exists(path))
                {
                    Process.Start("explorer.exe", $"/select,\"{path}\"");
                }
                else
                {
                    Process.Start("explorer.exe", Db.BaseDirectory);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Не удалось открыть проводник:\n" + ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }
    }
}
