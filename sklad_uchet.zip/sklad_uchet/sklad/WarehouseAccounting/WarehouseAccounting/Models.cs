﻿using System;

namespace WarehouseAccounting
{
    /// <summary>Названия ролей пользователей (в системе действует единая роль Администратор).</summary>
    internal static class Roles
    {
        public const string Admin = "Администратор";
    }

    /// <summary>Пользователь из таблицы Users.</summary>
    internal sealed class UserRecord
    {
        public int Id;
        public string Name;
        public string Hash;
        public string Role;

        public bool IsAdmin
        {
            get { return true; }
        }
    }

    /// <summary>Категория товара (элемент выпадающих списков).</summary>
    internal sealed class Category
    {
        public int Id;
        public string Name;

        public Category(int id, string name)
        {
            Id = id;
            Name = name;
        }

        public override string ToString()
        {
            return Name;
        }
    }

    /// <summary>Товар (строка таблицы Products).</summary>
    internal sealed class ProductData
    {
        public int Id;
        public string Sku;
        public string Title;
        public string UnitName;
        public int? CategoryId;
        public decimal Price;
        public int MinStock;
        public int Quantity;
    }

    /// <summary>Элемент выпадающего списка товаров в форме движения.</summary>
    internal sealed class ProductItem
    {
        public int Id;
        public string Display;
        public int Quantity;
        public string UnitName;

        public override string ToString()
        {
            return Display;
        }
    }
}
