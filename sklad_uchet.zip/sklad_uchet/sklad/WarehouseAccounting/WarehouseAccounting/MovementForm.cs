﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace WarehouseAccounting
{
    /// <summary>Диалог регистрации прихода или расхода товара.</summary>
    internal sealed class MovementForm : Form
    {
        private readonly bool isIncome;
        private readonly int userId;

        private readonly ComboBox cmbProduct = new ComboBox();
        private readonly Label lblStock = new Label();
        private readonly NumericUpDown numQty = new NumericUpDown();
        private readonly DateTimePicker dtpDate = new DateTimePicker();
        private readonly TextBox txtCounterparty = new TextBox();
        private readonly TextBox txtNote = new TextBox();
        private readonly Button btnOk = new Button();
        private readonly Button btnCancel = new Button();

        public MovementForm(bool income, int currentUserId, int? presetProductId)
        {
            isIncome = income;
            userId = currentUserId;

            Text = isIncome ? "Приход товара" : "Расход товара";
            Font = new Font("Segoe UI", 9.5f);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            ShowInTaskbar = false;
            StartPosition = FormStartPosition.CenterParent;

            int y = 15;
            cmbProduct.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbProduct.SelectedIndexChanged += delegate { UpdateStockLabel(); };
            AddRow("Товар *", cmbProduct, ref y);

            lblStock.SetBounds(200, y - 8, 275, 20);
            lblStock.ForeColor = Color.DimGray;
            Controls.Add(lblStock);
            y += 20;

            numQty.Minimum = 1;
            numQty.Maximum = 1000000;
            numQty.Value = 1;
            AddRow("Количество *", numQty, ref y);

            dtpDate.Format = DateTimePickerFormat.Custom;
            dtpDate.CustomFormat = "dd.MM.yyyy HH:mm";
            dtpDate.Value = DateTime.Now;
            AddRow("Дата и время", dtpDate, ref y);

            txtCounterparty.MaxLength = 150;
            AddRow(isIncome ? "Поставщик" : "Получатель", txtCounterparty, ref y);

            txtNote.MaxLength = 255;
            AddRow("Примечание", txtNote, ref y);

            btnOk.Text = isIncome ? "Оприходовать" : "Списать";
            btnOk.SetBounds(230, y + 10, 130, 34);
            btnOk.Click += OnOk;

            btnCancel.Text = "Отмена";
            btnCancel.SetBounds(370, y + 10, 105, 34);
            btnCancel.DialogResult = DialogResult.Cancel;

            Controls.Add(btnOk);
            Controls.Add(btnCancel);
            AcceptButton = btnOk;
            CancelButton = btnCancel;
            ClientSize = new Size(500, y + 60);

            foreach (ProductItem item in Db.GetProductItems()) cmbProduct.Items.Add(item);
            if (cmbProduct.Items.Count > 0) cmbProduct.SelectedIndex = 0;

            if (presetProductId.HasValue)
            {
                for (int i = 0; i < cmbProduct.Items.Count; i++)
                {
                    if (((ProductItem)cmbProduct.Items[i]).Id == presetProductId.Value)
                    {
                        cmbProduct.SelectedIndex = i;
                        break;
                    }
                }
            }
        }

        private void AddRow(string caption, Control editor, ref int y)
        {
            Label lbl = new Label { Text = caption, Left = 15, Top = y + 4, Width = 140 };
            editor.SetBounds(165, y, 240, 26);
            Controls.Add(lbl);
            Controls.Add(editor);
            y += 40;
        }

        private void UpdateStockLabel()
        {
            ProductItem item = cmbProduct.SelectedItem as ProductItem;
            lblStock.Text = item == null ? "" : "Сейчас на складе: " + item.Quantity + " " + item.UnitName;
        }

        private void OnOk(object sender, EventArgs e)
        {
            ProductItem item = cmbProduct.SelectedItem as ProductItem;
            if (item == null)
            {
                MessageBox.Show(this, "Выберите товар. Если список пуст — сначала добавьте товар.",
                    Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int qty = (int)numQty.Value;
            if (!isIncome && qty > item.Quantity)
            {
                MessageBox.Show(this, "Недостаточно товара на складе. Доступно: " + item.Quantity + " " + item.UnitName + ".",
                    Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                Db.AddMovement(item.Id, isIncome ? Db.In : Db.Out, qty, dtpDate.Value,
                    txtCounterparty.Text.Trim(), txtNote.Text.Trim(), userId);
                DialogResult = DialogResult.OK;
            }
            catch (InvalidOperationException ex)
            {
                MessageBox.Show(this, ex.Message, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка при работе с базой данных:\n" + ex.Message,
                    Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
