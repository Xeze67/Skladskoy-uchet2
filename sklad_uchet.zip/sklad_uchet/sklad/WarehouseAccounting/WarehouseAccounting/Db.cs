using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.Diagnostics;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;

namespace WarehouseAccounting
{
    /// <summary>
    /// Полный слой доступа к базе данных Microsoft Access (поддерживает .accdb и .mdb).
    /// Автоматически определяет установленный в системе драйвер (ACE 16/15/14/12 или системный Jet 4.0).
    /// Если файл базы отсутствует, он извлекается из встроенных ресурсов без использования нестабильных COM/ADOX.
    /// Все SQL-запросы параметризованы и экранируют зарезервированные слова (включая [Note]).
    /// </summary>
    internal static class Db
    {
        public const string AccdbFileName = "WarehouseDB.accdb";

        public const string In = "IN";    // приход
        public const string Out = "OUT";  // расход

        private static readonly string[] AceProviders =
        {
            "Microsoft.ACE.OLEDB.16.0",
            "Microsoft.ACE.OLEDB.15.0",
            "Microsoft.ACE.OLEDB.14.0",
            "Microsoft.ACE.OLEDB.12.0"
        };

        private const string JetProvider = "Microsoft.Jet.OLEDB.4.0";

        private static string activeConnectionString;
        private static string activeProvider;
        private static string activeDbPath;
        private static string activeFormat;

        public static string ActiveProvider => activeProvider;
        public static string ActiveDbPath => activeDbPath;
        public static string ActiveFormat => activeFormat;

        public static string SingleDatabasePath
        {
            get
            {
                // 1. Поиск папки db\WarehouseDB.accdb вверх по дереву каталогов
                string search = AppDomain.CurrentDomain.BaseDirectory;
                for (int i = 0; i < 6; i++)
                {
                    string candidateInDb = Path.Combine(search, "db", AccdbFileName);
                    if (File.Exists(candidateInDb))
                    {
                        return Path.GetFullPath(candidateInDb);
                    }
                    DirectoryInfo parent = Directory.GetParent(search);
                    if (parent == null) break;
                    search = parent.FullName;
                }

                // 2. Абсолютный путь к единственной рабочей базе проекта
                string projectDb = @"c:\Users\грызлы 2.0\Desktop\sklad_uchet\sklad\WarehouseAccounting\db\WarehouseDB.accdb";
                if (File.Exists(projectDb))
                {
                    return projectDb;
                }

                // 3. Автономный запуск на другом ПК: рядом с exe в папке db или прямо в папке с exe
                string besideExeDb = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, "db", AccdbFileName);
                if (File.Exists(besideExeDb)) return besideExeDb;

                string besideExe = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, AccdbFileName);
                if (File.Exists(besideExe)) return besideExe;

                return projectDb;
            }
        }

        public static string BaseDirectory => Path.GetDirectoryName(SingleDatabasePath);

        private static string GetConfigPathFile()
        {
            return Path.Combine(
                Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
                "WarehouseAccounting", "last_db_path.txt");
        }

        public static string GetConfiguredDbPath()
        {
            return SingleDatabasePath;
        }

        public static void SaveConfiguredDbPath(string path)
        {
            try
            {
                string cfg = GetConfigPathFile();
                string dir = Path.GetDirectoryName(cfg);
                if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
                File.WriteAllText(cfg, path, Encoding.UTF8);
            }
            catch { }
        }

        // ───────────── Определение провайдера и подключение ─────────────

        /// <summary>
        /// Возвращает список всех доступных в системе провайдеров OLE DB для Access.
        /// </summary>
        public static List<string> GetInstalledAccessProviders()
        {
            var list = new List<string>();
            try
            {
                var enumerator = new OleDbEnumerator();
                DataTable dt = enumerator.GetElements();
                foreach (DataRow row in dt.Rows)
                {
                    string name = row["SOURCES_NAME"]?.ToString() ?? "";
                    if (name.StartsWith("Microsoft.ACE.OLEDB", StringComparison.OrdinalIgnoreCase) ||
                        name.StartsWith("Microsoft.Jet.OLEDB", StringComparison.OrdinalIgnoreCase))
                    {
                        if (!list.Contains(name)) list.Add(name);
                    }
                }
            }
            catch
            {
            }
            return list;
        }

        /// <summary>
        /// Проверяет, может ли данный провайдер реально открыть файл базы в текущем процессе.
        /// </summary>
        public static bool CanOpen(string provider, string dbPath)
        {
            if (string.IsNullOrEmpty(provider) || string.IsNullOrEmpty(dbPath) || !File.Exists(dbPath))
                return false;

            string cs = BuildConnectionString(provider, dbPath);
            try
            {
                using (var c = new OleDbConnection(cs))
                {
                    c.Open();
                    return true;
                }
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Проверяет, зарегистрирован и работоспособен ли провайдер в текущей разрядности процесса.
        /// </summary>
        public static bool IsProviderUsable(string provider)
        {
            if (string.IsNullOrEmpty(provider)) return false;

            List<string> installed = GetInstalledAccessProviders();
            if (installed.Contains(provider)) return true;

            // Если список пуст или драйвер не в списке, пробуем тестовое открытие фиктивного источника
            try
            {
                using (var c = new OleDbConnection($"Provider={provider};Data Source=nul;"))
                {
                    c.Open();
                    return true;
                }
            }
            catch (OleDbException ex)
            {
                // Если ошибка говорит "Cannot find file" или "Invalid file name", значит сам драйвер загрузился и работает!
                // Если же ошибка "Provider not registered", значит драйвера нет в текущей разрядности.
                string msg = ex.Message.ToLowerInvariant();
                if (msg.Contains("not registered") || msg.Contains("не зарегистрирован")) return false;
                return true;
            }
            catch
            {
                return false;
            }
        }

        /// <summary>
        /// Проверяет, доступен ли хоть один провайдер Access в текущем процессе.
        /// </summary>
        public static bool HasAnyProvider()
        {
            return FindBestProvider(out _, out _);
        }

        private static bool FindBestProvider(out string provider, out string preferredExtension)
        {
            List<string> installed = GetInstalledAccessProviders();

            // 1. Проверяем ACE провайдеры (поддерживают и .accdb, и .mdb)
            foreach (string p in AceProviders)
            {
                if (installed.Contains(p) || IsProviderUsable(p))
                {
                    provider = p;
                    preferredExtension = ".accdb";
                    return true;
                }
            }

            // 2. Проверяем системный Jet 4.0 (всегда есть на 32-битной Windows / SysWOW64)
            if (installed.Contains(JetProvider) || IsProviderUsable(JetProvider))
            {
                provider = JetProvider;
                preferredExtension = ".mdb";
                return true;
            }

            provider = null;
            preferredExtension = null;
            return false;
        }

        /// <summary>
        /// Проверяет, можно ли перезапуститься в 32-битном процессе, если 64-битный не нашёл ACE.
        /// </summary>
        public static bool CanRelaunchIn32Bit(out string x86ExePath)
        {
            x86ExePath = null;
            if (!Environment.Is64BitProcess) return false;

            string baseDir = AppDomain.CurrentDomain.BaseDirectory;
            string candidate = Path.Combine(baseDir, "WarehouseAccounting_x86.exe");
            if (File.Exists(candidate))
            {
                x86ExePath = candidate;
                return true;
            }
            return false;
        }

        private static string BuildConnectionString(string provider, string dbPath)
        {
            return $"Provider={provider};Data Source={dbPath};Mode=Share Deny None;Persist Security Info=False;";
        }

        public static bool SwitchDatabase(string newPath, out string error)
        {
            error = null;
            if (string.IsNullOrEmpty(newPath) || !File.Exists(newPath))
            {
                error = "Выбранный файл базы данных не существует.";
                return false;
            }

            string ext = Path.GetExtension(newPath).ToLowerInvariant();
            var providersToTry = new List<string>();
            if (ext == ".accdb")
            {
                providersToTry.AddRange(AceProviders);
            }
            else
            {
                providersToTry.AddRange(AceProviders);
                providersToTry.Add(JetProvider);
            }

            foreach (string p in providersToTry)
            {
                string cs = BuildConnectionString(p, newPath);
                try
                {
                    using (var c = new OleDbConnection(cs))
                    {
                        c.Open();
                        EnsureSchema(c);
                        activeConnectionString = cs;
                        activeProvider = p;
                        activeDbPath = newPath;
                        activeFormat = ext;
                        SaveConfiguredDbPath(newPath);
                        return true;
                    }
                }
                catch (Exception ex)
                {
                    error = ex.Message;
                }
            }

            return false;
        }

        private static OleDbConnection NewConnection()
        {
            if (activeConnectionString == null)
            {
                EnsureReady();
            }
            return new OleDbConnection(activeConnectionString);
        }

        // ───────────── Подготовка базы (EnsureReady) ─────────────

        /// <summary>
        /// Инициализирует подключение к базе данных Microsoft Access.
        /// Проверяет цепочку провайдеров (ACE 16/15/14/12 -> Jet 4.0).
        /// При необходимости автоматически извлекает нужный файл шаблона (.accdb или .mdb).
        /// </summary>
        public static void EnsureReady()
        {
            if (activeConnectionString != null) return;

            string targetPath = SingleDatabasePath;

            // Если файла базы нет, создаем каталог и извлекаем шаблон
            if (!File.Exists(targetPath))
            {
                string dir = Path.GetDirectoryName(targetPath);
                if (!Directory.Exists(dir)) Directory.CreateDirectory(dir);
                ExtractTemplate(AccdbFileName, targetPath);
            }

            Exception lastEx = null;
            foreach (string provider in AceProviders)
            {
                string cs = BuildConnectionString(provider, targetPath);
                try
                {
                    using (var c = new OleDbConnection(cs))
                    {
                        c.Open();
                        activeConnectionString = cs;
                        activeProvider = provider;
                        activeDbPath = targetPath;
                        activeFormat = ".accdb";

                        EnsureSchema(c);
                        SaveConfiguredDbPath(targetPath);
                        return;
                    }
                }
                catch (Exception ex)
                {
                    lastEx = ex;
                }
            }

            // Если ни один провайдер не подошёл:
            // В 64-битном процессе проверяем возможность прозрачного запуска 32-битной версии
            if (CanRelaunchIn32Bit(out string x86Exe))
            {
                var psi = new ProcessStartInfo
                {
                    FileName = x86Exe,
                    UseShellExecute = true
                };
                Process.Start(psi);
                Environment.Exit(0);
                return;
            }

            string arch = Environment.Is64BitProcess ? "64-бит (x64)" : "32-бит (x86)";
            throw new InvalidOperationException(
                $"Не удалось открыть единую базу данных Microsoft Access:\n{targetPath}\n\n" +
                $"Текущий режим программы: {arch}.\n" +
                $"Последняя ошибка: {lastEx?.Message}\n\n" +
                "Убедитесь, что установлен Microsoft Access Database Engine (ACE OLEDB).", lastEx);
        }

        /// <summary>
        /// Извлекает встроенную чистую заготовку базы данных или копирует из каталога программы.
        /// Не зависит от ADOX COM.
        /// </summary>
        private static void ExtractTemplate(string fileName, string targetPath)
        {
            string sourceCandidate = Path.Combine(AppDomain.CurrentDomain.BaseDirectory, fileName);
            if (File.Exists(sourceCandidate))
            {
                try
                {
                    File.Copy(sourceCandidate, targetPath, true);
                    return;
                }
                catch { }
            }

            // Извлечение из встроенных ресурсов
            Assembly asm = Assembly.GetExecutingAssembly();
            string resourceName = null;
            foreach (string name in asm.GetManifestResourceNames())
            {
                if (name.EndsWith(fileName, StringComparison.OrdinalIgnoreCase))
                {
                    resourceName = name;
                    break;
                }
            }

            if (resourceName != null)
            {
                using (Stream stream = asm.GetManifestResourceStream(resourceName))
                {
                    if (stream != null)
                    {
                        using (FileStream fs = File.Create(targetPath))
                        {
                            stream.CopyTo(fs);
                        }
                        return;
                    }
                }
            }

            // Если не найден ни ресурс, ни исходный файл — пробуем создать пустой через ADOX как последний рубеж
            CreateDatabaseViaAdoxFallback(targetPath);
        }

        private static void CreateDatabaseViaAdoxFallback(string targetPath)
        {
            string ext = Path.GetExtension(targetPath).ToLowerInvariant();
            string prov = ext == ".mdb" ? JetProvider : "Microsoft.ACE.OLEDB.12.0";

            Type adox = Type.GetTypeFromProgID("ADOX.Catalog");
            if (adox == null)
            {
                throw new InvalidOperationException(
                    $"Файл базы данных {Path.GetFileName(targetPath)} не найден, и встроенный шаблон отсутствует.\n" +
                    "Пожалуйста, поместите шаблон базы рядом с исполняемым файлом.");
            }

            object catalog = Activator.CreateInstance(adox);
            object conn = null;
            try
            {
                conn = adox.InvokeMember("Create", BindingFlags.InvokeMethod, null, catalog,
                    new object[] { BuildConnectionString(prov, targetPath) });
            }
            finally
            {
                if (conn != null)
                {
                    try { conn.GetType().InvokeMember("Close", BindingFlags.InvokeMethod, null, conn, null); }
                    catch { }
                    Marshal.ReleaseComObject(conn);
                }
                Marshal.ReleaseComObject(catalog);
            }
        }

        private static void EnsureSchema(OleDbConnection c)
        {
            string[] required = { "Users", "Categories", "Products", "Movements" };
            var missing = new List<string>();
            foreach (string table in required)
            {
                if (!TableExists(c, table)) missing.Add(table);
            }

            if (missing.Count == required.Length)
            {
                CreateSchema(c);
            }
            else if (missing.Count > 0)
            {
                // Если не хватает только некоторых таблиц (например, Movements из-за старой ошибки)
                CreateMissingTables(c, missing);
            }

            // Если таблица категорий пуста — заполняем базовыми категориями
            try
            {
                using (var cmd = new OleDbCommand("SELECT COUNT(*) FROM [Categories]", c))
                {
                    int catCount = ScalarInt(cmd);
                    if (catCount == 0)
                    {
                        foreach (string name in new[] { "Электроника", "Канцтовары", "Хозтовары", "Продукты", "Инструменты" })
                        {
                            using (var ins = new OleDbCommand("INSERT INTO [Categories] ([CategoryName]) VALUES (?)", c))
                            {
                                AddText(ins, name, 100);
                                ins.ExecuteNonQuery();
                            }
                        }
                    }
                }
            }
            catch { }
        }

        private static bool TableExists(OleDbConnection c, string name)
        {
            using (DataTable t = c.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, name, "TABLE" }))
            {
                return t != null && t.Rows.Count > 0;
            }
        }

        private static void Exec(OleDbConnection c, string sql)
        {
            using (var cmd = new OleDbCommand(sql, c))
            {
                cmd.ExecuteNonQuery();
            }
        }

        public static void CreateSchema(OleDbConnection c)
        {
            Exec(c, "CREATE TABLE [Users] (" +
                    "[Users_id] COUNTER PRIMARY KEY, " +
                    "[UserName] TEXT(50) NOT NULL, " +
                    "[PasswordHash] TEXT(255) NOT NULL, " +
                    "[UserRole] TEXT(20) NOT NULL)");
            Exec(c, "CREATE UNIQUE INDEX [ux_users_name] ON [Users] ([UserName])");

            Exec(c, "CREATE TABLE [Categories] (" +
                    "[Category_id] COUNTER PRIMARY KEY, " +
                    "[CategoryName] TEXT(100) NOT NULL)");
            Exec(c, "CREATE UNIQUE INDEX [ux_categories_name] ON [Categories] ([CategoryName])");

            Exec(c, "CREATE TABLE [Products] (" +
                    "[Product_id] COUNTER PRIMARY KEY, " +
                    "[Sku] TEXT(30) NOT NULL, " +
                    "[Title] TEXT(150) NOT NULL, " +
                    "[UnitName] TEXT(15) NOT NULL, " +
                    "[Category_ID] LONG, " +
                    "[Price] CURRENCY NOT NULL, " +
                    "[MinStock] LONG NOT NULL, " +
                    "[Quantity] LONG NOT NULL)");
            Exec(c, "CREATE UNIQUE INDEX [ux_products_sku] ON [Products] ([Sku])");

            Exec(c, "CREATE TABLE [Movements] (" +
                    "[Movement_id] COUNTER PRIMARY KEY, " +
                    "[Product_ID] LONG NOT NULL, " +
                    "[MoveType] TEXT(3) NOT NULL, " +
                    "[Qty] LONG NOT NULL, " +
                    "[MoveDate] DATETIME NOT NULL, " +
                    "[Counterparty] TEXT(150), " +
                    "[Note] TEXT(255), " +
                    "[User_ID] LONG NOT NULL)");

            try
            {
                Exec(c, "ALTER TABLE [Products] ADD CONSTRAINT [fk_products_category] " +
                        "FOREIGN KEY ([Category_ID]) REFERENCES [Categories] ([Category_id])");
            }
            catch { }

            try
            {
                Exec(c, "ALTER TABLE [Movements] ADD CONSTRAINT [fk_movements_product] " +
                        "FOREIGN KEY ([Product_ID]) REFERENCES [Products] ([Product_id])");
            }
            catch { }

            try
            {
                Exec(c, "ALTER TABLE [Movements] ADD CONSTRAINT [fk_movements_user] " +
                        "FOREIGN KEY ([User_ID]) REFERENCES [Users] ([Users_id])");
            }
            catch { }

            foreach (string name in new[] { "Электроника", "Канцтовары", "Хозтовары", "Продукты", "Инструменты" })
            {
                using (var cmd = new OleDbCommand("INSERT INTO [Categories] ([CategoryName]) VALUES (?)", c))
                {
                    AddText(cmd, name, 100);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        private static void CreateMissingTables(OleDbConnection c, List<string> missing)
        {
            if (missing.Contains("Users"))
            {
                Exec(c, "CREATE TABLE [Users] ([Users_id] COUNTER PRIMARY KEY, [UserName] TEXT(50) NOT NULL, [PasswordHash] TEXT(255) NOT NULL, [UserRole] TEXT(20) NOT NULL)");
                Exec(c, "CREATE UNIQUE INDEX [ux_users_name] ON [Users] ([UserName])");
            }

            if (missing.Contains("Categories"))
            {
                Exec(c, "CREATE TABLE [Categories] ([Category_id] COUNTER PRIMARY KEY, [CategoryName] TEXT(100) NOT NULL)");
                Exec(c, "CREATE UNIQUE INDEX [ux_categories_name] ON [Categories] ([CategoryName])");
                foreach (string name in new[] { "Электроника", "Канцтовары", "Хозтовары", "Продукты", "Инструменты" })
                {
                    using (var cmd = new OleDbCommand("INSERT INTO [Categories] ([CategoryName]) VALUES (?)", c))
                    {
                        AddText(cmd, name, 100);
                        cmd.ExecuteNonQuery();
                    }
                }
            }

            if (missing.Contains("Products"))
            {
                Exec(c, "CREATE TABLE [Products] ([Product_id] COUNTER PRIMARY KEY, [Sku] TEXT(30) NOT NULL, [Title] TEXT(150) NOT NULL, [UnitName] TEXT(15) NOT NULL, [Category_ID] LONG, [Price] CURRENCY NOT NULL, [MinStock] LONG NOT NULL, [Quantity] LONG NOT NULL)");
                Exec(c, "CREATE UNIQUE INDEX [ux_products_sku] ON [Products] ([Sku])");
            }

            if (missing.Contains("Movements"))
            {
                Exec(c, "CREATE TABLE [Movements] ([Movement_id] COUNTER PRIMARY KEY, [Product_ID] LONG NOT NULL, [MoveType] TEXT(3) NOT NULL, [Qty] LONG NOT NULL, [MoveDate] DATETIME NOT NULL, [Counterparty] TEXT(150), [Note] TEXT(255), [User_ID] LONG NOT NULL)");
            }
        }

        // ───────────── Помощники параметров ─────────────

        private static void AddText(OleDbCommand cmd, string value, int size)
        {
            var p = cmd.Parameters.Add("?", OleDbType.VarWChar, size);
            p.Value = string.IsNullOrEmpty(value) ? (object)DBNull.Value : value;
        }

        private static void AddInt(OleDbCommand cmd, int value)
        {
            cmd.Parameters.Add("?", OleDbType.Integer).Value = value;
        }

        private static void AddNullableInt(OleDbCommand cmd, int? value)
        {
            cmd.Parameters.Add("?", OleDbType.Integer).Value = value.HasValue ? (object)value.Value : DBNull.Value;
        }

        private static void AddCurrency(OleDbCommand cmd, decimal value)
        {
            cmd.Parameters.Add("?", OleDbType.Currency).Value = value;
        }

        private static void AddDate(OleDbCommand cmd, DateTime value)
        {
            cmd.Parameters.Add("?", OleDbType.Date).Value = value;
        }

        private static int ScalarInt(OleDbCommand cmd)
        {
            object o = cmd.ExecuteScalar();
            return (o == null || o == DBNull.Value) ? 0 : Convert.ToInt32(o);
        }

        // ───────────── Пользователи ─────────────

        public static int CountUsers()
        {
            using (var c = NewConnection())
            using (var cmd = new OleDbCommand("SELECT COUNT(*) FROM [Users]", c))
            {
                c.Open();
                return ScalarInt(cmd);
            }
        }

        public static UserRecord GetUser(string name)
        {
            using (var c = NewConnection())
            using (var cmd = new OleDbCommand(
                "SELECT [Users_id], [UserName], [PasswordHash], [UserRole] FROM [Users] WHERE [UserName] = ?", c))
            {
                AddText(cmd, name, 50);
                c.Open();
                using (var r = cmd.ExecuteReader())
                {
                    if (!r.Read()) return null;
                    return new UserRecord
                    {
                        Id = Convert.ToInt32(r.GetValue(0)),
                        Name = r.GetString(1),
                        Hash = r.GetString(2),
                        Role = r.GetString(3)
                    };
                }
            }
        }

        public static List<UserRecord> GetAllUsers()
        {
            var list = new List<UserRecord>();
            using (var c = NewConnection())
            using (var cmd = new OleDbCommand("SELECT [Users_id], [UserName], [PasswordHash], [UserRole] FROM [Users] ORDER BY [Users_id]", c))
            {
                c.Open();
                using (var r = cmd.ExecuteReader())
                {
                    while (r.Read())
                    {
                        list.Add(new UserRecord
                        {
                            Id = Convert.ToInt32(r.GetValue(0)),
                            Name = r.GetString(1),
                            Hash = r.GetString(2),
                            Role = r.GetString(3)
                        });
                    }
                }
            }
            return list;
        }

        public static int CreateUser(string name, string hash, string role)
        {
            using (var c = NewConnection())
            {
                c.Open();
                using (var cmd = new OleDbCommand(
                    "INSERT INTO [Users] ([UserName], [PasswordHash], [UserRole]) VALUES (?, ?, ?)", c))
                {
                    AddText(cmd, name, 50);
                    AddText(cmd, hash, 255);
                    AddText(cmd, role, 20);
                    cmd.ExecuteNonQuery();
                }
                using (var idCmd = new OleDbCommand("SELECT @@IDENTITY", c))
                {
                    return ScalarInt(idCmd);
                }
            }
        }

        public static void UpdateUserRole(int userId, string role)
        {
            using (var c = NewConnection())
            using (var cmd = new OleDbCommand("UPDATE [Users] SET [UserRole] = ? WHERE [Users_id] = ?", c))
            {
                AddText(cmd, role, 20);
                AddInt(cmd, userId);
                c.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public static void UpdateUserPassword(int userId, string hash)
        {
            using (var c = NewConnection())
            using (var cmd = new OleDbCommand("UPDATE [Users] SET [PasswordHash] = ? WHERE [Users_id] = ?", c))
            {
                AddText(cmd, hash, 255);
                AddInt(cmd, userId);
                c.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public static void DeleteUser(int userId)
        {
            using (var c = NewConnection())
            using (var cmd = new OleDbCommand("DELETE FROM [Users] WHERE [Users_id] = ?", c))
            {
                AddInt(cmd, userId);
                c.Open();
                cmd.ExecuteNonQuery();
            }
        }

        // ───────────── Категории ─────────────

        public static List<Category> GetCategories()
        {
            var list = new List<Category>();
            using (var c = NewConnection())
            using (var cmd = new OleDbCommand("SELECT [Category_id], [CategoryName] FROM [Categories] ORDER BY [CategoryName]", c))
            {
                c.Open();
                using (var r = cmd.ExecuteReader())
                {
                    while (r.Read()) list.Add(new Category(Convert.ToInt32(r.GetValue(0)), r.GetString(1)));
                }
            }
            return list;
        }

        public static bool CategoryNameExists(string name, int exceptId)
        {
            using (var c = NewConnection())
            using (var cmd = new OleDbCommand(
                "SELECT COUNT(*) FROM [Categories] WHERE [CategoryName] = ? AND [Category_id] <> ?", c))
            {
                AddText(cmd, name, 100);
                AddInt(cmd, exceptId);
                c.Open();
                return ScalarInt(cmd) > 0;
            }
        }

        public static void AddCategory(string name)
        {
            using (var c = NewConnection())
            using (var cmd = new OleDbCommand("INSERT INTO [Categories] ([CategoryName]) VALUES (?)", c))
            {
                AddText(cmd, name, 100);
                c.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public static void RenameCategory(int id, string name)
        {
            using (var c = NewConnection())
            using (var cmd = new OleDbCommand("UPDATE [Categories] SET [CategoryName] = ? WHERE [Category_id] = ?", c))
            {
                AddText(cmd, name, 100);
                AddInt(cmd, id);
                c.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public static int CategoryProductCount(int id)
        {
            using (var c = NewConnection())
            using (var cmd = new OleDbCommand("SELECT COUNT(*) FROM [Products] WHERE [Category_ID] = ?", c))
            {
                AddInt(cmd, id);
                c.Open();
                return ScalarInt(cmd);
            }
        }

        public static void DeleteCategory(int id)
        {
            using (var c = NewConnection())
            {
                c.Open();
                using (var tx = c.BeginTransaction())
                {
                    try
                    {
                        // Снимаем привязку категории с товаров
                        using (var cmdUnlink = new OleDbCommand("UPDATE [Products] SET [Category_ID] = NULL WHERE [Category_ID] = ?", c, tx))
                        {
                            AddInt(cmdUnlink, id);
                            cmdUnlink.ExecuteNonQuery();
                        }

                        // Удаляем категорию
                        using (var cmd = new OleDbCommand("DELETE FROM [Categories] WHERE [Category_id] = ?", c, tx))
                        {
                            AddInt(cmd, id);
                            cmd.ExecuteNonQuery();
                        }

                        tx.Commit();
                    }
                    catch
                    {
                        tx.Rollback();
                        throw;
                    }
                }
            }
        }

        // ───────────── Товары ─────────────

        public static DataTable GetProducts(string search, int? categoryId, bool lowOnly)
        {
            var sql = new StringBuilder(
                "SELECT p.[Product_id], p.[Sku], p.[Title], c.[CategoryName], p.[UnitName], p.[Price], " +
                "p.[Quantity], p.[MinStock], p.[Price] * p.[Quantity] AS Total " +
                "FROM [Products] AS p LEFT JOIN [Categories] AS c ON p.[Category_ID] = c.[Category_id] WHERE 1 = 1");

            var table = new DataTable();
            using (var c = NewConnection())
            using (var cmd = new OleDbCommand())
            {
                cmd.Connection = c;

                if (!string.IsNullOrWhiteSpace(search))
                {
                    sql.Append(" AND (p.[Title] LIKE ? OR p.[Sku] LIKE ?)");
                    string pattern = "%" + search.Trim() + "%";
                    AddText(cmd, pattern, 160);
                    AddText(cmd, pattern, 160);
                }
                if (categoryId.HasValue)
                {
                    sql.Append(" AND p.[Category_ID] = ?");
                    AddInt(cmd, categoryId.Value);
                }
                if (lowOnly)
                {
                    sql.Append(" AND p.[Quantity] <= p.[MinStock]");
                }
                sql.Append(" ORDER BY p.[Title]");

                cmd.CommandText = sql.ToString();
                using (var adapter = new OleDbDataAdapter(cmd))
                {
                    adapter.Fill(table);
                }
            }
            return table;
        }

        public static ProductData GetProduct(int id)
        {
            using (var c = NewConnection())
            using (var cmd = new OleDbCommand(
                "SELECT [Product_id], [Sku], [Title], [UnitName], [Category_ID], [Price], [MinStock], [Quantity] " +
                "FROM [Products] WHERE [Product_id] = ?", c))
            {
                AddInt(cmd, id);
                c.Open();
                using (var r = cmd.ExecuteReader())
                {
                    if (!r.Read()) return null;
                    return new ProductData
                    {
                        Id = Convert.ToInt32(r.GetValue(0)),
                        Sku = r.GetString(1),
                        Title = r.GetString(2),
                        UnitName = r.GetString(3),
                        CategoryId = r.IsDBNull(4) ? (int?)null : Convert.ToInt32(r.GetValue(4)),
                        Price = Convert.ToDecimal(r.GetValue(5)),
                        MinStock = Convert.ToInt32(r.GetValue(6)),
                        Quantity = Convert.ToInt32(r.GetValue(7))
                    };
                }
            }
        }

        public static List<ProductItem> GetProductItems()
        {
            var list = new List<ProductItem>();
            using (var c = NewConnection())
            using (var cmd = new OleDbCommand(
                "SELECT [Product_id], [Sku], [Title], [UnitName], [Quantity] FROM [Products] ORDER BY [Title]", c))
            {
                c.Open();
                using (var r = cmd.ExecuteReader())
                {
                    while (r.Read())
                    {
                        list.Add(new ProductItem
                        {
                            Id = Convert.ToInt32(r.GetValue(0)),
                            Display = r.GetString(1) + " — " + r.GetString(2),
                            UnitName = r.GetString(3),
                            Quantity = Convert.ToInt32(r.GetValue(4))
                        });
                    }
                }
            }
            return list;
        }

        public static bool SkuExists(string sku, int exceptId)
        {
            using (var c = NewConnection())
            using (var cmd = new OleDbCommand(
                "SELECT COUNT(*) FROM [Products] WHERE [Sku] = ? AND [Product_id] <> ?", c))
            {
                AddText(cmd, sku, 30);
                AddInt(cmd, exceptId);
                c.Open();
                return ScalarInt(cmd) > 0;
            }
        }

        public static int AddProduct(ProductData p)
        {
            using (var c = NewConnection())
            {
                c.Open();
                using (var cmd = new OleDbCommand(
                    "INSERT INTO [Products] ([Sku], [Title], [UnitName], [Category_ID], [Price], [MinStock], [Quantity]) " +
                    "VALUES (?, ?, ?, ?, ?, ?, 0)", c))
                {
                    AddText(cmd, p.Sku, 30);
                    AddText(cmd, p.Title, 150);
                    AddText(cmd, p.UnitName, 15);
                    AddNullableInt(cmd, p.CategoryId);
                    AddCurrency(cmd, p.Price);
                    AddInt(cmd, p.MinStock);
                    cmd.ExecuteNonQuery();
                }
                using (var idCmd = new OleDbCommand("SELECT @@IDENTITY", c))
                {
                    return ScalarInt(idCmd);
                }
            }
        }

        public static void UpdateProduct(ProductData p)
        {
            using (var c = NewConnection())
            using (var cmd = new OleDbCommand(
                "UPDATE [Products] SET [Sku] = ?, [Title] = ?, [UnitName] = ?, [Category_ID] = ?, [Price] = ?, [MinStock] = ? " +
                "WHERE [Product_id] = ?", c))
            {
                AddText(cmd, p.Sku, 30);
                AddText(cmd, p.Title, 150);
                AddText(cmd, p.UnitName, 15);
                AddNullableInt(cmd, p.CategoryId);
                AddCurrency(cmd, p.Price);
                AddInt(cmd, p.MinStock);
                AddInt(cmd, p.Id);
                c.Open();
                cmd.ExecuteNonQuery();
            }
        }

        /// <summary>
        /// Сохраняет все изменённые строки таблицы товаров напрямую в базу данных Microsoft Access.
        /// Возвращает количество сохранённых записей.
        /// </summary>
        public static int SaveProductChanges(DataTable table)
        {
            if (table == null) return 0;

            var categories = GetCategories();
            var catMap = new Dictionary<string, int>(StringComparer.OrdinalIgnoreCase);
            foreach (var c in categories) catMap[c.Name] = c.Id;

            int updatedCount = 0;

            using (var conn = NewConnection())
            {
                conn.Open();
                using (var tx = conn.BeginTransaction())
                {
                    foreach (DataRow row in table.Rows)
                    {
                        if (row.RowState == DataRowState.Deleted) continue;
                        if (row.RowState == DataRowState.Modified)
                        {
                            int id = Convert.ToInt32(row["Product_id"]);
                            string sku = Convert.ToString(row["Sku"]).Trim();
                            string title = Convert.ToString(row["Title"]).Trim();
                            string unit = Convert.ToString(row["UnitName"]).Trim();
                            decimal price = Convert.ToDecimal(row["Price"]);
                            int minStock = Convert.ToInt32(row["MinStock"]);
                            string catName = Convert.ToString(row["CategoryName"]).Trim();

                            int? catId = null;
                            if (!string.IsNullOrEmpty(catName))
                            {
                                if (catMap.TryGetValue(catName, out int foundId))
                                {
                                    catId = foundId;
                                }
                                else
                                {
                                    using (var cmdCat = new OleDbCommand("INSERT INTO [Categories] ([CategoryName]) VALUES (?)", conn, tx))
                                    {
                                        cmdCat.Parameters.Add("?", OleDbType.VarWChar, 100).Value = catName;
                                        cmdCat.ExecuteNonQuery();
                                    }
                                    using (var idCmd = new OleDbCommand("SELECT @@IDENTITY", conn, tx))
                                    {
                                        int newCatId = ScalarInt(idCmd);
                                        catMap[catName] = newCatId;
                                        catId = newCatId;
                                    }
                                }
                            }

                            using (var cmd = new OleDbCommand(
                                "UPDATE [Products] SET [Sku] = ?, [Title] = ?, [UnitName] = ?, [Category_ID] = ?, [Price] = ?, [MinStock] = ? " +
                                "WHERE [Product_id] = ?", conn, tx))
                            {
                                AddText(cmd, sku, 30);
                                AddText(cmd, title, 150);
                                AddText(cmd, unit, 15);
                                AddNullableInt(cmd, catId);
                                AddCurrency(cmd, price);
                                AddInt(cmd, minStock);
                                AddInt(cmd, id);
                                cmd.ExecuteNonQuery();
                            }

                            updatedCount++;
                        }
                    }

                    tx.Commit();
                }
            }

            table.AcceptChanges();
            return updatedCount;
        }

        public static int MovementCountForProduct(int productId)
        {
            using (var c = NewConnection())
            using (var cmd = new OleDbCommand("SELECT COUNT(*) FROM [Movements] WHERE [Product_ID] = ?", c))
            {
                AddInt(cmd, productId);
                c.Open();
                return ScalarInt(cmd);
            }
        }

        public static void DeleteProduct(int id)
        {
            using (var c = NewConnection())
            {
                c.Open();
                using (var tx = c.BeginTransaction())
                {
                    try
                    {
                        // 1. Удаляем все движения по данному товару
                        using (var cmdMove = new OleDbCommand("DELETE FROM [Movements] WHERE [Product_ID] = ?", c, tx))
                        {
                            AddInt(cmdMove, id);
                            cmdMove.ExecuteNonQuery();
                        }

                        // 2. Удаляем сам товар
                        using (var cmdProd = new OleDbCommand("DELETE FROM [Products] WHERE [Product_id] = ?", c, tx))
                        {
                            AddInt(cmdProd, id);
                            cmdProd.ExecuteNonQuery();
                        }

                        tx.Commit();
                    }
                    catch
                    {
                        tx.Rollback();
                        throw;
                    }
                }
            }
        }

        // ───────────── Движения (приход / расход) ─────────────

        public static void AddMovement(int productId, string type, int qty, DateTime date,
                                       string counterparty, string note, int userId)
        {
            if (type != In && type != Out) throw new ArgumentException("Неизвестный тип движения.");
            if (qty <= 0) throw new InvalidOperationException("Количество должно быть больше нуля.");

            using (var c = NewConnection())
            {
                c.Open();
                using (OleDbTransaction tx = c.BeginTransaction())
                {
                    int current;
                    using (var q = new OleDbCommand("SELECT [Quantity] FROM [Products] WHERE [Product_id] = ?", c, tx))
                    {
                        AddInt(q, productId);
                        object o = q.ExecuteScalar();
                        if (o == null || o == DBNull.Value) throw new InvalidOperationException("Товар не найден.");
                        current = Convert.ToInt32(o);
                    }

                    if (type == Out && qty > current)
                    {
                        throw new InvalidOperationException(
                            $"Недостаточно товара на складе. Доступно: {current}, запрошено: {qty}.");
                    }

                    int updated = type == In ? current + qty : current - qty;

                    using (var ins = new OleDbCommand(
                        "INSERT INTO [Movements] ([Product_ID], [MoveType], [Qty], [MoveDate], [Counterparty], [Note], [User_ID]) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?)", c, tx))
                    {
                        AddInt(ins, productId);
                        AddText(ins, type, 3);
                        AddInt(ins, qty);
                        AddDate(ins, date);
                        AddText(ins, counterparty, 150);
                        AddText(ins, note, 255);
                        AddInt(ins, userId);
                        ins.ExecuteNonQuery();
                    }

                    using (var upd = new OleDbCommand("UPDATE [Products] SET [Quantity] = ? WHERE [Product_id] = ?", c, tx))
                    {
                        AddInt(upd, updated);
                        AddInt(upd, productId);
                        upd.ExecuteNonQuery();
                    }

                    tx.Commit();
                }
            }
        }

        public static DataTable GetMovements(DateTime from, DateTime to, string type, int? productId = null)
        {
            var sql = new StringBuilder(
                "SELECT m.[Movement_id], m.[MoveDate], p.[Sku], p.[Title], " +
                "IIF(m.[MoveType] = 'IN', 'Приход', 'Расход') AS TypeName, " +
                "m.[Qty], m.[Counterparty], m.[Note], u.[UserName] " +
                "FROM ([Movements] AS m INNER JOIN [Products] AS p ON m.[Product_ID] = p.[Product_id]) " +
                "INNER JOIN [Users] AS u ON m.[User_ID] = u.[Users_id] " +
                "WHERE m.[MoveDate] >= ? AND m.[MoveDate] <= ?");

            var table = new DataTable();
            using (var c = NewConnection())
            using (var cmd = new OleDbCommand())
            {
                cmd.Connection = c;
                AddDate(cmd, from);
                AddDate(cmd, to);
                if (type != null)
                {
                    sql.Append(" AND m.[MoveType] = ?");
                    AddText(cmd, type, 3);
                }
                if (productId.HasValue)
                {
                    sql.Append(" AND m.[Product_ID] = ?");
                    AddInt(cmd, productId.Value);
                }
                sql.Append(" ORDER BY m.[MoveDate] DESC, m.[Movement_id] DESC");

                cmd.CommandText = sql.ToString();
                using (var adapter = new OleDbDataAdapter(cmd))
                {
                    adapter.Fill(table);
                }
            }
            return table;
        }

        public static int[] GetTurnover(DateTime from, DateTime to)
        {
            int[] result = new int[2];
            using (var c = NewConnection())
            using (var cmd = new OleDbCommand(
                "SELECT [MoveType], SUM([Qty]) FROM [Movements] WHERE [MoveDate] >= ? AND [MoveDate] <= ? GROUP BY [MoveType]", c))
            {
                AddDate(cmd, from);
                AddDate(cmd, to);
                c.Open();
                using (var r = cmd.ExecuteReader())
                {
                    while (r.Read())
                    {
                        int sum = r.IsDBNull(1) ? 0 : Convert.ToInt32(r.GetValue(1));
                        string mtype = r.GetString(0);
                        if (mtype == In) result[0] = sum;
                        else if (mtype == Out) result[1] = sum;
                    }
                }
            }
            return result;
        }

        // ───────────── Диагностика и резервное копирование ─────────────

        public static string GetDiagnosticInfo()
        {
            var sb = new StringBuilder();
            sb.AppendLine("=== ДИАГНОСТИКА БАЗЫ ДАННЫХ И СИСТЕМЫ ===");
            sb.AppendLine($"ОС: {Environment.OSVersion} ({(Environment.Is64BitOperatingSystem ? "64-bit OS" : "32-bit OS")})");
            sb.AppendLine($"Процесс приложения: {(Environment.Is64BitProcess ? "64-bit (x64)" : "32-bit (x86)")}");
            sb.AppendLine($".NET Framework: {Environment.Version}");
            sb.AppendLine($"Каталог базы данных: {BaseDirectory}");
            sb.AppendLine($"Активный файл БД: {ActiveDbPath ?? "(не подключено)"}");
            if (File.Exists(ActiveDbPath))
            {
                var fi = new FileInfo(ActiveDbPath);
                sb.AppendLine($"Размер файла БД: {fi.Length / 1024} КБ");
            }
            sb.AppendLine($"Формат: {ActiveFormat ?? "(неизвестно)"}");
            sb.AppendLine($"Активный OLE DB провайдер: {ActiveProvider ?? "(нет)"}");
            sb.AppendLine();
            sb.AppendLine("Установленные Access/Jet OLE DB провайдеры в текущей разрядности:");
            List<string> providers = GetInstalledAccessProviders();
            if (providers.Count == 0) sb.AppendLine("  (не обнаружено)");
            else foreach (string p in providers) sb.AppendLine($"  - {p}");

            sb.AppendLine();
            sb.AppendLine("Статистика базы данных:");
            try
            {
                using (var c = NewConnection())
                {
                    c.Open();
                    sb.AppendLine($"  - Пользователей: {CountUsers()}");
                    sb.AppendLine($"  - Категорий: {GetCategories().Count}");
                    using (var cmd = new OleDbCommand("SELECT COUNT(*) FROM [Products]", c))
                        sb.AppendLine($"  - Товаров в базе: {ScalarInt(cmd)}");
                    using (var cmd = new OleDbCommand("SELECT COUNT(*) FROM [Movements]", c))
                        sb.AppendLine($"  - Записей движений: {ScalarInt(cmd)}");
                }
                sb.AppendLine("Состояние БД: ОК (все таблицы и внешние ключи активны)");
            }
            catch (Exception ex)
            {
                sb.AppendLine($"Ошибка проверки таблиц: {ex.Message}");
            }

            return sb.ToString();
        }

        public static void BackupDatabase(string targetPath)
        {
            if (string.IsNullOrEmpty(ActiveDbPath) || !File.Exists(ActiveDbPath))
                throw new InvalidOperationException("Файл базы данных не найден.");

            // Принудительно очищаем пулы подключений, чтобы записать все несохранённые страницы на диск
            OleDbConnection.ReleaseObjectPool();
            File.Copy(ActiveDbPath, targetPath, true);
        }

        // ───────────── Демонстрационные данные ─────────────

        public static void SeedDemoData(int userId)
        {
            Category[] cats = GetCategories().ToArray();
            Func<string, int?> catId = name =>
            {
                foreach (Category c in cats) if (c.Name == name) return c.Id;
                return (int?)null;
            };

            var demo = new[]
            {
                new { Sku = "EL-001", Title = "USB-флешка 32 ГБ",         Unit = "шт", Cat = "Электроника", Price = 450m, Min = 10, Qty = 40  },
                new { Sku = "EL-002", Title = "Мышь беспроводная",        Unit = "шт", Cat = "Электроника", Price = 890m, Min = 5,  Qty = 3   },
                new { Sku = "ST-001", Title = "Бумага А4, 500 листов",    Unit = "уп", Cat = "Канцтовары",  Price = 380m, Min = 10, Qty = 25  },
                new { Sku = "ST-002", Title = "Ручка шариковая синяя",    Unit = "шт", Cat = "Канцтовары",  Price = 25m,  Min = 50, Qty = 200 },
                new { Sku = "HZ-001", Title = "Мешки для мусора 60 л",    Unit = "уп", Cat = "Хозтовары",   Price = 120m, Min = 10, Qty = 8   },
                new { Sku = "TL-001", Title = "Набор отвёрток (6 шт.)",   Unit = "набор", Cat = "Инструменты", Price = 650m, Min = 3, Qty = 12 }
            };

            foreach (var d in demo)
            {
                int id = AddProduct(new ProductData
                {
                    Sku = d.Sku,
                    Title = d.Title,
                    UnitName = d.Unit,
                    CategoryId = catId(d.Cat),
                    Price = d.Price,
                    MinStock = d.Min
                });
                AddMovement(id, In, d.Qty, DateTime.Now.AddDays(-7), "Начальный остаток", "Демо-данные", userId);
            }
        }
    }
}
