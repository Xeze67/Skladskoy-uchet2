using System;
using System.Diagnostics;
using System.IO;
using System.Windows.Forms;

namespace WarehouseAccounting
{
    internal static class Program
    {
        /// <summary>
        /// Главная точка входа для приложения.
        /// Обеспечивает безопасную инициализацию базы Access с автоопределением драйверов,
        /// автоперезапуском при несовпадении разрядности и циклом авторизации.
        /// </summary>
        [STAThread]
        static void Main(string[] args)
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            // Если процесс запущен в 64-битном режиме, но в системе нет 64-битного ACE OLEDB,
            // а рядом есть 32-битный бинарник WarehouseAccounting_x86.exe — прозрачно запускаем его.
            if (Environment.Is64BitProcess && !Db.HasAnyProvider())
            {
                if (Db.CanRelaunchIn32Bit(out string x86Exe))
                {
                    try
                    {
                        var p = Process.Start(new ProcessStartInfo
                        {
                            FileName = x86Exe,
                            Arguments = string.Join(" ", args),
                            UseShellExecute = true
                        });
                        return;
                    }
                    catch { }
                }
            }

            try
            {
                Db.EnsureReady();
            }
            catch (Exception ex)
            {
                string msg = ex.Message + "\n\nДетали ошибки:\n" + ex.InnerException?.Message;
                MessageBox.Show(msg, "Складской учёт — Ошибка инициализации БД", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            while (true)
            {
                UserRecord user;
                using (var login = new LoginForm())
                {
                    if (login.ShowDialog() != DialogResult.OK) return;
                    user = login.User;
                }

                bool logout;
                using (var main = new MainForm(user))
                {
                    Application.Run(main);
                    logout = main.LogoutRequested;
                }

                if (!logout) return;
            }
        }
    }
}
