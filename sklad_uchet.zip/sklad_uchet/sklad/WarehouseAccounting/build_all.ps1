# Скрипт полной сборки всех конфигураций проекта «Складской учёт (Microsoft Access)»
$ErrorActionPreference = "Stop"

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location $scriptDir

$proj = Join-Path $scriptDir "WarehouseAccounting\WarehouseAccounting.csproj"
$outDir = Join-Path $scriptDir "bin\Release"
if (-not (Test-Path $outDir)) { New-Item -ItemType Directory -Path $outDir | Out-Null }

Write-Host "1/3. Сборка AnyCPU..."
dotnet build $proj -c Release -p:PlatformTarget=AnyCPU
Copy-Item (Join-Path $scriptDir "WarehouseAccounting\bin\Release\net472\WarehouseAccounting.exe") (Join-Path $outDir "WarehouseAccounting.exe") -Force
Copy-Item (Join-Path $scriptDir "WarehouseAccounting\bin\Release\net472\WarehouseAccounting.exe.config") (Join-Path $outDir "WarehouseAccounting.exe.config") -Force

Write-Host "2/3. Сборка x86..."
dotnet build $proj -c Release -p:PlatformTarget=x86
Copy-Item (Join-Path $scriptDir "WarehouseAccounting\bin\Release\net472\WarehouseAccounting.exe") (Join-Path $outDir "WarehouseAccounting_x86.exe") -Force

Write-Host "3/3. Сборка x64..."
dotnet build $proj -c Release -p:PlatformTarget=x64
Copy-Item (Join-Path $scriptDir "WarehouseAccounting\bin\Release\net472\WarehouseAccounting.exe") (Join-Path $outDir "WarehouseAccounting_x64.exe") -Force

# База данных используется только одна: в папке db\WarehouseDB.accdb
# Релиз собран успешно

Write-Host "Сборка завершена успешно! Файлы готовы в: $outDir"
Get-ChildItem $outDir | Select-Object Name, Length
