-- Схема базы данных WarehouseDB.accdb (Microsoft Access, диалект Jet/ACE SQL)
-- Приложение создаёт этот файл и таблицы автоматически при первом запуске (Db.EnsureReady).
-- Скрипт приведён для справки и для ручного создания базы в Access.

CREATE TABLE Users (
    Users_id      COUNTER PRIMARY KEY,
    UserName      TEXT(50)  NOT NULL,
    PasswordHash  TEXT(255) NOT NULL,      -- pbkdf2$итерации$соль$хеш
    UserRole      TEXT(20)  NOT NULL       -- «Администратор» | «Кладовщик»
);
CREATE UNIQUE INDEX ux_users_name ON Users (UserName);

CREATE TABLE Categories (
    Category_id   COUNTER PRIMARY KEY,
    CategoryName  TEXT(100) NOT NULL
);
CREATE UNIQUE INDEX ux_categories_name ON Categories (CategoryName);

CREATE TABLE Products (
    Product_id    COUNTER PRIMARY KEY,
    Sku           TEXT(30)  NOT NULL,      -- артикул
    Title         TEXT(150) NOT NULL,
    UnitName      TEXT(15)  NOT NULL,      -- шт, уп, кг ...
    Category_ID   LONG,                    -- может быть пустым
    Price         CURRENCY  NOT NULL,
    MinStock      LONG      NOT NULL,      -- порог «низкого остатка»
    Quantity      LONG      NOT NULL       -- текущий остаток, меняется только движениями
);
CREATE UNIQUE INDEX ux_products_sku ON Products (Sku);

CREATE TABLE Movements (
    Movement_id   COUNTER PRIMARY KEY,
    Product_ID    LONG      NOT NULL,
    MoveType      TEXT(3)   NOT NULL,      -- 'IN' приход | 'OUT' расход
    Qty           LONG      NOT NULL,      -- всегда > 0
    MoveDate      DATETIME  NOT NULL,
    Counterparty  TEXT(150),               -- поставщик / получатель
    Note          TEXT(255),
    User_ID       LONG      NOT NULL
);

ALTER TABLE Products  ADD CONSTRAINT fk_products_category FOREIGN KEY (Category_ID) REFERENCES Categories (Category_id);
ALTER TABLE Movements ADD CONSTRAINT fk_movements_product FOREIGN KEY (Product_ID)  REFERENCES Products (Product_id);
ALTER TABLE Movements ADD CONSTRAINT fk_movements_user    FOREIGN KEY (User_ID)     REFERENCES Users (Users_id);

-- Начальные категории
INSERT INTO Categories (CategoryName) VALUES ('Электроника');
INSERT INTO Categories (CategoryName) VALUES ('Канцтовары');
INSERT INTO Categories (CategoryName) VALUES ('Хозтовары');
INSERT INTO Categories (CategoryName) VALUES ('Продукты');
