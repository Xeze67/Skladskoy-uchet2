﻿using System;
using System.Windows.Forms;

namespace WarehouseAccounting
{
    internal static class Program
    {
        /// <summary>
        /// Точка входа. Подготовка БД → вход → главное окно → (по «Сменить пользователя») снова вход.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);

            try
            {
                Db.EnsureReady();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Складской учёт", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            while (true)
            {
                UserRecord user;
                using (var login = new LoginForm())
                {
                    if (login.ShowDialog() != DialogResult.OK) return;
                    user = login.User;
                }

                bool logout;
                using (var main = new MainForm(user))
                {
                    Application.Run(main);
                    logout = main.LogoutRequested;
                }

                if (!logout) return;
            }
        }
    }
}
