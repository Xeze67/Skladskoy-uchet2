﻿using System;
using System.Drawing;
using System.Windows.Forms;

namespace WarehouseAccounting
{
    /// <summary>Окно входа и регистрации. Первый зарегистрированный пользователь становится администратором.</summary>
    internal sealed class LoginForm : Form
    {
        private const int MaxAttempts = 5;

        private readonly Label lblTitle = new Label();
        private readonly Label lblInfo = new Label();
        private readonly Label lblName = new Label();
        private readonly Label lblPass = new Label();
        private readonly Label lblConfirm = new Label();
        private readonly TextBox txtName = new TextBox();
        private readonly TextBox txtPass = new TextBox();
        private readonly TextBox txtConfirm = new TextBox();
        private readonly Button btnPrimary = new Button();
        private readonly Button btnSwitch = new Button();

        private bool registerMode;
        private bool firstRun;
        private int failedAttempts;

        public UserRecord User { get; private set; }

        public LoginForm()
        {
            Text = "Складской учёт — вход";
            Font = new Font("Segoe UI", 9.5f);
            FormBorderStyle = FormBorderStyle.FixedDialog;
            MaximizeBox = false;
            MinimizeBox = false;
            StartPosition = FormStartPosition.CenterScreen;
            ClientSize = new Size(380, 330);

            lblTitle.Text = "Складской учёт";
            lblTitle.Font = new Font("Segoe UI", 16f, FontStyle.Bold);
            lblTitle.SetBounds(20, 15, 340, 34);

            lblInfo.SetBounds(20, 55, 340, 40);
            lblInfo.ForeColor = Color.DimGray;

            lblName.Text = "Имя пользователя";
            lblName.SetBounds(20, 105, 340, 20);
            txtName.SetBounds(20, 127, 340, 26);
            txtName.MaxLength = 50;

            lblPass.Text = "Пароль";
            lblPass.SetBounds(20, 160, 340, 20);
            txtPass.SetBounds(20, 182, 340, 26);
            txtPass.UseSystemPasswordChar = true;
            txtPass.MaxLength = 128;

            lblConfirm.Text = "Повторите пароль";
            lblConfirm.SetBounds(20, 215, 340, 20);
            txtConfirm.SetBounds(20, 237, 340, 26);
            txtConfirm.UseSystemPasswordChar = true;
            txtConfirm.MaxLength = 128;

            btnPrimary.SetBounds(20, 280, 200, 34);
            btnPrimary.Click += OnPrimaryClick;

            btnSwitch.SetBounds(230, 280, 130, 34);
            btnSwitch.Click += delegate { SetMode(!registerMode); };

            Controls.AddRange(new Control[]
            {
                lblTitle, lblInfo, lblName, txtName, lblPass, txtPass,
                lblConfirm, txtConfirm, btnPrimary, btnSwitch
            });
            AcceptButton = btnPrimary;

            firstRun = Db.CountUsers() == 0;
            SetMode(firstRun);
        }

        private void SetMode(bool register)
        {
            registerMode = register;
            lblConfirm.Visible = register;
            txtConfirm.Visible = register;
            txtPass.Text = "";
            txtConfirm.Text = "";

            if (register)
            {
                btnPrimary.Text = "Зарегистрироваться";
                btnSwitch.Text = "Ко входу";
                btnSwitch.Visible = !firstRun;
                lblInfo.Text = firstRun
                    ? "Первый запуск: создайте учётную запись администратора."
                    : "Новая учётная запись получит роль «Кладовщик».";
                ClientSize = new Size(380, 330);
            }
            else
            {
                btnPrimary.Text = "Войти";
                btnSwitch.Text = "Регистрация";
                btnSwitch.Visible = true;
                lblInfo.Text = "Введите имя пользователя и пароль.";
                ClientSize = new Size(380, 280);
                btnPrimary.Top = 230;
                btnSwitch.Top = 230;
            }

            if (register)
            {
                btnPrimary.Top = 280;
                btnSwitch.Top = 280;
            }
            txtName.Focus();
        }

        private void OnPrimaryClick(object sender, EventArgs e)
        {
            try
            {
                if (registerMode) DoRegister();
                else DoLogin();
            }
            catch (Exception ex)
            {
                MessageBox.Show(this, "Ошибка при работе с базой данных:\n" + ex.Message,
                    Text, MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void DoLogin()
        {
            string name = txtName.Text.Trim();
            UserRecord user = name.Length == 0 ? null : Db.GetUser(name);

            if (user == null || !CryptoHelper.Verify(txtPass.Text, user.Hash))
            {
                failedAttempts++;
                if (failedAttempts >= MaxAttempts)
                {
                    MessageBox.Show(this, "Слишком много неудачных попыток входа. Программа будет закрыта.",
                        Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    DialogResult = DialogResult.Cancel;
                    return;
                }
                MessageBox.Show(this, "Неверное имя пользователя или пароль.\nПопыток осталось: " +
                    (MaxAttempts - failedAttempts), Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                txtPass.Clear();
                txtPass.Focus();
                return;
            }

            User = user;
            DialogResult = DialogResult.OK;
        }

        private void DoRegister()
        {
            string name = txtName.Text.Trim();
            string error = ValidateName(name);
            if (error == null) error = ValidatePassword(txtPass.Text, txtConfirm.Text);
            if (error != null)
            {
                MessageBox.Show(this, error, Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            if (Db.GetUser(name) != null)
            {
                MessageBox.Show(this, "Пользователь с таким именем уже существует.",
                    Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            bool first = Db.CountUsers() == 0;
            string role = first ? Roles.Admin : Roles.Keeper;
            int id = Db.CreateUser(name, CryptoHelper.HashPassword(txtPass.Text), role);

            if (first) Db.SeedDemoData(id);

            User = new UserRecord { Id = id, Name = name, Role = role };
            DialogResult = DialogResult.OK;
        }

        private static string ValidateName(string name)
        {
            if (name.Length < 3 || name.Length > 50)
                return "Имя пользователя должно содержать от 3 до 50 символов.";

            foreach (char ch in name)
            {
                if (!(char.IsLetterOrDigit(ch) || ch == '.' || ch == '-' || ch == '_'))
                    return "Имя может содержать только буквы, цифры, точку, дефис и подчёркивание.";
            }
            return null;
        }

        private static string ValidatePassword(string pass, string confirm)
        {
            if (pass.Length < 6 || pass.Length > 128)
                return "Пароль должен содержать от 6 до 128 символов.";
            if (pass != confirm)
                return "Пароли не совпадают.";
            return null;
        }
    }
}
