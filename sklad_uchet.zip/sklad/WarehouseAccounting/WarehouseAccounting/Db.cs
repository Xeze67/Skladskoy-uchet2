﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.OleDb;
using System.IO;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;

namespace WarehouseAccounting
{
    /// <summary>
    /// Вся работа с базой Microsoft Access в одном месте.
    /// Все запросы параметризованные (в OleDb параметры позиционные: порядок добавления = порядок знаков «?»).
    /// Если файл базы отсутствует, он создаётся автоматически при первом запуске.
    /// </summary>
    internal static class Db
    {
        public const string FileName = "WarehouseDB.accdb";

        public const string In = "IN";    // приход
        public const string Out = "OUT";  // расход

        private static readonly string[] Providers = { "Microsoft.ACE.OLEDB.12.0", "Microsoft.ACE.OLEDB.16.0" };
        private static string connectionString;

        public static string DbPath
        {
            get { return Path.Combine(AppDomain.CurrentDomain.BaseDirectory, FileName); }
        }

        // ───────────── Подключение и подготовка базы ─────────────

        private static string BuildConnectionString(string provider)
        {
            return "Provider=" + provider + ";Data Source=" + DbPath + ";";
        }

        private static string GetConnectionString()
        {
            if (connectionString != null) return connectionString;

            Exception last = null;
            foreach (string provider in Providers)
            {
                string cs = BuildConnectionString(provider);
                try
                {
                    using (var c = new OleDbConnection(cs))
                    {
                        c.Open();
                    }
                    connectionString = cs;
                    return cs;
                }
                catch (Exception ex)
                {
                    last = ex;
                }
            }

            throw new InvalidOperationException(
                "Не удалось открыть базу данных " + FileName + ".\n\n" +
                "Проверьте, что установлен «Microsoft Access Database Engine» " +
                "(той же разрядности, что и приложение: x64 или x86).\n\n" +
                "Подробности: " + (last != null ? last.Message : "неизвестная ошибка"), last);
        }

        private static OleDbConnection NewConnection()
        {
            return new OleDbConnection(GetConnectionString());
        }

        /// <summary>Проверяет базу; при первом запуске создаёт файл .accdb, таблицы и справочник категорий.</summary>
        public static void EnsureReady()
        {
            if (!File.Exists(DbPath))
            {
                CreateDatabaseFile();
                using (var c = NewConnection())
                {
                    c.Open();
                    CreateSchema(c);
                }
                return;
            }

            using (var c = NewConnection())
            {
                c.Open();
                string[] required = { "Users", "Categories", "Products", "Movements" };
                var missing = new List<string>();
                foreach (string table in required)
                {
                    if (!TableExists(c, table)) missing.Add(table);
                }

                if (missing.Count == required.Length)
                {
                    CreateSchema(c); // файл есть, но он пустой
                }
                else if (missing.Count > 0)
                {
                    throw new InvalidOperationException(
                        "В базе " + FileName + " отсутствуют таблицы: " + string.Join(", ", missing) + ".\n" +
                        "Удалите файл базы (предварительно сделав копию) — программа создаст новую.");
                }
            }
        }

        private static bool TableExists(OleDbConnection c, string name)
        {
            using (DataTable t = c.GetOleDbSchemaTable(OleDbSchemaGuid.Tables, new object[] { null, null, name, "TABLE" }))
            {
                return t != null && t.Rows.Count > 0;
            }
        }

        /// <summary>Создаёт пустой файл .accdb через ADOX (COM, late binding — ссылки на сборки не нужны).</summary>
        private static void CreateDatabaseFile()
        {
            Exception last = null;
            foreach (string provider in Providers)
            {
                try
                {
                    Type adox = Type.GetTypeFromProgID("ADOX.Catalog");
                    if (adox == null) throw new InvalidOperationException("Компонент ADOX не найден в системе.");

                    object catalog = Activator.CreateInstance(adox);
                    object conn = null;
                    try
                    {
                        conn = adox.InvokeMember("Create", BindingFlags.InvokeMethod, null, catalog,
                            new object[] { BuildConnectionString(provider) });
                    }
                    finally
                    {
                        if (conn != null)
                        {
                            try { conn.GetType().InvokeMember("Close", BindingFlags.InvokeMethod, null, conn, null); }
                            catch { }
                            Marshal.ReleaseComObject(conn);
                        }
                        Marshal.ReleaseComObject(catalog);
                    }
                    return;
                }
                catch (Exception ex)
                {
                    last = ex;
                }
            }

            throw new InvalidOperationException(
                "Не удалось создать файл базы данных " + FileName + ".\n\n" +
                "Установите «Microsoft Access Database Engine» (разрядность должна совпадать с приложением) " +
                "и проверьте права записи в папку программы.\n\n" +
                "Подробности: " + (last != null ? last.Message : "неизвестная ошибка"), last);
        }

        private static void Exec(OleDbConnection c, string sql)
        {
            using (var cmd = new OleDbCommand(sql, c))
            {
                cmd.ExecuteNonQuery();
            }
        }

        private static void CreateSchema(OleDbConnection c)
        {
            Exec(c, "CREATE TABLE Users (" +
                    "Users_id COUNTER PRIMARY KEY, " +
                    "UserName TEXT(50) NOT NULL, " +
                    "PasswordHash TEXT(255) NOT NULL, " +
                    "UserRole TEXT(20) NOT NULL)");
            Exec(c, "CREATE UNIQUE INDEX ux_users_name ON Users (UserName)");

            Exec(c, "CREATE TABLE Categories (" +
                    "Category_id COUNTER PRIMARY KEY, " +
                    "CategoryName TEXT(100) NOT NULL)");
            Exec(c, "CREATE UNIQUE INDEX ux_categories_name ON Categories (CategoryName)");

            Exec(c, "CREATE TABLE Products (" +
                    "Product_id COUNTER PRIMARY KEY, " +
                    "Sku TEXT(30) NOT NULL, " +
                    "Title TEXT(150) NOT NULL, " +
                    "UnitName TEXT(15) NOT NULL, " +
                    "Category_ID LONG, " +
                    "Price CURRENCY NOT NULL, " +
                    "MinStock LONG NOT NULL, " +
                    "Quantity LONG NOT NULL)");
            Exec(c, "CREATE UNIQUE INDEX ux_products_sku ON Products (Sku)");

            Exec(c, "CREATE TABLE Movements (" +
                    "Movement_id COUNTER PRIMARY KEY, " +
                    "Product_ID LONG NOT NULL, " +
                    "MoveType TEXT(3) NOT NULL, " +
                    "Qty LONG NOT NULL, " +
                    "MoveDate DATETIME NOT NULL, " +
                    "Counterparty TEXT(150), " +
                    "Note TEXT(255), " +
                    "User_ID LONG NOT NULL)");

            Exec(c, "ALTER TABLE Products ADD CONSTRAINT fk_products_category " +
                    "FOREIGN KEY (Category_ID) REFERENCES Categories (Category_id)");
            Exec(c, "ALTER TABLE Movements ADD CONSTRAINT fk_movements_product " +
                    "FOREIGN KEY (Product_ID) REFERENCES Products (Product_id)");
            Exec(c, "ALTER TABLE Movements ADD CONSTRAINT fk_movements_user " +
                    "FOREIGN KEY (User_ID) REFERENCES Users (Users_id)");

            foreach (string name in new[] { "Электроника", "Канцтовары", "Хозтовары", "Продукты" })
            {
                using (var cmd = new OleDbCommand("INSERT INTO Categories (CategoryName) VALUES (?)", c))
                {
                    AddText(cmd, name, 100);
                    cmd.ExecuteNonQuery();
                }
            }
        }

        // ───────────── Помощники параметров ─────────────

        private static void AddText(OleDbCommand cmd, string value, int size)
        {
            var p = cmd.Parameters.Add("?", OleDbType.VarWChar, size);
            p.Value = string.IsNullOrEmpty(value) ? (object)DBNull.Value : value;
        }

        private static void AddInt(OleDbCommand cmd, int value)
        {
            cmd.Parameters.Add("?", OleDbType.Integer).Value = value;
        }

        private static void AddNullableInt(OleDbCommand cmd, int? value)
        {
            cmd.Parameters.Add("?", OleDbType.Integer).Value = value.HasValue ? (object)value.Value : DBNull.Value;
        }

        private static void AddCurrency(OleDbCommand cmd, decimal value)
        {
            cmd.Parameters.Add("?", OleDbType.Currency).Value = value;
        }

        private static void AddDate(OleDbCommand cmd, DateTime value)
        {
            cmd.Parameters.Add("?", OleDbType.Date).Value = value;
        }

        private static int ScalarInt(OleDbCommand cmd)
        {
            object o = cmd.ExecuteScalar();
            return (o == null || o == DBNull.Value) ? 0 : Convert.ToInt32(o);
        }

        // ───────────── Пользователи ─────────────

        public static int CountUsers()
        {
            using (var c = NewConnection())
            using (var cmd = new OleDbCommand("SELECT COUNT(*) FROM Users", c))
            {
                c.Open();
                return ScalarInt(cmd);
            }
        }

        public static UserRecord GetUser(string name)
        {
            using (var c = NewConnection())
            using (var cmd = new OleDbCommand(
                "SELECT Users_id, UserName, PasswordHash, UserRole FROM Users WHERE UserName = ?", c))
            {
                AddText(cmd, name, 50);
                c.Open();
                using (var r = cmd.ExecuteReader())
                {
                    if (!r.Read()) return null;
                    return new UserRecord
                    {
                        Id = Convert.ToInt32(r.GetValue(0)),
                        Name = r.GetString(1),
                        Hash = r.GetString(2),
                        Role = r.GetString(3)
                    };
                }
            }
        }

        /// <summary>Создаёт пользователя и возвращает его идентификатор.</summary>
        public static int CreateUser(string name, string hash, string role)
        {
            using (var c = NewConnection())
            {
                c.Open();
                using (var cmd = new OleDbCommand(
                    "INSERT INTO Users (UserName, PasswordHash, UserRole) VALUES (?, ?, ?)", c))
                {
                    AddText(cmd, name, 50);
                    AddText(cmd, hash, 255);
                    AddText(cmd, role, 20);
                    cmd.ExecuteNonQuery();
                }
                using (var idCmd = new OleDbCommand("SELECT @@IDENTITY", c))
                {
                    return ScalarInt(idCmd);
                }
            }
        }

        // ───────────── Категории ─────────────

        public static List<Category> GetCategories()
        {
            var list = new List<Category>();
            using (var c = NewConnection())
            using (var cmd = new OleDbCommand("SELECT Category_id, CategoryName FROM Categories ORDER BY CategoryName", c))
            {
                c.Open();
                using (var r = cmd.ExecuteReader())
                {
                    while (r.Read()) list.Add(new Category(Convert.ToInt32(r.GetValue(0)), r.GetString(1)));
                }
            }
            return list;
        }

        public static bool CategoryNameExists(string name, int exceptId)
        {
            using (var c = NewConnection())
            using (var cmd = new OleDbCommand(
                "SELECT COUNT(*) FROM Categories WHERE CategoryName = ? AND Category_id <> ?", c))
            {
                AddText(cmd, name, 100);
                AddInt(cmd, exceptId);
                c.Open();
                return ScalarInt(cmd) > 0;
            }
        }

        public static void AddCategory(string name)
        {
            using (var c = NewConnection())
            using (var cmd = new OleDbCommand("INSERT INTO Categories (CategoryName) VALUES (?)", c))
            {
                AddText(cmd, name, 100);
                c.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public static void RenameCategory(int id, string name)
        {
            using (var c = NewConnection())
            using (var cmd = new OleDbCommand("UPDATE Categories SET CategoryName = ? WHERE Category_id = ?", c))
            {
                AddText(cmd, name, 100);
                AddInt(cmd, id);
                c.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public static int CategoryProductCount(int id)
        {
            using (var c = NewConnection())
            using (var cmd = new OleDbCommand("SELECT COUNT(*) FROM Products WHERE Category_ID = ?", c))
            {
                AddInt(cmd, id);
                c.Open();
                return ScalarInt(cmd);
            }
        }

        public static void DeleteCategory(int id)
        {
            using (var c = NewConnection())
            using (var cmd = new OleDbCommand("DELETE FROM Categories WHERE Category_id = ?", c))
            {
                AddInt(cmd, id);
                c.Open();
                cmd.ExecuteNonQuery();
            }
        }

        // ───────────── Товары ─────────────

        /// <summary>Список товаров для таблицы. Фильтры: поиск по названию/артикулу, категория, только низкий остаток.</summary>
        public static DataTable GetProducts(string search, int? categoryId, bool lowOnly)
        {
            var sql = new StringBuilder(
                "SELECT p.Product_id, p.Sku, p.Title, c.CategoryName, p.UnitName, p.Price, " +
                "p.Quantity, p.MinStock, p.Price * p.Quantity AS Total " +
                "FROM Products AS p LEFT JOIN Categories AS c ON p.Category_ID = c.Category_id WHERE 1 = 1");

            var table = new DataTable();
            using (var c = NewConnection())
            using (var cmd = new OleDbCommand())
            {
                cmd.Connection = c;

                if (!string.IsNullOrWhiteSpace(search))
                {
                    sql.Append(" AND (p.Title LIKE ? OR p.Sku LIKE ?)");
                    string pattern = "%" + search.Trim() + "%";
                    AddText(cmd, pattern, 160);
                    AddText(cmd, pattern, 160);
                }
                if (categoryId.HasValue)
                {
                    sql.Append(" AND p.Category_ID = ?");
                    AddInt(cmd, categoryId.Value);
                }
                if (lowOnly)
                {
                    sql.Append(" AND p.Quantity <= p.MinStock");
                }
                sql.Append(" ORDER BY p.Title");

                cmd.CommandText = sql.ToString();
                using (var adapter = new OleDbDataAdapter(cmd))
                {
                    adapter.Fill(table);
                }
            }
            return table;
        }

        public static ProductData GetProduct(int id)
        {
            using (var c = NewConnection())
            using (var cmd = new OleDbCommand(
                "SELECT Product_id, Sku, Title, UnitName, Category_ID, Price, MinStock, Quantity " +
                "FROM Products WHERE Product_id = ?", c))
            {
                AddInt(cmd, id);
                c.Open();
                using (var r = cmd.ExecuteReader())
                {
                    if (!r.Read()) return null;
                    return new ProductData
                    {
                        Id = Convert.ToInt32(r.GetValue(0)),
                        Sku = r.GetString(1),
                        Title = r.GetString(2),
                        UnitName = r.GetString(3),
                        CategoryId = r.IsDBNull(4) ? (int?)null : Convert.ToInt32(r.GetValue(4)),
                        Price = Convert.ToDecimal(r.GetValue(5)),
                        MinStock = Convert.ToInt32(r.GetValue(6)),
                        Quantity = Convert.ToInt32(r.GetValue(7))
                    };
                }
            }
        }

        /// <summary>Товары для выпадающего списка в форме прихода/расхода.</summary>
        public static List<ProductItem> GetProductItems()
        {
            var list = new List<ProductItem>();
            using (var c = NewConnection())
            using (var cmd = new OleDbCommand(
                "SELECT Product_id, Sku, Title, UnitName, Quantity FROM Products ORDER BY Title", c))
            {
                c.Open();
                using (var r = cmd.ExecuteReader())
                {
                    while (r.Read())
                    {
                        list.Add(new ProductItem
                        {
                            Id = Convert.ToInt32(r.GetValue(0)),
                            Display = r.GetString(1) + " — " + r.GetString(2),
                            UnitName = r.GetString(3),
                            Quantity = Convert.ToInt32(r.GetValue(4))
                        });
                    }
                }
            }
            return list;
        }

        public static bool SkuExists(string sku, int exceptId)
        {
            using (var c = NewConnection())
            using (var cmd = new OleDbCommand(
                "SELECT COUNT(*) FROM Products WHERE Sku = ? AND Product_id <> ?", c))
            {
                AddText(cmd, sku, 30);
                AddInt(cmd, exceptId);
                c.Open();
                return ScalarInt(cmd) > 0;
            }
        }

        /// <summary>Добавляет товар с нулевым остатком и возвращает его идентификатор.</summary>
        public static int AddProduct(ProductData p)
        {
            using (var c = NewConnection())
            {
                c.Open();
                using (var cmd = new OleDbCommand(
                    "INSERT INTO Products (Sku, Title, UnitName, Category_ID, Price, MinStock, Quantity) " +
                    "VALUES (?, ?, ?, ?, ?, ?, 0)", c))
                {
                    AddText(cmd, p.Sku, 30);
                    AddText(cmd, p.Title, 150);
                    AddText(cmd, p.UnitName, 15);
                    AddNullableInt(cmd, p.CategoryId);
                    AddCurrency(cmd, p.Price);
                    AddInt(cmd, p.MinStock);
                    cmd.ExecuteNonQuery();
                }
                using (var idCmd = new OleDbCommand("SELECT @@IDENTITY", c))
                {
                    return ScalarInt(idCmd);
                }
            }
        }

        /// <summary>Изменяет данные товара. Остаток меняется только движениями.</summary>
        public static void UpdateProduct(ProductData p)
        {
            using (var c = NewConnection())
            using (var cmd = new OleDbCommand(
                "UPDATE Products SET Sku = ?, Title = ?, UnitName = ?, Category_ID = ?, Price = ?, MinStock = ? " +
                "WHERE Product_id = ?", c))
            {
                AddText(cmd, p.Sku, 30);
                AddText(cmd, p.Title, 150);
                AddText(cmd, p.UnitName, 15);
                AddNullableInt(cmd, p.CategoryId);
                AddCurrency(cmd, p.Price);
                AddInt(cmd, p.MinStock);
                AddInt(cmd, p.Id);
                c.Open();
                cmd.ExecuteNonQuery();
            }
        }

        public static int MovementCountForProduct(int productId)
        {
            using (var c = NewConnection())
            using (var cmd = new OleDbCommand("SELECT COUNT(*) FROM Movements WHERE Product_ID = ?", c))
            {
                AddInt(cmd, productId);
                c.Open();
                return ScalarInt(cmd);
            }
        }

        public static void DeleteProduct(int id)
        {
            using (var c = NewConnection())
            using (var cmd = new OleDbCommand("DELETE FROM Products WHERE Product_id = ?", c))
            {
                AddInt(cmd, id);
                c.Open();
                cmd.ExecuteNonQuery();
            }
        }

        // ───────────── Движения (приход / расход) ─────────────

        /// <summary>
        /// Регистрирует приход или расход. Запись движения и изменение остатка выполняются в одной транзакции.
        /// Расход больше остатка запрещён (InvalidOperationException).
        /// </summary>
        public static void AddMovement(int productId, string type, int qty, DateTime date,
                                       string counterparty, string note, int userId)
        {
            if (type != In && type != Out) throw new ArgumentException("Неизвестный тип движения.");
            if (qty <= 0) throw new InvalidOperationException("Количество должно быть больше нуля.");

            using (var c = NewConnection())
            {
                c.Open();
                using (OleDbTransaction tx = c.BeginTransaction())
                {
                    int current;
                    using (var q = new OleDbCommand("SELECT Quantity FROM Products WHERE Product_id = ?", c, tx))
                    {
                        AddInt(q, productId);
                        object o = q.ExecuteScalar();
                        if (o == null || o == DBNull.Value) throw new InvalidOperationException("Товар не найден.");
                        current = Convert.ToInt32(o);
                    }

                    if (type == Out && qty > current)
                    {
                        throw new InvalidOperationException(
                            "Недостаточно товара на складе. Доступно: " + current + ", запрошено: " + qty + ".");
                    }

                    int updated = type == In ? current + qty : current - qty;

                    using (var ins = new OleDbCommand(
                        "INSERT INTO Movements (Product_ID, MoveType, Qty, MoveDate, Counterparty, Note, User_ID) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?)", c, tx))
                    {
                        AddInt(ins, productId);
                        AddText(ins, type, 3);
                        AddInt(ins, qty);
                        AddDate(ins, date);
                        AddText(ins, counterparty, 150);
                        AddText(ins, note, 255);
                        AddInt(ins, userId);
                        ins.ExecuteNonQuery();
                    }

                    using (var upd = new OleDbCommand("UPDATE Products SET Quantity = ? WHERE Product_id = ?", c, tx))
                    {
                        AddInt(upd, updated);
                        AddInt(upd, productId);
                        upd.ExecuteNonQuery();
                    }

                    tx.Commit();
                }
            }
        }

        /// <summary>Журнал движений за период. type: null — все, иначе Db.In / Db.Out.</summary>
        public static DataTable GetMovements(DateTime from, DateTime to, string type)
        {
            var sql = new StringBuilder(
                "SELECT m.Movement_id, m.MoveDate, p.Sku, p.Title, " +
                "IIF(m.MoveType = 'IN', 'Приход', 'Расход') AS TypeName, " +
                "m.Qty, m.Counterparty, m.Note, u.UserName " +
                "FROM (Movements AS m INNER JOIN Products AS p ON m.Product_ID = p.Product_id) " +
                "INNER JOIN Users AS u ON m.User_ID = u.Users_id " +
                "WHERE m.MoveDate >= ? AND m.MoveDate <= ?");

            var table = new DataTable();
            using (var c = NewConnection())
            using (var cmd = new OleDbCommand())
            {
                cmd.Connection = c;
                AddDate(cmd, from);
                AddDate(cmd, to);
                if (type != null)
                {
                    sql.Append(" AND m.MoveType = ?");
                    AddText(cmd, type, 3);
                }
                sql.Append(" ORDER BY m.MoveDate DESC, m.Movement_id DESC");

                cmd.CommandText = sql.ToString();
                using (var adapter = new OleDbDataAdapter(cmd))
                {
                    adapter.Fill(table);
                }
            }
            return table;
        }

        /// <summary>Суммарный оборот за период: [0] — приход, [1] — расход (в единицах товара).</summary>
        public static int[] GetTurnover(DateTime from, DateTime to)
        {
            int[] result = new int[2];
            using (var c = NewConnection())
            using (var cmd = new OleDbCommand(
                "SELECT MoveType, SUM(Qty) FROM Movements WHERE MoveDate >= ? AND MoveDate <= ? GROUP BY MoveType", c))
            {
                AddDate(cmd, from);
                AddDate(cmd, to);
                c.Open();
                using (var r = cmd.ExecuteReader())
                {
                    while (r.Read())
                    {
                        int sum = r.IsDBNull(1) ? 0 : Convert.ToInt32(r.GetValue(1));
                        if (r.GetString(0) == In) result[0] = sum;
                        else if (r.GetString(0) == Out) result[1] = sum;
                    }
                }
            }
            return result;
        }

        // ───────────── Демонстрационные данные ─────────────

        /// <summary>Заполняет базу демо-товарами и начальными приходами (вызывается один раз после создания администратора).</summary>
        public static void SeedDemoData(int userId)
        {
            Category[] cats = GetCategories().ToArray();
            Func<string, int?> catId = name =>
            {
                foreach (Category c in cats) if (c.Name == name) return c.Id;
                return (int?)null;
            };

            var demo = new[]
            {
                new { Sku = "EL-001", Title = "USB-флешка 32 ГБ",         Unit = "шт", Cat = "Электроника", Price = 450m, Min = 10, Qty = 40  },
                new { Sku = "EL-002", Title = "Мышь беспроводная",        Unit = "шт", Cat = "Электроника", Price = 890m, Min = 5,  Qty = 3   },
                new { Sku = "ST-001", Title = "Бумага А4, 500 листов",    Unit = "уп", Cat = "Канцтовары",  Price = 380m, Min = 10, Qty = 25  },
                new { Sku = "ST-002", Title = "Ручка шариковая синяя",    Unit = "шт", Cat = "Канцтовары",  Price = 25m,  Min = 50, Qty = 200 },
                new { Sku = "HZ-001", Title = "Мешки для мусора 60 л",    Unit = "уп", Cat = "Хозтовары",   Price = 120m, Min = 10, Qty = 8   }
            };

            foreach (var d in demo)
            {
                int id = AddProduct(new ProductData
                {
                    Sku = d.Sku,
                    Title = d.Title,
                    UnitName = d.Unit,
                    CategoryId = catId(d.Cat),
                    Price = d.Price,
                    MinStock = d.Min
                });
                AddMovement(id, In, d.Qty, DateTime.Now.AddDays(-7), "Начальный остаток", "Демо-данные", userId);
            }
        }
    }
}
