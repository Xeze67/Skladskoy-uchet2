﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace WarehouseAccounting
{
    /// <summary>Главное окно: вкладки «Товары», «Журнал движений», «Отчёт».</summary>
    internal sealed class MainForm : Form
    {
        private readonly UserRecord user;

        private readonly ToolStrip toolStrip = new ToolStrip();
        private readonly StatusStrip statusStrip = new StatusStrip();
        private readonly ToolStripStatusLabel statusLabel = new ToolStripStatusLabel();
        private readonly TabControl tabs = new TabControl();

        // Товары
        private readonly DataGridView gridProducts = new DataGridView();
        private readonly TextBox txtSearch = new TextBox();
        private readonly ComboBox cmbCategory = new ComboBox();
        private readonly CheckBox chkLow = new CheckBox();

        // Журнал
        private readonly DataGridView gridMoves = new DataGridView();
        private readonly DateTimePicker dtFrom = new DateTimePicker();
        private readonly DateTimePicker dtTo = new DateTimePicker();
        private readonly ComboBox cmbMoveType = new ComboBox();

        // Отчёт
        private readonly TextBox txtReport = new TextBox();
        private readonly DateTimePicker dtRepFrom = new DateTimePicker();
        private readonly DateTimePicker dtRepTo = new DateTimePicker();

        private bool loading = true;

        /// <summary>true — пользователь выбрал «Сменить пользователя» (нужно снова показать окно входа).</summary>
        public bool LogoutRequested { get; private set; }

        public MainForm(UserRecord currentUser)
        {
            user = currentUser;

            Text = "Складской учёт (мини-версия)";
            Font = new Font("Segoe UI", 9.5f);
            MinimumSize = new Size(900, 560);
            Size = new Size(1100, 680);
            StartPosition = FormStartPosition.CenterScreen;
            KeyPreview = true;

            BuildTabs();
            BuildToolStrip();
            BuildStatusStrip();

            // Элемент с Dock = Fill добавляется первым, затем панели Top/Bottom.
            Controls.Add(tabs);
            Controls.Add(toolStrip);
            Controls.Add(statusStrip);

            LoadCategoryFilter();
            loading = false;

            RefreshProducts();
            RefreshMoves();
            RefreshReport();
        }

        // ───────────── Построение интерфейса ─────────────

        private void BuildToolStrip()
        {
            toolStrip.Dock = DockStyle.Top;
            toolStrip.GripStyle = ToolStripGripStyle.Hidden;
            toolStrip.Padding = new Padding(6, 4, 6, 4);

            toolStrip.Items.Add(MakeButton("Новый товар", delegate { AddProduct(); }));
            toolStrip.Items.Add(MakeButton("Изменить", delegate { EditProduct(); }));
            ToolStripButton del = MakeButton("Удалить", delegate { DeleteProduct(); });
            del.Enabled = user.IsAdmin;
            toolStrip.Items.Add(del);
            toolStrip.Items.Add(new ToolStripSeparator());
            toolStrip.Items.Add(MakeButton("Приход", delegate { RegisterMovement(true); }));
            toolStrip.Items.Add(MakeButton("Расход", delegate { RegisterMovement(false); }));
            toolStrip.Items.Add(new ToolStripSeparator());
            toolStrip.Items.Add(MakeButton("Категории", delegate { OpenCategories(); }));
            toolStrip.Items.Add(MakeButton("Экспорт в CSV", delegate { ExportCurrent(); }));
            toolStrip.Items.Add(new ToolStripSeparator());
            toolStrip.Items.Add(MakeButton("Сменить пользователя", delegate
            {
                LogoutRequested = true;
                Close();
            }));
        }

        private static ToolStripButton MakeButton(string text, EventHandler handler)
        {
            var b = new ToolStripButton(text);
            b.DisplayStyle = ToolStripItemDisplayStyle.Text;
            b.Click += handler;
            return b;
        }

        private void BuildStatusStrip()
        {
            statusStrip.Dock = DockStyle.Bottom;
            statusLabel.Text = "Пользователь: " + user.Name + " (" + user.Role + ")";
            statusStrip.Items.Add(statusLabel);
        }

        private void BuildTabs()
        {
            tabs.Dock = DockStyle.Fill;

            var pageProducts = new TabPage("Товары");
            var pageMoves = new TabPage("Журнал движений");
            var pageReport = new TabPage("Отчёт");

            // --- Товары ---
            ConfigureGrid(gridProducts);
            gridProducts.DoubleClick += delegate { EditProduct(); };
            gridProducts.DataBindingComplete += delegate { FormatProductsGrid(); };

            var filterPanel = new Panel { Dock = DockStyle.Top, Height = 42 };
            var lblSearch = new Label { Text = "Поиск:", Left = 10, Top = 11, Width = 50 };
            txtSearch.SetBounds(62, 8, 240, 26);
            txtSearch.TextChanged += delegate { RefreshProducts(); };
            var lblCat = new Label { Text = "Категория:", Left = 320, Top = 11, Width = 75 };
            cmbCategory.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbCategory.SetBounds(398, 8, 200, 26);
            cmbCategory.SelectedIndexChanged += delegate { RefreshProducts(); };
            chkLow.Text = "Только низкий остаток";
            chkLow.SetBounds(615, 9, 190, 24);
            chkLow.CheckedChanged += delegate { RefreshProducts(); };
            filterPanel.Controls.AddRange(new Control[] { lblSearch, txtSearch, lblCat, cmbCategory, chkLow });

            pageProducts.Controls.Add(gridProducts);
            pageProducts.Controls.Add(filterPanel);

            // --- Журнал ---
            ConfigureGrid(gridMoves);

            var movesPanel = new Panel { Dock = DockStyle.Top, Height = 42 };
            var lblFrom = new Label { Text = "С:", Left = 10, Top = 11, Width = 25 };
            dtFrom.Format = DateTimePickerFormat.Short;
            dtFrom.Value = DateTime.Today.AddDays(-30);
            dtFrom.SetBounds(38, 8, 115, 26);
            dtFrom.ValueChanged += delegate { RefreshMoves(); };
            var lblTo = new Label { Text = "По:", Left = 170, Top = 11, Width = 30 };
            dtTo.Format = DateTimePickerFormat.Short;
            dtTo.Value = DateTime.Today;
            dtTo.SetBounds(202, 8, 115, 26);
            dtTo.ValueChanged += delegate { RefreshMoves(); };
            var lblType = new Label { Text = "Тип:", Left = 335, Top = 11, Width = 35 };
            cmbMoveType.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbMoveType.Items.AddRange(new object[] { "Все", "Приход", "Расход" });
            cmbMoveType.SelectedIndex = 0;
            cmbMoveType.SetBounds(373, 8, 120, 26);
            cmbMoveType.SelectedIndexChanged += delegate { RefreshMoves(); };
            movesPanel.Controls.AddRange(new Control[] { lblFrom, dtFrom, lblTo, dtTo, lblType, cmbMoveType });

            pageMoves.Controls.Add(gridMoves);
            pageMoves.Controls.Add(movesPanel);

            // --- Отчёт ---
            txtReport.Dock = DockStyle.Fill;
            txtReport.Multiline = true;
            txtReport.ReadOnly = true;
            txtReport.ScrollBars = ScrollBars.Vertical;
            txtReport.Font = new Font("Consolas", 10.5f);
            txtReport.BackColor = Color.White;

            var repPanel = new Panel { Dock = DockStyle.Top, Height = 42 };
            var lblRepFrom = new Label { Text = "Период с:", Left = 10, Top = 11, Width = 65 };
            dtRepFrom.Format = DateTimePickerFormat.Short;
            dtRepFrom.Value = new DateTime(DateTime.Today.Year, DateTime.Today.Month, 1);
            dtRepFrom.SetBounds(78, 8, 115, 26);
            var lblRepTo = new Label { Text = "по:", Left = 205, Top = 11, Width = 25 };
            dtRepTo.Format = DateTimePickerFormat.Short;
            dtRepTo.Value = DateTime.Today;
            dtRepTo.SetBounds(232, 8, 115, 26);
            var btnRep = new Button { Text = "Сформировать", Left = 365, Top = 6, Width = 130, Height = 30 };
            btnRep.Click += delegate { RefreshReport(); };
            repPanel.Controls.AddRange(new Control[] { lblRepFrom, dtRepFrom, lblRepTo, dtRepTo, btnRep });

            pageReport.Controls.Add(txtReport);
            pageReport.Controls.Add(repPanel);

            tabs.TabPages.Add(pageProducts);
            tabs.TabPages.Add(pageMoves);
            tabs.TabPages.Add(pageReport);
            tabs.SelectedIndexChanged += delegate
            {
                if (tabs.SelectedIndex == 1) RefreshMoves();
                else if (tabs.SelectedIndex == 2) RefreshReport();
            };
        }

        private static void ConfigureGrid(DataGridView g)
        {
            g.Dock = DockStyle.Fill;
            g.ReadOnly = true;
            g.AllowUserToAddRows = false;
            g.AllowUserToDeleteRows = false;
            g.AllowUserToResizeRows = false;
            g.MultiSelect = false;
            g.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            g.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            g.RowHeadersVisible = false;
            g.BackgroundColor = Color.White;
            g.BorderStyle = BorderStyle.None;
            g.EnableHeadersVisualStyles = true;
        }

        // ───────────── Загрузка данных ─────────────

        private void LoadCategoryFilter()
        {
            cmbCategory.Items.Clear();
            cmbCategory.Items.Add(new Category(0, "Все категории"));
            foreach (Category c in Db.GetCategories()) cmbCategory.Items.Add(c);
            cmbCategory.SelectedIndex = 0;
        }

        private void RefreshProducts()
        {
            if (loading) return;
            try
            {
                int? categoryId = null;
                Category selected = cmbCategory.SelectedItem as Category;
                if (selected != null && selected.Id != 0) categoryId = selected.Id;

                gridProducts.DataSource = Db.GetProducts(txtSearch.Text, categoryId, chkLow.Checked);
            }
            catch (Exception ex)
            {
                ShowDbError(ex);
            }
        }

        private void FormatProductsGrid()
        {
            if (gridProducts.Columns.Count == 0) return;

            SetHeader(gridProducts, "Product_id", null);
            SetHeader(gridProducts, "Sku", "Артикул");
            SetHeader(gridProducts, "Title", "Название");
            SetHeader(gridProducts, "CategoryName", "Категория");
            SetHeader(gridProducts, "UnitName", "Ед.");
            SetHeader(gridProducts, "Price", "Цена, руб.");
            SetHeader(gridProducts, "Quantity", "Остаток");
            SetHeader(gridProducts, "MinStock", "Мин. остаток");
            SetHeader(gridProducts, "Total", "Стоимость, руб.");

            if (gridProducts.Columns.Contains("Price")) gridProducts.Columns["Price"].DefaultCellStyle.Format = "N2";
            if (gridProducts.Columns.Contains("Total")) gridProducts.Columns["Total"].DefaultCellStyle.Format = "N2";
            if (gridProducts.Columns.Contains("Title")) gridProducts.Columns["Title"].FillWeight = 220;

            int low = 0;
            foreach (DataGridViewRow row in gridProducts.Rows)
            {
                int qty = Convert.ToInt32(row.Cells["Quantity"].Value);
                int min = Convert.ToInt32(row.Cells["MinStock"].Value);
                bool isLow = qty <= min;
                row.DefaultCellStyle.BackColor = isLow ? Color.MistyRose : Color.White;
                if (isLow) low++;
            }
            statusLabel.Text = "Пользователь: " + user.Name + " (" + user.Role + ")   |   Товаров: " +
                               gridProducts.Rows.Count + "   |   С низким остатком: " + low;
        }

        private static void SetHeader(DataGridView g, string column, string header)
        {
            if (!g.Columns.Contains(column)) return;
            if (header == null) g.Columns[column].Visible = false;
            else g.Columns[column].HeaderText = header;
        }

        private void RefreshMoves()
        {
            if (loading) return;
            try
            {
                DateTime from = dtFrom.Value.Date;
                DateTime to = dtTo.Value.Date.AddDays(1).AddSeconds(-1);

                string type = null;
                if (cmbMoveType.SelectedIndex == 1) type = Db.In;
                else if (cmbMoveType.SelectedIndex == 2) type = Db.Out;

                gridMoves.DataSource = Db.GetMovements(from, to, type);

                SetHeader(gridMoves, "Movement_id", null);
                SetHeader(gridMoves, "MoveDate", "Дата и время");
                SetHeader(gridMoves, "Sku", "Артикул");
                SetHeader(gridMoves, "Title", "Товар");
                SetHeader(gridMoves, "TypeName", "Тип");
                SetHeader(gridMoves, "Qty", "Кол-во");
                SetHeader(gridMoves, "Counterparty", "Контрагент");
                SetHeader(gridMoves, "Note", "Примечание");
                SetHeader(gridMoves, "UserName", "Сотрудник");
                if (gridMoves.Columns.Contains("MoveDate"))
                    gridMoves.Columns["MoveDate"].DefaultCellStyle.Format = "dd.MM.yyyy HH:mm";

                foreach (DataGridViewRow row in gridMoves.Rows)
                {
                    bool income = Convert.ToString(row.Cells["TypeName"].Value) == "Приход";
                    row.DefaultCellStyle.BackColor = income ? Color.Honeydew : Color.LemonChiffon;
                }
            }
            catch (Exception ex)
            {
                ShowDbError(ex);
            }
        }

        private void RefreshReport()
        {
            if (loading) return;
            try
            {
                DataTable products = Db.GetProducts(null, null, false);
                int positions = products.Rows.Count;
                long totalQty = 0;
                decimal totalValue = 0;
                var low = new List<string>();

                foreach (DataRow r in products.Rows)
                {
                    int qty = Convert.ToInt32(r["Quantity"]);
                    int min = Convert.ToInt32(r["MinStock"]);
                    totalQty += qty;
                    totalValue += Convert.ToDecimal(r["Total"]);
                    if (qty <= min)
                    {
                        low.Add("  - " + r["Sku"] + "  " + r["Title"] + ": остаток " + qty + " " + r["UnitName"] +
                                " (минимум " + min + ")");
                    }
                }

                DateTime from = dtRepFrom.Value.Date;
                DateTime to = dtRepTo.Value.Date.AddDays(1).AddSeconds(-1);
                int[] turnover = Db.GetTurnover(from, to);

                var sb = new StringBuilder();
                sb.AppendLine("ОТЧЁТ ПО СКЛАДУ");
                sb.AppendLine("Сформирован: " + DateTime.Now.ToString("dd.MM.yyyy HH:mm", CultureInfo.CurrentCulture));
                sb.AppendLine(new string('=', 60));
                sb.AppendLine("Позиций товаров:           " + positions);
                sb.AppendLine("Общее количество на складе: " + totalQty);
                sb.AppendLine("Стоимость остатков:         " + totalValue.ToString("N2", CultureInfo.CurrentCulture) + " руб.");
                sb.AppendLine("Позиций с низким остатком:  " + low.Count);
                if (low.Count > 0)
                {
                    sb.AppendLine();
                    sb.AppendLine("Требуется пополнение:");
                    foreach (string s in low) sb.AppendLine(s);
                }
                sb.AppendLine();
                sb.AppendLine("Оборот за период " + from.ToString("dd.MM.yyyy") + " — " + dtRepTo.Value.ToString("dd.MM.yyyy") + ":");
                sb.AppendLine("  Приход: " + turnover[0] + " ед.");
                sb.AppendLine("  Расход: " + turnover[1] + " ед.");

                txtReport.Text = sb.ToString();
            }
            catch (Exception ex)
            {
                ShowDbError(ex);
            }
        }

        private void RefreshAll()
        {
            RefreshProducts();
            RefreshMoves();
            RefreshReport();
        }

        // ───────────── Действия ─────────────

        private int? SelectedProductId()
        {
            DataGridViewRow row = gridProducts.CurrentRow;
            if (row == null || row.Cells["Product_id"].Value == null) return null;
            return Convert.ToInt32(row.Cells["Product_id"].Value);
        }

        private void AddProduct()
        {
            using (var form = new ProductForm(null))
            {
                if (form.ShowDialog(this) != DialogResult.OK) return;
                try
                {
                    int id = Db.AddProduct(form.Result);
                    if (form.InitialQty > 0)
                    {
                        Db.AddMovement(id, Db.In, form.InitialQty, DateTime.Now, "Начальный остаток", "", user.Id);
                    }
                }
                catch (Exception ex)
                {
                    ShowDbError(ex);
                    return;
                }
            }
            RefreshAll();
        }

        private void EditProduct()
        {
            int? id = SelectedProductId();
            if (id == null)
            {
                MessageBox.Show(this, "Выберите товар в таблице.", Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                ProductData data = Db.GetProduct(id.Value);
                if (data == null) return;
                using (var form = new ProductForm(data))
                {
                    if (form.ShowDialog(this) != DialogResult.OK) return;
                    Db.UpdateProduct(form.Result);
                }
            }
            catch (Exception ex)
            {
                ShowDbError(ex);
                return;
            }
            RefreshAll();
        }

        private void DeleteProduct()
        {
            if (!user.IsAdmin)
            {
                MessageBox.Show(this, "Удалять товары может только администратор.", Text,
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            int? id = SelectedProductId();
            if (id == null)
            {
                MessageBox.Show(this, "Выберите товар в таблице.", Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            try
            {
                int moves = Db.MovementCountForProduct(id.Value);
                if (moves > 0)
                {
                    MessageBox.Show(this,
                        "Нельзя удалить товар: по нему есть движения (" + moves + "). История склада должна сохраняться.",
                        Text, MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                if (MessageBox.Show(this, "Удалить выбранный товар?", Text,
                        MessageBoxButtons.YesNo, MessageBoxIcon.Question) != DialogResult.Yes) return;

                Db.DeleteProduct(id.Value);
            }
            catch (Exception ex)
            {
                ShowDbError(ex);
                return;
            }
            RefreshAll();
        }

        private void RegisterMovement(bool income)
        {
            try
            {
                using (var form = new MovementForm(income, user.Id, SelectedProductId()))
                {
                    if (form.ShowDialog(this) != DialogResult.OK) return;
                }
            }
            catch (Exception ex)
            {
                ShowDbError(ex);
                return;
            }
            RefreshAll();
        }

        private void OpenCategories()
        {
            using (var form = new CategoriesForm(user.IsAdmin))
            {
                form.ShowDialog(this);
            }
            loading = true;
            LoadCategoryFilter();
            loading = false;
            RefreshProducts();
        }

        private void ExportCurrent()
        {
            DataGridView grid;
            string name;
            if (tabs.SelectedIndex == 1)
            {
                grid = gridMoves;
                name = "movements.csv";
            }
            else if (tabs.SelectedIndex == 0)
            {
                grid = gridProducts;
                name = "products.csv";
            }
            else
            {
                MessageBox.Show(this, "Экспорт доступен на вкладках «Товары» и «Журнал движений».", Text,
                    MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            using (var dlg = new SaveFileDialog())
            {
                dlg.Filter = "CSV (*.csv)|*.csv";
                dlg.FileName = name;
                if (dlg.ShowDialog(this) != DialogResult.OK) return;

                try
                {
                    List<DataGridViewColumn> cols = grid.Columns.Cast<DataGridViewColumn>()
                        .Where(c => c.Visible).OrderBy(c => c.DisplayIndex).ToList();

                    var sb = new StringBuilder();
                    sb.AppendLine(string.Join(";", cols.Select(c => Csv(c.HeaderText))));
                    foreach (DataGridViewRow row in grid.Rows)
                    {
                        sb.AppendLine(string.Join(";", cols.Select(c => Csv(row.Cells[c.Index].FormattedValue))));
                    }
                    File.WriteAllText(dlg.FileName, sb.ToString(), new UTF8Encoding(true));
                    MessageBox.Show(this, "Файл сохранён:\n" + dlg.FileName, Text, MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                catch (Exception ex)
                {
                    MessageBox.Show(this, "Не удалось сохранить файл:\n" + ex.Message, Text,
                        MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private static string Csv(object value)
        {
            string s = value == null ? "" : value.ToString();
            if (s.IndexOfAny(new[] { ';', '"', '\r', '\n' }) >= 0) s = "\"" + s.Replace("\"", "\"\"") + "\"";
            return s;
        }

        private void ShowDbError(Exception ex)
        {
            MessageBox.Show(this, "Ошибка при работе с базой данных:\n" + ex.Message, Text,
                MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        // ───────────── Горячие клавиши ─────────────

        protected override bool ProcessCmdKey(ref Message msg, Keys keyData)
        {
            switch (keyData)
            {
                case Keys.Control | Keys.F:
                    tabs.SelectedIndex = 0;
                    txtSearch.Focus();
                    return true;
                case Keys.Control | Keys.N:
                    AddProduct();
                    return true;
                case Keys.Control | Keys.I:
                    RegisterMovement(true);
                    return true;
                case Keys.Control | Keys.O:
                    RegisterMovement(false);
                    return true;
                case Keys.F5:
                    RefreshAll();
                    return true;
            }
            return base.ProcessCmdKey(ref msg, keyData);
        }
    }
}
