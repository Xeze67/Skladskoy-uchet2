import os
from pptx import Presentation
from pptx.util import Inches, Pt
from pptx.dml.color import RGBColor
from pptx.enum.text import PP_ALIGN
from pptx.enum.shapes import MSO_SHAPE

from reportlab.lib.pagesizes import landscape, A4
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Image, Table, TableStyle, PageBreak
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

pdfmetrics.registerFont(TTFont('Arial', r'C:\Windows\Fonts\arial.ttf'))
pdfmetrics.registerFont(TTFont('Arial-Bold', r'C:\Windows\Fonts\arialbd.ttf'))

# ==========================================
# 1. PPTX GENERATION (python-pptx)
# ==========================================
prs = Presentation()
prs.slide_width = Inches(13.333)
prs.slide_height = Inches(7.5)
blank_slide_layout = prs.slide_layouts[6]

DARK_BG = RGBColor(15, 23, 42)      # Slate 900
CARD_BG = RGBColor(30, 41, 59)      # Slate 800
ACCENT_BLUE = RGBColor(37, 99, 235) # Blue 600
ACCENT_CYAN = RGBColor(6, 182, 212) # Cyan 500
ACCENT_GREEN = RGBColor(16, 185, 129) # Emerald 500
TEXT_WHITE = RGBColor(255, 255, 255)
TEXT_MUTED = RGBColor(148, 163, 184)

def set_slide_background(slide, color=DARK_BG):
    bg_shape = slide.shapes.add_shape(MSO_SHAPE.RECTANGLE, 0, 0, prs.slide_width, prs.slide_height)
    bg_shape.fill.solid()
    bg_shape.fill.fore_color.rgb = color
    bg_shape.line.fill.background()
    return bg_shape

def add_header(slide, title_text, category_text="ТЕМА № 9 • СКЛАДСКОЙ УЧЁТ"):
    header_box = slide.shapes.add_textbox(Inches(0.8), Inches(0.4), Inches(11.7), Inches(1.1))
    tf = header_box.text_frame
    tf.word_wrap = True
    
    p_cat = tf.paragraphs[0]
    p_cat.text = category_text
    p_cat.font.name = 'Arial'
    p_cat.font.size = Pt(11)
    p_cat.font.bold = True
    p_cat.font.color.rgb = ACCENT_CYAN
    
    p_title = tf.add_paragraph()
    p_title.text = title_text
    p_title.font.name = 'Arial'
    p_title.font.size = Pt(22)
    p_title.font.bold = True
    p_title.font.color.rgb = TEXT_WHITE

# SLIDE 1: Title
s1 = prs.slides.add_slide(blank_slide_layout)
set_slide_background(s1)

tb = s1.shapes.add_textbox(Inches(1.2), Inches(1.5), Inches(10.9), Inches(4.5))
tf = tb.text_frame
tf.word_wrap = True

p = tf.paragraphs[0]
p.text = "ГРУППОВОЙ ПРОЕКТ • ТЕМА № 9"
p.font.name = 'Arial'
p.font.size = Pt(14)
p.font.bold = True
p.font.color.rgb = ACCENT_CYAN

p2 = tf.add_paragraph()
p2.text = "Складской учёт (мини-версия)"
p2.font.name = 'Arial'
p2.font.size = Pt(36)
p2.font.bold = True
p2.font.color.rgb = TEXT_WHITE

p3 = tf.add_paragraph()
p3.text = "Разработка приложения в Visual Studio + Git + защита"
p3.font.name = 'Arial'
p3.font.size = Pt(18)
p3.font.color.rgb = RGBColor(203, 213, 225)
p3.space_before = Pt(10)

p4 = tf.add_paragraph()
p4.text = "\nКоманда разработчиков:\n• Ложкин — Тимлид, Архитектор решения\n• Барышев — Разработчик WinForms UI/UX\n• Рейтер — Разработчик БД, QA-инженер\n\nСтек: C# 13, .NET 9.0, Windows Forms, xUnit, Git Flow, MS Access (warehouse.accdb)"
p4.font.name = 'Arial'
p4.font.size = Pt(14)
p4.font.color.rgb = TEXT_MUTED

# Helper for card slides
def add_cards_slide(prs, title, cat, cards):
    s = prs.slides.add_slide(blank_slide_layout)
    set_slide_background(s)
    add_header(s, title, cat)
    
    num_cards = len(cards)
    gap = 0.35
    total_w = 11.7
    card_w = (total_w - gap * (num_cards - 1)) / num_cards
    
    for i, (ctitle, cdesc, ccolor) in enumerate(cards):
        cx = Inches(0.8 + i * (card_w + gap))
        card = s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, cx, Inches(1.8), Inches(card_w), Inches(4.8))
        card.fill.solid()
        card.fill.fore_color.rgb = CARD_BG
        card.line.color.rgb = ccolor
        card.line.width = Pt(1.5)
        
        tb = s.shapes.add_textbox(cx + Inches(0.2), Inches(2.0), Inches(card_w - 0.4), Inches(4.4))
        tf = tb.text_frame
        tf.word_wrap = True
        
        p = tf.paragraphs[0]
        p.text = ctitle
        p.font.name = 'Arial'
        p.font.size = Pt(16)
        p.font.bold = True
        p.font.color.rgb = ccolor
        
        p2 = tf.add_paragraph()
        p2.text = "\n" + cdesc
        p2.font.name = 'Arial'
        p2.font.size = Pt(12)
        p2.font.color.rgb = RGBColor(226, 232, 240)
        p2.space_before = Pt(8)
    return s

# SLIDE 2: Problem & Goal
add_cards_slide(prs, "Проблема, актуальность и цель проекта", "АКТУАЛЬНОСТЬ", [
    ("Актуальная проблема", "• Ведение учета в разрозненных блокнотах и Excel приводит к ошибкам.\n• Отсутствие контроля остатков влечет списание 'в минус' и срыв отгрузок.\n• Пересортица на складе и несвоевременный заказ дефицитных позиций.", RGBColor(239, 68, 68)),
    ("Цель проекта", "• Разработка надежного настольного приложения для складского учета малого предприятия.\n• Автоматизация приходов, отгрузок, списания брака и инвентаризации.\n• Мгновенный контроль остатков и предупреждение о дефиците.", ACCENT_BLUE),
    ("Ключевой результат", "• Полнофункциональное WinForms-приложение с дашбордом KPI.\n• 100% защита от отрицательных остатков.\n• Автоматическое формирование ведомостей и экспорт в CSV.", ACCENT_GREEN)
])

# SLIDE 3: Architecture & Tech Stack
add_cards_slide(prs, "Архитектура решения и технологический стек", "АРХИТЕКТУРА SOLUTION", [
    ("Core (Domain & Logic)", "• Чистая доменная модель (Product, Operation, Category).\n• Бизнес-сервисы IWarehouseService и IReportService.\n• Строгая валидация и кастомные исключения.", ACCENT_BLUE),
    ("Presentation (WinForms)", "• MainForm: интерактивный дашборд с 4 карточками KPI.\n• DataGridView с подсветкой дефицитных позиций.\n• Диалоги ProductEditForm, OperationForm, ReportsForm.", ACCENT_CYAN),
    ("Storage & QA (Tests)", "• Реляционная БД Microsoft Access (warehouse.accdb).\n• 14 модульных тестов xUnit в Test Explorer.\n• Git Flow: ветки feature/*, PR, код-ревью.", ACCENT_GREEN)
])

# Helper for diagram slide
def add_diagram_slide(prs, title, cat, img_path, desc_points):
    s = prs.slides.add_slide(blank_slide_layout)
    set_slide_background(s)
    add_header(s, title, cat)
    
    # Left side: image
    if os.path.exists(img_path):
        s.shapes.add_picture(img_path, Inches(0.8), Inches(1.7), width=Inches(7.2))
    
    # Right side: text card
    card = s.shapes.add_shape(MSO_SHAPE.ROUNDED_RECTANGLE, Inches(8.3), Inches(1.7), Inches(4.2), Inches(5.0))
    card.fill.solid()
    card.fill.fore_color.rgb = CARD_BG
    card.line.color.rgb = ACCENT_BLUE
    card.line.width = Pt(1.5)
    
    tb = s.shapes.add_textbox(Inches(8.5), Inches(1.9), Inches(3.8), Inches(4.6))
    tf = tb.text_frame
    tf.word_wrap = True
    
    p = tf.paragraphs[0]
    p.text = "Ключевые элементы"
    p.font.name = 'Arial'
    p.font.size = Pt(15)
    p.font.bold = True
    p.font.color.rgb = ACCENT_CYAN
    
    for point in desc_points:
        p_pt = tf.add_paragraph()
        p_pt.text = "• " + point
        p_pt.font.name = 'Arial'
        p_pt.font.size = Pt(11)
        p_pt.font.color.rgb = RGBColor(226, 232, 240)
        p_pt.space_before = Pt(8)
    return s

# SLIDE 4: Use Case Diagram
add_diagram_slide(prs, "Диаграмма вариантов использования (Use Case)", "ПРОЕКТИРОВАНИЕ",
    'docs/Diagrams/use_case_diagram.png', [
        "Актёр 'Кладовщик': оформление прихода товаров, регистрация отгрузки клиентам, списание брака, инвентаризация.",
        "Актёр 'Менеджер по закупкам': оперативный мониторинг позиций в дефиците, контроль минимальных запасов, дозаказ.",
        "Актёр 'Администратор': просмотр журнала всех операций, формирование аналитических отчетов и выгрузка в CSV.",
        "Системные прецеденты строго разграничены по ролям пользователей."
    ])

# SLIDE 5: ER Diagram
add_diagram_slide(prs, "ER-диаграмма модели данных (Entity-Relationship)", "СТРУКТУРА ДАННЫХ",
    'docs/Diagrams/er_diagram.png', [
        "Сущность Products: артикул SKU, цены закупки и продажи, остаток, минимальный запас, ячейка стеллажа.",
        "Сущность Categories: древовидная классификация номенклатуры (инструмент, крепеж, химия).",
        "Сущность Counterparties: база поставщиков и покупателей с контактами.",
        "Сущность WarehouseOperations: журнал проводок прихода, расхода, списания и инвентаризации с датой и автором."
    ])

# SLIDE 6: Class Diagram
add_diagram_slide(prs, "Архитектурная диаграмма классов системы", "АРХИТЕКТУРА КЛАССОВ",
    'docs/Diagrams/class_diagram.png', [
        "Слой Domain: сущности Product, Category, Counterparty, WarehouseOperation.",
        "Слой Data: интерфейс IWarehouseRepository и AccessWarehouseRepository (OLE DB).",
        "Слой Services: бизнес-логика IWarehouseService и аналитика IReportService.",
        "Слой Presentation: формы MainForm, OperationForm, ProductEditForm, ReportsForm."
    ])

# SLIDE 7: Sequence Diagram
add_diagram_slide(prs, "Диаграмма последовательности: Оформление отгрузки", "СЦЕНАРИИ РАБОТЫ",
    'docs/Diagrams/sequence_diagram.png', [
        "1. Кладовщик инициирует операцию расхода в MainForm.",
        "2. OperationForm запрашивает текущее наличие у WarehouseService.",
        "3. Валидация: если запрашиваемое количество превышает остаток, генерируется InsufficientStockException.",
        "4. При успешной проверке: остаток уменьшается, создается проводка в журнале и сохраняется в БД Access.",
        "5. MainForm реактивно обновляет DataGridView и KPI-карточки."
    ])

# SLIDE 8: UI Dashboard Demo
add_cards_slide(prs, "Пользовательский интерфейс: Главный дашборд", "ИНТЕРФЕЙС И UX", [
    ("Интерактивные KPI", "• Всего номенклатурных позиций.\n• Физический остаток товаров на складе.\n• Суммарная финансовая оценка склада (в рублях).\n• Число позиций в дефиците (яркий акцент).", ACCENT_BLUE),
    ("Умная таблица остатков", "• Автоматическая подсветка строк с дефицитом нежно-красным цветом.\n• Отображение цен, статусов и ячеек хранения.\n• Быстрый переход к редактированию по двойному клику.", ACCENT_CYAN),
    ("Быстрый поиск и фильтры", "• Поиск в реальном времени по артикулу, названию и ячейке стеллажа.\n• Фильтрация по категориям товаров.\n• Чекбокс мгновенного отбора только дефицитных позиций.", ACCENT_GREEN)
])

# SLIDE 9: Warehouse Operations
add_cards_slide(prs, "Модуль проведения складских операций", "ДОКУМЕНТООБОРОТ", [
    ("Приход товара (+)", "• Поступление от поставщика.\n• Автоматическое увеличение складского остатка.\n• Обновление учетной цены закупки.\n• Генерация номера документа (ПР-0001).", ACCENT_GREEN),
    ("Отгрузка клиенту (-)", "• Реализация заказчику.\n• Жесткий контроль наличия: блокировка списания в минус.\n• Расчет выручки по цене реализации.\n• Генерация документа расхода (РХ-0001).", ACCENT_BLUE),
    ("Списание и инвентаризация", "• Списание повреждений и брака с указанием причины.\n• Инвентаризация: ввод фактического наличия и фиксация расхождений.\n• Фиксация ответственного сотрудника.", RGBColor(217, 119, 6))
])

# SLIDE 10: Reports & Analytics
add_cards_slide(prs, "Модуль аналитических отчетов и экспорт в CSV", "АНАЛИТИКА И ОТЧЕТНОСТЬ", [
    ("Ведомость остатков", "• Полная инвентарная ведомость всех позиций.\n• Оценка склада по себестоимости закупки.\n• Индикация дефицита и ячеек размещения.\n• Экспорт в формат CSV для Excel в 1 клик.", ACCENT_BLUE),
    ("Ведомость дефицита", "• Автоматический отбор позиций с остатком ниже минимума.\n• Расчет рекомендуемого объема дозаказа.\n• Расчет необходимого бюджета на пополнение склада.", RGBColor(239, 68, 68)),
    ("Движение товаров (обороты)", "• Оборотно-сальдовая ведомость за выбранный период.\n• Суммарный объем приходов и отгрузок в рублях и штуках.\n• Контроль списаний брака.", ACCENT_GREEN)
])

# SLIDE 11: Teamwork, Visual Studio & Git
add_cards_slide(prs, "Инструменты Visual Studio 2022 и процесс Git", "КОМАНДНАЯ РАЗРАБОТКА", [
    ("Возможности Visual Studio", "• Многопроектный Solution (Core + UI + Tests).\n• Test Explorer: выполнение 14 автоматических тестов.\n• Интегрированный отладчик и NuGet пакеты.", ACCENT_CYAN),
    ("Git Flow и распределение", "• Ветки: feature/solution-setup, feature/domain-and-storage, feature/services, feature/dashboard.\n• Pull Requests с взаимным код-ревью.\n• Осмысленная история коммитов (Conventional Commits).", ACCENT_BLUE),
    ("Индивидуальный вклад", "• Ложкин (Тимлид): 14 коммитов, 5 PR.\n• Барышев (UI): 10 коммитов, 3 PR.\n• Рейтер (Data & QA): 8 коммитов, 3 PR.\n• Статистика полностью подтверждена в Git-логе.", ACCENT_GREEN)
])

# SLIDE 12: Conclusion & Defense
add_cards_slide(prs, "Итоги выполнения проекта и перспективы", "ИТОГИ И ЗАЩИТА", [
    ("Достигнутые результаты", "• 100% реализация всех требований ТЗ по Теме 9.\n• Разработано надежное, быстрое приложение WinForms.\n• Успешно пройдены все 14 модульных тестов xUnit.\n• Подготовлена полная проектная документация.", ACCENT_GREEN),
    ("Полученные навыки", "• Проектирование чистой многозвенной архитектуры C#/.NET.\n• Профессиональное использование Git Flow и разрешение конфликтов.\n• Разработка удобного UX для сотрудников склада.", ACCENT_BLUE),
    ("Перспективы развития", "• Подключение сканера штрих-кодов и печать этикеток.\n• Сетевая синхронизация через клиент-серверную СУБД / REST API.\n• Интеграция с 1С:Предприятие.", ACCENT_CYAN)
])

pptx_path = 'docs/Презентация_Складской_учёт_Тема_9.pptx'
prs.save(pptx_path)
print(f"PPTX presentation created at {pptx_path}")

# ==========================================
# 2. PDF PRESENTATION GENERATION (ReportLab)
# ==========================================
pdf_pres_path = 'docs/Презентация_Складской_учёт_Тема_9.pdf'

doc_pdf = SimpleDocTemplate(
    pdf_pres_path,
    pagesize=landscape(A4),
    leftMargin=15*mm,
    rightMargin=15*mm,
    topMargin=15*mm,
    bottomMargin=15*mm
)

p_styles = getSampleStyleSheet()

slide_title_style = ParagraphStyle(
    'SlideTitle',
    fontName='Arial-Bold',
    fontSize=18,
    leading=22,
    textColor=colors.HexColor('#0F172A')
)

slide_cat_style = ParagraphStyle(
    'SlideCat',
    fontName='Arial-Bold',
    fontSize=10,
    leading=13,
    textColor=colors.HexColor('#2563EB')
)

slide_body = ParagraphStyle(
    'SlideBody',
    fontName='Arial',
    fontSize=9,
    leading=13,
    textColor=colors.HexColor('#1E293B')
)

card_title = ParagraphStyle(
    'CardTitle',
    fontName='Arial-Bold',
    fontSize=11,
    leading=14,
    textColor=colors.HexColor('#0F172A')
)

pdf_story = []

slides_content = [
    ("ГРУППОВОЙ ПРОЕКТ • ТЕМА № 9", "Складской учёт (мини-версия)", [
        "<b>Дисциплина:</b> «Разработка приложения в Visual Studio + Git + защита»",
        "<b>Состав команды:</b><br/>• <b>Ложкин</b> — Тимлид, Архитектор решения<br/>• <b>Барышев</b> — Разработчик WinForms UI/UX<br/>• <b>Рейтер</b> — Разработчик БД, QA-инженер",
        "<b>Стек технологий:</b> Microsoft .NET 9.0 (C# 13), Windows Forms, xUnit (14 тестов), Git Flow, MS Access (warehouse.accdb)"
    ], None),
    ("АКТУАЛЬНОСТЬ И ЦЕЛЬ", "Проблема, актуальность и цель проекта", [
        "<b>Проблема:</b> ручной учет и таблицы Excel приводят к пересортице, списанию в минус и дефициту.",
        "<b>Цель проекта:</b> компактное и быстрое настольное приложение для комплексной автоматизации малого склада.",
        "<b>Результат:</b> интуитивный дашборд с KPI, 100% защита от отрицательных остатков, экспорт отчетов в CSV."
    ], None),
    ("АРХИТЕКТУРА SOLUTION", "Архитектура решения и технологический стек", [
        "<b>Core Layer:</b> доменные модели Product, Operation, Category; бизнес-сервисы WarehouseService, ReportService.",
        "<b>Presentation Layer:</b> интерфейс WinForms (MainForm, ProductEditForm, OperationForm, ReportsForm).",
        "<b>Testing & Storage:</b> 14 тестов xUnit, СУБД Microsoft Access (warehouse.accdb), ветки Git Flow."
    ], None),
    ("ПРОЕКТИРОВАНИЕ", "Диаграмма вариантов использования (Use Case)", [
        "<b>Кладовщик:</b> проведение приходов, отгрузок, списания брака, инвентаризация.",
        "<b>Менеджер по закупкам:</b> контроль дефицита, формирование заказов поставщикам.",
        "<b>Администратор:</b> журнал документов, выгрузка аналитики в CSV."
    ], 'docs/Diagrams/use_case_diagram.png'),
    ("СТРУКТУРА ДАННЫХ", "ER-диаграмма модели данных склада", [
        "<b>Products:</b> артикул SKU, остаток, цена закупки, цена продажи, минимальный запас, ячейка.",
        "<b>Categories & Counterparties:</b> классификация товаров и контакты контрагентов.",
        "<b>WarehouseOperations:</b> история приходов, расходов, списаний с датой и автором."
    ], 'docs/Diagrams/er_diagram.png'),
    ("АРХИТЕКТУРА КЛАССОВ", "Архитектурная диаграмма классов системы", [
        "<b>Domain:</b> сущности Product, Category, Counterparty, WarehouseOperation.",
        "<b>Data & Services:</b> IWarehouseRepository, AccessWarehouseRepository, WarehouseService, ReportService.",
        "<b>Presentation:</b> формы MainForm, OperationForm, ReportsForm, CategoriesForm."
    ], 'docs/Diagrams/class_diagram.png'),
    ("СЦЕНАРИИ РАБОТЫ", "Диаграмма последовательности: Оформление отгрузки", [
        "<b>1.</b> Кладовщик нажимает кнопку 'Отгрузка' в MainForm.",
        "<b>2.</b> OperationForm запрашивает наличие и проверяет достаточность остатка.",
        "<b>3.</b> При нехватке выбрасывается InsufficientStockException; при успехе остаток списывается и обновляется UI."
    ], 'docs/Diagrams/sequence_diagram.png'),
    ("ИНТЕРФЕЙС И UX", "Пользовательский интерфейс: Главный дашборд", [
        "<b>Интерактивные KPI-карточки:</b> общее число позиций, физический остаток, оценка склада, количество в дефиците.",
        "<b>Таблица DataGridView:</b> подсветка позиций в дефиците нежно-красным цветом.",
        "<b>Быстрый поиск и фильтры:</b> мгновенная фильтрация по названию, артикулу, категории и дефициту."
    ], None),
    ("ДОКУМЕНТООБОРОТ", "Модуль складских документов и операций", [
        "<b>Приход товара (+):</b> регистрация поступления, увеличение остатка, обновление цены закупки.",
        "<b>Отгрузка клиенту (-):</b> списание со склада с жестким контролем наличия (защита от минуса).",
        "<b>Списание и инвентаризация:</b> списание повреждений и выравнивание фактических остатков."
    ], None),
    ("АНАЛИТИКА", "Модуль аналитических отчетов и экспорт в CSV", [
        "<b>Ведомость остатков:</b> инвентарный список номенклатуры и оценка стоимости склада.",
        "<b>Ведомость дефицита:</b> список товаров к заказу с расчетом требуемого бюджета.",
        "<b>Движение товаров:</b> оборотно-сальдовая ведомость приходов и отгрузок за период."
    ], None),
    ("КОМАНДНАЯ РАБОТА", "Инструменты Visual Studio 2022 и процесс Git", [
        "<b>Visual Studio:</b> Solution с 3 проектами, Test Explorer, NuGet пакеты, встроенный отладчик.",
        "<b>Git Flow:</b> ветки feature/*, Pull Requests, код-ревью, осмысленная история коммитов.",
        "<b>Вклад:</b> Ложкин (14 коммитов, 5 PR), Барышев (10 коммитов, 3 PR), Рейтер (8 коммитов, 3 PR)."
    ], None),
    ("ИТОГИ И ЗАЩИТА", "Итоги выполнения проекта и перспективы", [
        "<b>Результаты:</b> 100% выполнение требований ТЗ, прохождение всех 14 тестов xUnit, готовый релиз.",
        "<b>Навыки:</b> командная работа в Git, архитектура C#/.NET, проектирование десктопного UX.",
        "<b>Перспективы:</b> интеграция со сканерами штрих-кодов, печать ценников, синхронизация с 1С."
    ], None)
]

for idx, (cat, title, points, img) in enumerate(slides_content):
    pdf_story.append(Paragraph(cat, slide_cat_style))
    pdf_story.append(Paragraph(title, slide_title_style))
    pdf_story.append(Spacer(1, 4*mm))
    
    if img and os.path.exists(img):
        # Image + text layout
        img_flow = Image(img, width=170*mm, height=105*mm)
        text_content = [Paragraph(p, slide_body) for p in points]
        
        t_slide = Table([[img_flow, text_content]], colWidths=[175*mm, 90*mm])
        t_slide.setStyle(TableStyle([
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
            ('LEFTPADDING', (1, 0), (1, 0), 10),
            ('RIGHTPADDING', (0, 0), (-1, -1), 0),
        ]))
        pdf_story.append(t_slide)
    else:
        # 3 cards layout
        cards_cells = []
        for p in points:
            cards_cells.append([Paragraph(p, slide_body)])
            
        t_cards = Table([cards_cells], colWidths=[88*mm, 88*mm, 88*mm])
        t_cards.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, -1), colors.HexColor('#F8FAFC')),
            ('BOX', (0, 0), (0, 0), 1, colors.HexColor('#2563EB')),
            ('BOX', (1, 0), (1, 0), 1, colors.HexColor('#0284C7')),
            ('BOX', (2, 0), (2, 0), 1, colors.HexColor('#10B981')),
            ('TOPPADDING', (0, 0), (-1, -1), 15),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 15),
            ('LEFTPADDING', (0, 0), (-1, -1), 12),
            ('RIGHTPADDING', (0, 0), (-1, -1), 12),
            ('VALIGN', (0, 0), (-1, -1), 'TOP'),
        ]))
        pdf_story.append(Spacer(1, 10*mm))
        pdf_story.append(t_cards)
        
    if idx < len(slides_content) - 1:
        pdf_story.append(PageBreak())

doc_pdf.build(pdf_story)
print(f"PDF presentation created at {pdf_pres_path}")
