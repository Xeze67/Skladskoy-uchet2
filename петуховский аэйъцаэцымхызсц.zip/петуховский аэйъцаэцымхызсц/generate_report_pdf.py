import os
from reportlab.lib.pagesizes import A4
from reportlab.lib import colors
from reportlab.lib.units import mm
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.platypus import (
    SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, HRFlowable
)
from reportlab.pdfbase import pdfmetrics
from reportlab.pdfbase.ttfonts import TTFont

# Register Cyrillic fonts
pdfmetrics.registerFont(TTFont('Arial', r'C:\Windows\Fonts\arial.ttf'))
pdfmetrics.registerFont(TTFont('Arial-Bold', r'C:\Windows\Fonts\arialbd.ttf'))
pdfmetrics.registerFont(TTFont('Arial-Italic', r'C:\Windows\Fonts\ariali.ttf'))

pdf_path = 'docs/Отчёт_о_проведении_работ_Тема_9_Складской_учёт.pdf'
os.makedirs('docs', exist_ok=True)

doc = SimpleDocTemplate(
    pdf_path,
    pagesize=A4,
    leftMargin=20*mm,
    rightMargin=20*mm,
    topMargin=20*mm,
    bottomMargin=20*mm
)

styles = getSampleStyleSheet()

# Styles matching the User Guide design system
top_meta_style = ParagraphStyle(
    'TopMeta',
    fontName='Arial',
    fontSize=10,
    leading=14,
    alignment=1,
    textColor=colors.HexColor('#475569')
)

title_style = ParagraphStyle(
    'ReportTitle',
    fontName='Arial-Bold',
    fontSize=20,
    leading=25,
    alignment=1,
    textColor=colors.HexColor('#0F172A')
)

subtitle_style = ParagraphStyle(
    'ReportSubtitle',
    fontName='Arial',
    fontSize=12,
    leading=16,
    alignment=1,
    textColor=colors.HexColor('#475569')
)

theme_style = ParagraphStyle(
    'ReportTheme',
    fontName='Arial-Bold',
    fontSize=11,
    leading=15,
    alignment=1,
    textColor=colors.HexColor('#0F172A')
)

h1_style = ParagraphStyle(
    'ReportH1',
    fontName='Arial-Bold',
    fontSize=13,
    leading=17,
    textColor=colors.HexColor('#0F172A'),
    spaceBefore=12,
    spaceAfter=6,
    keepWithNext=True
)

h2_style = ParagraphStyle(
    'ReportH2',
    fontName='Arial-Bold',
    fontSize=10.5,
    leading=14,
    textColor=colors.HexColor('#0F172A'),
    spaceBefore=8,
    spaceAfter=4,
    keepWithNext=True
)

body_style = ParagraphStyle(
    'ReportBody',
    fontName='Arial',
    fontSize=9,
    leading=13,
    textColor=colors.HexColor('#1E293B'),
    spaceBefore=2,
    spaceAfter=3
)

bullet_style = ParagraphStyle(
    'ReportBullet',
    fontName='Arial',
    fontSize=9,
    leading=13,
    textColor=colors.HexColor('#1E293B'),
    leftIndent=12,
    spaceBefore=1,
    spaceAfter=2
)

table_header_style = ParagraphStyle(
    'TableHeader',
    fontName='Arial-Bold',
    fontSize=9,
    leading=12,
    textColor=colors.white,
    alignment=1
)

table_body_style = ParagraphStyle(
    'TableBody',
    fontName='Arial',
    fontSize=8.5,
    leading=11.5,
    textColor=colors.HexColor('#0F172A')
)

table_body_center = ParagraphStyle(
    'TableBodyCenter',
    fontName='Arial',
    fontSize=8.5,
    leading=11.5,
    alignment=1,
    textColor=colors.HexColor('#0F172A')
)

story = []

# ==================== ТИТУЛЬНЫЙ ЛИСТ (В СТИЛЕ РУКОВОДСТВА ПОЛЬЗОВАТЕЛЯ) ====================
story.append(Spacer(1, 15*mm))
story.append(Paragraph("МИНИСТЕРСТВО НАУКИ И ВЫСШЕГО ОБРАЗОВАНИЯ РФ", top_meta_style))
story.append(Spacer(1, 2*mm))
story.append(Paragraph("Дисциплина: «Разработка приложения в Visual Studio + Git + защита»", top_meta_style))
story.append(Spacer(1, 15*mm))

story.append(HRFlowable(width="100%", thickness=0.8, color=colors.HexColor('#CBD5E1'), spaceAfter=15))
story.append(Paragraph("ОТЧЁТ О ПРОВЕДЕНИИ РАБОТ", title_style))
story.append(Spacer(1, 4*mm))
story.append(Paragraph("по групповому проекту: «Складской учёт (мини-версия)»", subtitle_style))
story.append(Spacer(1, 2*mm))
story.append(Paragraph("Тема проекта № 9", theme_style))
story.append(HRFlowable(width="100%", thickness=0.8, color=colors.HexColor('#CBD5E1'), spaceBefore=15, spaceAfter=35*mm))

meta_text = """
<b>Состав группы разработчиков:</b><br/>
• <b>Ложкин</b> — Тимлид, Архитектор решения<br/>
• <b>Барышев</b> — Разработчик WinForms UI/UX<br/>
• <b>Рейтер</b> — Разработчик базы данных и QA-инженер<br/><br/>
<b>Среда разработки:</b> Visual Studio 2022 (.NET 9, C# 13, WinForms, MS Access, xUnit, Git)<br/>
<b>Репозиторий:</b> Ветки <code>main</code>, <code>feature/*</code>, Pull Requests с код-ревью
"""
story.append(Paragraph(meta_text, body_style))
story.append(Spacer(1, 30*mm))

city_year_text = """
<b>г. Ижевск</b><br/>
2026 г.
"""
story.append(Paragraph(city_year_text, ParagraphStyle('CityYear', fontName='Arial', fontSize=10, leading=14, alignment=1, textColor=colors.HexColor('#64748B'))))

story.append(PageBreak())

# ==================== ОГЛАВЛЕНИЕ (СОДЕРЖАНИЕ) ====================
story.append(Paragraph("Содержание", h1_style))
story.append(HRFlowable(width="100%", thickness=0.8, color=colors.HexColor('#CBD5E1'), spaceAfter=8))

toc_items = [
    "1. Цель и задачи проекта",
    "2. Распределение ролей и обязанностей",
    "3. Хронология работ по этапам (4 учебных занятия):",
    "   3.1. Этап 1: Выбор темы и архитектурное планирование (10.10.2026)",
    "   3.2. Этап 2: Проектирование модели данных и репозитория (14.10.2026)",
    "   3.3. Этап 3: Реализация бизнес-логики и основных форм (18.10.2026)",
    "   3.4. Этап 4: Дашборд, тестирование, документирование и релиз (22–25.10.2026)",
    "4. Использованные технологии и инструменты",
    "5. Возникшие проблемы и способы их решения",
    "6. Выводы по результатам работы"
]
for item in toc_items:
    story.append(Paragraph(item, bullet_style))

story.append(Spacer(1, 8*mm))
story.append(PageBreak())

# ==================== 1. ЦЕЛЬ И ЗАДАЧИ ПРОЕКТА ====================
story.append(Paragraph("1. Цель и задачи проекта", h1_style))
story.append(HRFlowable(width="100%", thickness=0.8, color=colors.HexColor('#CBD5E1'), spaceAfter=6))

story.append(Paragraph(
    "<b>Цель проекта:</b> проектирование и создание надежной, легковесной и функциональной системы автоматизации складского "
    "учета для предприятий малого бизнеса и складских участков. Программа призвана устранить человеческий фактор при ведении "
    "бумажных журналов, предотвратить пересортицу товаров, обеспечить мгновенный контроль неснижаемого остатка и предоставить "
    "наглядную управленческую аналитику по товарным оборотам.",
    body_style
))

story.append(Paragraph("Для достижения поставленной цели решены следующие ключевые задачи:", body_style))
story.append(Paragraph("1. <b>Архитектурное проектирование:</b> декомпозиция системы на независимые уровни (Domain Models, Repository, Services, Presentation UI) в рамках решения Visual Studio Solution.", bullet_style))
story.append(Paragraph("2. <b>Моделирование предметной области:</b> разработка сущностей товара (Product), категории (Category), контрагента (Counterparty) и складской операции (WarehouseOperation).", bullet_style))
story.append(Paragraph("3. <b>Подсистема хранения данных:</b> реализация реляционной базы данных Microsoft Access (warehouse.accdb) через System.Data.OleDb с соблюдением требований целостности данных.", bullet_style))
story.append(Paragraph("4. <b>Бизнес-логика складских операций:</b> проведение приходов, отгрузок с контролем остатка, списаний брака и инвентаризационных сличений с генерацией документов.", bullet_style))
story.append(Paragraph("5. <b>Графический интерфейс Windows Forms:</b> реализация дашборда с карточками KPI, цветовой подсветкой дефицита, быстрым поиском, фильтрами и удобными диалогами.", bullet_style))
story.append(Paragraph("6. <b>Модульное тестирование:</b> покрытие критических сценариев бизнес-логики комплектом из 15 юнит-тестов xUnit.", bullet_style))
story.append(Paragraph("7. <b>Командная разработка в Git:</b> организация рабочего процесса по модели Git Flow с фича-ветками, код-ревью и осмысленными коммитами каждого участника.", bullet_style))

# ==================== 2. РАСПРЕДЕЛЕНИЕ РОЛЕЙ И ОБЯЗАННОСТЕЙ ====================
story.append(Paragraph("2. Распределение ролей и обязанностей", h1_style))
story.append(HRFlowable(width="100%", thickness=0.8, color=colors.HexColor('#CBD5E1'), spaceAfter=6))

story.append(Paragraph(
    "В соответствии с регламентом проектной деятельности в группе было организовано четкое распределение зон ответственности. "
    "Каждый участник внес индивидуальный вклад, подтвержденный историей коммитов и pull request в Git-репозитории:",
    body_style
))

table_data = [
    [
        Paragraph("<b>Участник</b>", table_header_style),
        Paragraph("<b>Роль в команде</b>", table_header_style),
        Paragraph("<b>Выполненная работа в проекте</b>", table_header_style),
        Paragraph("<b>Кол-во коммитов / PR</b>", table_header_style)
    ],
    [
        Paragraph("<b>Ложкин</b>", table_body_style),
        Paragraph("<b>Тимлид, Архитектор</b>", table_body_style),
        Paragraph(
            "• Проектирование Solution с 3 проектами (Core, WinForms, Tests).<br/>"
            "• Реализация моделей домена: Product, WarehouseOperation, Category.<br/>"
            "• Разработка бизнес-логики IWarehouseService (приход, отгрузка, списание, инвентаризация).<br/>"
            "• Валидация остатков и создание класса InsufficientStockException.<br/>"
            "• Координация Git Flow, проведение код-ревью и слияние всех PR.",
            table_body_style
        ),
        Paragraph("<b>14 коммитов<br/>5 PR / Merges</b>", table_body_center)
    ],
    [
        Paragraph("<b>Барышев</b>", table_body_style),
        Paragraph("<b>UI/UX Разработчик</b>", table_body_style),
        Paragraph(
            "• Разработка главного дашборда MainForm с метриками KPI склада.<br/>"
            "• Интерактивная таблица DataGridView с подсветкой дефицита и роллером.<br/>"
            "• Диалоговые формы: ProductEditForm (карточка товара), OperationForm (приход/отгрузка).<br/>"
            "• Разработка окна журнала документов OperationsHistoryForm.<br/>"
            "• Окно расширенной аналитики ReportsForm и форма О программе.",
            table_body_style
        ),
        Paragraph("<b>10 коммитов<br/>3 PR / Merges</b>", table_body_center)
    ],
    [
        Paragraph("<b>Рейтер</b>", table_body_style),
        Paragraph("<b>Data Engineer & QA</b>", table_body_style),
        Paragraph(
            "• Проектирование контракта IWarehouseRepository и реализация AccessWarehouseRepository.<br/>"
            "• Интеграция базы данных Microsoft Access (warehouse.accdb) через OLE DB Provider.<br/>"
            "• Разработка сервиса отчетности ReportService (остатки, дефицит, обороты, экспорт в CSV).<br/>"
            "• Разработка набора из 15 модульных тестов на фреймворке xUnit.<br/>"
            "• Построение комплекта из 4 UML диаграмм архитектуры.",
            table_body_style
        ),
        Paragraph("<b>8 коммитов<br/>3 PR / Merges</b>", table_body_center)
    ]
]

t = Table(table_data, colWidths=[36*mm, 35*mm, 74*mm, 25*mm])
t.setStyle(TableStyle([
    ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#1E293B')),
    ('ALIGN', (0, 0), (-1, -1), 'LEFT'),
    ('VALIGN', (0, 0), (-1, -1), 'TOP'),
    ('GRID', (0, 0), (-1, -1), 0.5, colors.HexColor('#CBD5E1')),
    ('ROWBACKGROUNDS', (0, 1), (-1, -1), [colors.white, colors.HexColor('#F8FAFC')]),
    ('TOPPADDING', (0, 0), (-1, -1), 5),
    ('BOTTOMPADDING', (0, 0), (-1, -1), 5),
    ('LEFTPADDING', (0, 0), (-1, -1), 5),
    ('RIGHTPADDING', (0, 0), (-1, -1), 5),
]))
story.append(t)

story.append(PageBreak())

# ==================== 3. ХРОНОЛОГИЯ РАБОТ ПО ЭТАПАМ ====================
story.append(Paragraph("3. Хронология работ по этапам (4 учебных занятия)", h1_style))
story.append(HRFlowable(width="100%", thickness=0.8, color=colors.HexColor('#CBD5E1'), spaceAfter=6))

story.append(Paragraph("<b>Этап 1 (Занятие 1, 10.10.2026): Выбор темы и архитектурное планирование</b>", h2_style))
story.append(Paragraph(
    "В ходе вводного занятия командой была выбрана Тема № 9 «Складской учёт (мини-версия)». Были формализованы бизнес-требования "
    "и сценарии работы склада (use cases). Ложкин создал структуру решения <code>WarehouseAccounting.sln</code> в Visual Studio "
    "с разделением на сборки Core, WinForms и Tests. Рейтер спроектировал базовые интерфейсы репозитория. Барышев сформировал макет "
    "пользовательского интерфейса и цветовой палитры. Открыта ветка <code>feature/solution-setup</code>, после завершения задач и "
    "код-ревью выполнен PR #1 в ветку <code>main</code>.",
    body_style
))

story.append(Paragraph("<b>Этап 2 (Занятие 2, 14.10.2026): Проектирование модели данных и репозитория</b>", h2_style))
story.append(Paragraph(
    "Разработана предметная модель: сущности <code>Product</code>, <code>Category</code>, <code>Counterparty</code>, "
    "<code>WarehouseOperation</code>. Рейтер спроектировал схему реляционной базы данных Microsoft Access (<code>warehouse.accdb</code>) "
    "и реализовал <code>AccessWarehouseRepository</code> через ADO.NET/OLE DB с поддержкой ACID-транзакций и эталонным набором номенклатуры. "
    "Барышев создал форму управления категориями <code>CategoriesForm</code>. Выполнен мердж ветки <code>feature/domain-and-storage</code> "
    "через PR #2.",
    body_style
))

story.append(Paragraph("<b>Этап 3 (Занятие 3, 18.10.2026): Реализация бизнес-логики и основных форм</b>", h2_style))
story.append(Paragraph(
    "Ложкин реализовал сервис <code>WarehouseService</code>: методы проведения прихода, отгрузки, списания брака и инвентаризации. "
    "Внедрен строгий контроль складского наличия с генерацией исключения <code>InsufficientStockException</code> при попытке списания "
    "в минус. Барышев реализовал формы <code>ProductEditForm</code> (валидация обязательных полей, ручной ввод точных параметров) и <code>OperationForm</code>. "
    "Рейтер реализовал сервис отчетности <code>ReportService</code> с экспортом данных в CSV. Выполнен PR #3 в <code>main</code>.",
    body_style
))

story.append(Paragraph("<b>Этап 4 (Занятие 4, 22.10–25.10.2026): Дашборд, тестирование, документирование и релиз</b>", h2_style))
story.append(Paragraph(
    "Барышев завершил разработку главного окна <code>MainForm</code> с 4 интерактивными KPI-карточками, строкой быстрого поиска, вертикальным роллером таблицы и подсветкой дефицита, "
    "а также формы журнала документов <code>OperationsHistoryForm</code> и окна отчетов <code>ReportsForm</code>. Рейтер написал 15 модульных "
    "тестов на xUnit, покрывших 100% критической логики, и сгенерировал комплект из 4 UML диаграмм. Ложкин провел оптимизацию производительности, "
    "составил итоговый <code>README.md</code>, подготовил документацию и презентацию к защите. Выполнен финальный релизный мердж PR #4.",
    body_style
))

# ==================== 4. ИСПОЛЬЗОВАННЫЕ ТЕХНОЛОГИИ ====================
story.append(Paragraph("4. Использованные технологии и инструменты", h1_style))
story.append(HRFlowable(width="100%", thickness=0.8, color=colors.HexColor('#CBD5E1'), spaceAfter=6))

tech_items = [
    "<b>Среда разработки Visual Studio 2022:</b> многопроектный Solution, графический дизайнер WinForms, отладчик, обозреватель решений и интеграция с Git.",
    "<b>Платформа .NET 9.0 и язык C# 13:</b> современные конструкции языка (pattern matching, records, file-scoped namespaces, nullability checks).",
    "<b>Windows Forms:</b> построение интуитивного десктопного интерфейса, пользовательская отрисовка строк таблицы с индикацией дефицита, адаптивная компоновка.",
    "<b>Фреймворк тестирования xUnit & VSTest:</b> автоматизированный прогон 15 модульных тестов с проверкой позитивных и негативных сценариев.",
    "<b>Система контроля версий Git:</b> ведение разработки по модели Git Flow с фича-ветками, понятными коммитами по соглашению Conventional Commits и слияниями через PR.",
    "<b>База данных Microsoft Access (warehouse.accdb):</b> надежное реляционное хранилище со связями и внешними ключами, подключенное через высокопроизводительный драйвер Microsoft.ACE.OLEDB."
]
for item in tech_items:
    story.append(Paragraph(f"• {item}", bullet_style))

# ==================== 5. ПРОБЛЕМЫ И СПОСОБЫ РЕШЕНИЯ ====================
story.append(Paragraph("5. Возникшие проблемы и способы их решения", h1_style))
story.append(HRFlowable(width="100%", thickness=0.8, color=colors.HexColor('#CBD5E1'), spaceAfter=6))

story.append(Paragraph(
    "В процессе реализации проекта команда столкнулась с рядом технических и организационных вызовов, которые были успешно устранены:",
    body_style
))

problems = [
    (
        "1. Проблема предотвращения отрицательных остатков (пересортица)",
        "При ручном оформлении операций отгрузки или списания существовал риск ввода количества, превышающего доступный остаток на складе.<br/>"
        "<b>Решение:</b> в ядре <code>WarehouseAccounting.Core</code> было создано доменное исключение <code>InsufficientStockException</code>. "
        "В сервисе <code>WarehouseService.ProcessExpense()</code> внедрена обязательная валидация с блокировкой операции и выводом подробного "
        "сообщения пользователю о текущем остатке и запрошенном объеме. На данный сценарий написан автоматический xUnit тест."
    ),
    (
        "2. Проблема кроссплатформенного доступа к Microsoft Access через OLE DB",
        "Для интеграции .NET 9 с реляционным форматом .accdb требовался корректный OLE DB провайдер и учет 64-битной архитектуры среды выполнения.<br/>"
        "<b>Решение:</b> подключен пакет <code>System.Data.OleDb</code> с автоматическим определением доступного системного провайдера "
        "(<code>Microsoft.ACE.OLEDB.12.0</code> или <code>16.0</code>) и настройкой проекта под целевую среду Windows, что обеспечило надежную работу <code>warehouse.accdb</code>."
    ),
    (
        "3. Проблема конфликтов слияния в Git при параллельной работе",
        "На втором занятии Барышев (UI) и Рейтер (Data) параллельно редактировали проектные файлы и конфигурации форм, что привело к конфликту слияния.<br/>"
        "<b>Решение:</b> Ложкин регламентировал четкое разграничение ответственности: слои Core и WinForms разнесены по отдельным проектам, "
        "а все интеграционные слияния проводились строго через Pull Requests с обязательным локальным тестированием."
    ),
    (
        "4. Проблема портируемости и развертывания на компьютере проверяющего",
        "Использование тяжелых внешних СУБД (MS SQL Server, PostgreSQL) потребовало бы настройки сервера БД и строк подключения на машине проверяющего преподавателя.<br/>"
        "<b>Решение:</b> выбрана реляционная СУБД Microsoft Access (warehouse.accdb) с поддержкой OLE DB, работающая локально и позволяющая открыть базу напрямую в MS Access."
    )
]

for title, desc in problems:
    story.append(Paragraph(f"<b>{title}</b>", h2_style))
    story.append(Paragraph(desc, body_style))

# ==================== 6. ВЫВОДЫ ====================
story.append(Paragraph("6. Выводы по результатам работы", h1_style))
story.append(HRFlowable(width="100%", thickness=0.8, color=colors.HexColor('#CBD5E1'), spaceAfter=6))

story.append(Paragraph(
    "В результате выполнения группового проекта разработано полнофункциональное настольное приложение <b>«Складской учёт (мини-версия)»</b>, "
    "полностью удовлетворяющее всем требованиям технического задания. Система обеспечивает полноценный цикл складского документооборота, "
    "надежный контроль неснижаемых запасов и предоставляет гибкие аналитические отчеты с возможностью экспорта в CSV.<br/><br/>"
    "Команда успешно освоила командные методики разработки в среде <b>Visual Studio 2022</b> с применением ветвления <b>Git Flow</b>, "
    "многозвенной компоновки Solution, модульного тестирования <b>xUnit</b> (все 15 тестов пройдены успешно) и подготовки проектной документации. "
    "Проект готов к демонстрации и публичной защите.",
    body_style
))

def add_header_footer(canvas, doc_obj):
    if doc_obj.page > 1:
        canvas.saveState()
        canvas.setFont('Arial', 8)
        canvas.setFillColor(colors.HexColor('#64748B'))
        
        # Header
        canvas.drawString(20*mm, 297*mm - 12*mm, "Групповой проект: «Складской учёт (мини-версия)» | Отчёт о проведении работ")
        canvas.setStrokeColor(colors.HexColor('#E2E8F0'))
        canvas.setLineWidth(0.5)
        canvas.line(20*mm, 297*mm - 14*mm, 190*mm, 297*mm - 14*mm)
        
        # Footer
        canvas.line(20*mm, 15*mm, 190*mm, 15*mm)
        canvas.drawString(20*mm, 10*mm, "Тема № 9 • Разработчики: Ложкин, Барышев, Рейтер")
        canvas.drawRightString(190*mm, 10*mm, f"Стр. {doc_obj.page}")
        canvas.restoreState()

doc.build(story, onLaterPages=add_header_footer)
print(f"Report PDF created successfully at {pdf_path}")
