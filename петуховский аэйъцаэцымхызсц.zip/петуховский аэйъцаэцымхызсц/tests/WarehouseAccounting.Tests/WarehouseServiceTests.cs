using System;
using System.IO;
using System.Linq;
using WarehouseAccounting.Core.Data;
using WarehouseAccounting.Core.Exceptions;
using WarehouseAccounting.Core.Models;
using WarehouseAccounting.Core.Services;
using Xunit;

namespace WarehouseAccounting.Tests
{
    public class WarehouseServiceTests : IDisposable
    {
        private readonly string _testDbPath;
        private readonly IWarehouseRepository _repository;
        private readonly IWarehouseService _service;

        public WarehouseServiceTests()
        {
            _testDbPath = Path.Combine(Path.GetTempPath(), $"test_warehouse_{Guid.NewGuid()}.json");
            _repository = new JsonWarehouseRepository(_testDbPath);
            _service = new WarehouseService(_repository);
        }

        public void Dispose()
        {
            if (File.Exists(_testDbPath))
            {
                try { File.Delete(_testDbPath); } catch { }
            }
        }

        [Fact]
        public void ProcessReceipt_IncreasesProductQuantityAndRecordsOperation()
        {
            // Arrange
            var product = _service.GetProducts().First();
            decimal initialQty = product.Quantity;
            decimal receiptQty = 10m;
            decimal price = 1200m;

            // Act
            var op = _service.ProcessReceipt(product.Id, receiptQty, price, null, "Ложкин", "Тестовый приход");

            // Assert
            var updated = _service.GetProductById(product.Id);
            Assert.NotNull(updated);
            Assert.Equal(initialQty + receiptQty, updated.Quantity);
            Assert.Equal(OperationType.Receipt, op.Type);
            Assert.Equal(receiptQty, op.Quantity);
            Assert.StartsWith("ПР-", op.DocumentNumber);
        }

        [Fact]
        public void ProcessReceipt_WithNegativeOrZeroQuantity_ThrowsValidationException()
        {
            var product = _service.GetProducts().First();

            Assert.Throws<WarehouseValidationException>(() =>
                _service.ProcessReceipt(product.Id, 0m, 100m, null, "Тест", ""));

            Assert.Throws<WarehouseValidationException>(() =>
                _service.ProcessReceipt(product.Id, -5m, 100m, null, "Тест", ""));
        }

        [Fact]
        public void ProcessExpense_DecreasesQuantity_WhenStockIsSufficient()
        {
            // Arrange
            var product = _service.GetProducts().First(p => p.Quantity >= 5);
            decimal initialQty = product.Quantity;
            decimal expenseQty = 2m;

            // Act
            var op = _service.ProcessExpense(product.Id, expenseQty, 3000m, null, "Барышев", "Тестовая отгрузка");

            // Assert
            var updated = _service.GetProductById(product.Id);
            Assert.NotNull(updated);
            Assert.Equal(initialQty - expenseQty, updated.Quantity);
            Assert.Equal(OperationType.Expense, op.Type);
            Assert.Equal(expenseQty, op.Quantity);
            Assert.StartsWith("РХ-", op.DocumentNumber);
        }

        [Fact]
        public void ProcessExpense_WhenInsufficientStock_ThrowsInsufficientStockException()
        {
            // Arrange
            var product = _service.GetProducts().First();
            decimal excessiveQty = product.Quantity + 999m;

            // Act & Assert
            var ex = Assert.Throws<InsufficientStockException>(() =>
                _service.ProcessExpense(product.Id, excessiveQty, 1000m, null, "Барышев", "Ошибка"));

            Assert.Equal(product.Id, ex.ProductId);
            Assert.Equal(excessiveQty, ex.RequestedQuantity);
            Assert.Equal(product.Quantity, ex.AvailableQuantity);
        }

        [Fact]
        public void ProcessWriteOff_DecreasesQuantityCorrectly()
        {
            var product = _service.GetProducts().First(p => p.Quantity >= 3);
            decimal initial = product.Quantity;

            var op = _service.ProcessWriteOff(product.Id, 2m, "Брак упаковки", "Рейтер");

            var updated = _service.GetProductById(product.Id);
            Assert.NotNull(updated);
            Assert.Equal(initial - 2m, updated.Quantity);
            Assert.Equal(OperationType.WriteOff, op.Type);
        }

        [Fact]
        public void ProcessInventory_AdjustsQuantityToActual()
        {
            var product = _service.GetProducts().First();
            decimal targetQty = 42m;

            var op = _service.ProcessInventory(product.Id, targetQty, "Рейтер", "Сверка остатков");

            var updated = _service.GetProductById(product.Id);
            Assert.NotNull(updated);
            Assert.Equal(targetQty, updated.Quantity);
            Assert.Equal(OperationType.InventoryAdjustment, op.Type);
        }

        [Fact]
        public void SearchProducts_FiltersByQueryCorrectly()
        {
            var all = _service.GetProducts();
            var first = all.First();

            var searchResult = _service.GetProducts(search: first.Sku);

            Assert.Contains(searchResult, p => p.Id == first.Id);
        }

        [Fact]
        public void GetProducts_OnlyLowStock_ReturnsOnlyDeficitItems()
        {
            var lowStockItems = _service.GetProducts(onlyLowStock: true);

            Assert.NotEmpty(lowStockItems);
            Assert.All(lowStockItems, p => Assert.True(p.IsLowStock));
        }

        [Fact]
        public void DashboardStats_CalculatesAccurateTotals()
        {
            var stats = _service.GetDashboardStats();

            Assert.True(stats.TotalItemTypes > 0);
            Assert.True(stats.TotalStockQuantity > 0);
            Assert.True(stats.TotalStockValueRub > 0);
            Assert.True(stats.TotalOperationsCount > 0);
        }

        [Fact]
        public void AccessWarehouseRepository_CanInitializeAndLoadProducts()
        {
            var repo = new AccessWarehouseRepository();
            var products = repo.GetAllProducts();
            Assert.NotEmpty(products);
            Assert.True(products.Count >= 10);
        }
    }
}
