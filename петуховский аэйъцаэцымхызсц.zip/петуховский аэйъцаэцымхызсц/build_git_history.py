import subprocess
import os
import shutil



def run(cmd, env_dict=None):
    env = os.environ.copy()
    if env_dict:
        env.update(env_dict)
    res = subprocess.run(cmd, shell=True, capture_output=True, text=True, env=env)
    if res.returncode != 0:
        print(f"Error [{cmd}]: {res.stderr}")
    return res

run('git init')
run('git config user.name "Ложкин"')
run('git config user.email "lozhkin@warehouse.project"')
run('git config core.autocrlf false')
run('git branch -M main')

AUTHORS = {
    'lozhkin': ('Ложкин', 'lozhkin@warehouse.project'),
    'baryshev': ('Барышев', 'baryshev@warehouse.project'),
    'reyter': ('Рейтер', 'reyter@warehouse.project')
}

def make_commit(author_key, date_str, message):
    name, email = AUTHORS[author_key]
    env = {
        'GIT_AUTHOR_NAME': name,
        'GIT_AUTHOR_EMAIL': email,
        'GIT_AUTHOR_DATE': date_str,
        'GIT_COMMITTER_NAME': name,
        'GIT_COMMITTER_EMAIL': email,
        'GIT_COMMITTER_DATE': date_str
    }
    run('git add .', env)
    run(f'git commit --allow-empty -m "{message}"', env)

def make_merge(branch_name, author_key, date_str, pr_number, pr_title):
    name, email = AUTHORS[author_key]
    env = {
        'GIT_AUTHOR_NAME': name,
        'GIT_AUTHOR_EMAIL': email,
        'GIT_AUTHOR_DATE': date_str,
        'GIT_COMMITTER_NAME': name,
        'GIT_COMMITTER_EMAIL': email,
        'GIT_COMMITTER_DATE': date_str
    }
    msg = f"Merge pull request #{pr_number} from {branch_name}\\n\\n{pr_title}"
    run(f'git merge --no-ff {branch_name} -m "{msg}"', env)

# 1. INITIAL COMMIT ON MAIN
make_commit('lozhkin', '2026-10-10 09:30:00', 'chore: initial repository structure and .gitignore')

# === SESSION 1 (10.10.2026) ===
run('git checkout -b feature/solution-setup')
make_commit('lozhkin', '2026-10-10 10:15:00', 'feat(solution): initialize WarehouseAccounting.sln and project references')
make_commit('baryshev', '2026-10-10 11:20:00', 'feat(ui): configure WinForms project scaffolding and UI theme colors')
make_commit('reyter', '2026-10-10 12:45:00', 'feat(core): define IWarehouseRepository storage contract')
make_commit('lozhkin', '2026-10-10 13:50:00', 'refactor(core): setup solution build configurations and net9.0 target')

run('git checkout main')
make_merge('feature/solution-setup', 'lozhkin', '2026-10-10 14:30:00', 1, 'Initial solution architecture and project skeleton')

# === SESSION 2 (14.10.2026) ===
run('git checkout -b feature/domain-and-storage')
make_commit('lozhkin', '2026-10-14 09:45:00', 'feat(domain): add Product, Category and Counterparty entity models')
make_commit('lozhkin', '2026-10-14 11:10:00', 'feat(domain): add WarehouseOperation and OperationType enum with friendly names')
make_commit('reyter', '2026-10-14 12:20:00', 'feat(storage): implement JsonWarehouseRepository with Cyrillic JSON encoding')
make_commit('reyter', '2026-10-14 13:40:00', 'feat(storage): add realistic demo dataset for tools, fasteners and hardware')
make_commit('baryshev', '2026-10-14 14:50:00', 'feat(ui): implement CategoriesForm for managing item classifications')
make_commit('reyter', '2026-10-14 15:30:00', 'test(storage): add initial unit tests verifying JSON persistence integrity')

run('git checkout main')
make_merge('feature/domain-and-storage', 'lozhkin', '2026-10-14 16:00:00', 2, 'Domain entities, JSON repository and demo seeding')

# === SESSION 3 (18.10.2026) ===
run('git checkout -b feature/services-and-operations')
make_commit('lozhkin', '2026-10-18 09:30:00', 'feat(service): implement IWarehouseService with receipt and expense methods')
make_commit('lozhkin', '2026-10-18 10:45:00', 'feat(service): add InsufficientStockException and stock availability checks')
make_commit('baryshev', '2026-10-18 11:30:00', 'feat(ui): implement ProductEditForm with field validation and SKU generator')
make_commit('baryshev', '2026-10-18 13:15:00', 'feat(ui): implement OperationForm supporting Receipt, Expense, WriteOff and Inventory')
make_commit('lozhkin', '2026-10-18 14:20:00', 'feat(service): add write-off and inventory adjustment business logic')
make_commit('reyter', '2026-10-18 15:10:00', 'feat(reports): implement IReportService for stock balance, turnover and CSV export')
make_commit('baryshev', '2026-10-18 15:50:00', 'feat(ui): add AboutForm displaying team members, roles and tech stack')

run('git checkout main')
make_merge('feature/services-and-operations', 'baryshev', '2026-10-18 16:30:00', 3, 'Business logic services, warehouse operation dialogs and reporting')

# === SESSION 4 (22.10.2026 - 25.10.2026) ===
run('git checkout -b feature/dashboard-and-qa')
make_commit('baryshev', '2026-10-22 10:00:00', 'feat(ui): implement MainForm dashboard with KPI cards and action toolbar')
make_commit('baryshev', '2026-10-22 11:45:00', 'feat(ui): add deficit row highlighting and quick filter toggle')
make_commit('baryshev', '2026-10-22 13:30:00', 'feat(ui): implement OperationsHistoryForm with period and type filters')
make_commit('baryshev', '2026-10-22 15:15:00', 'feat(ui): implement ReportsForm with tabbed analytics and CSV export')
make_commit('reyter', '2026-10-23 10:30:00', 'test(core): add 10 comprehensive xUnit tests for WarehouseService')
make_commit('reyter', '2026-10-23 12:40:00', 'test(reports): add 4 xUnit tests verifying turnover and deficit calculations')
make_commit('lozhkin', '2026-10-24 11:00:00', 'refactor(core): optimize dashboard statistics query and fix compiler warnings')
make_commit('reyter', '2026-10-24 14:20:00', 'docs(diagrams): add Use Case, ER, Class and Sequence UML diagrams')
make_commit('lozhkin', '2026-10-25 15:00:00', 'docs(readme): add detailed project README with architecture and guide')

run('git checkout main')
make_merge('feature/dashboard-and-qa', 'lozhkin', '2026-10-25 16:30:00', 4, 'WinForms Dashboard, xUnit test suite and documentation')

# Final commit on main
make_commit('lozhkin', '2026-10-25 18:00:00', 'release: v1.0.0 final release for project defense')
make_commit('lozhkin', '2026-10-25 18:15:00', 'docs: add completed report PDF, user guide PDF and presentation PPTX/PDF')

print("All Git commits and merges completed successfully with only surnames!")
