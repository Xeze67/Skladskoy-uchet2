using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Encodings.Web;
using System.Text.Json;
using System.Text.Unicode;
using WarehouseAccounting.Core.Models;

namespace WarehouseAccounting.Core.Data
{
    public class WarehouseDataContainer
    {
        public List<Category> Categories { get; set; } = new();
        public List<Counterparty> Counterparties { get; set; } = new();
        public List<Product> Products { get; set; } = new();
        public List<WarehouseOperation> Operations { get; set; } = new();
    }

    public class JsonWarehouseRepository : IWarehouseRepository
    {
        private readonly string _filePath;
        private WarehouseDataContainer _data = new();
        private readonly object _lock = new();

        private readonly JsonSerializerOptions _jsonOptions = new()
        {
            WriteIndented = true,
            Encoder = JavaScriptEncoder.Create(UnicodeRanges.BasicLatin, UnicodeRanges.Cyrillic)
        };

        public JsonWarehouseRepository(string? filePath = null)
        {
            if (string.IsNullOrWhiteSpace(filePath))
            {
                var appDir = AppDomain.CurrentDomain.BaseDirectory;
                _filePath = Path.Combine(appDir, "warehouse_data.json");
            }
            else
            {
                _filePath = filePath;
            }

            Load();
        }

        public IReadOnlyList<Product> GetAllProducts()
        {
            lock (_lock)
            {
                return _data.Products.ToList();
            }
        }

        public Product? GetProductById(int id)
        {
            lock (_lock)
            {
                return _data.Products.FirstOrDefault(p => p.Id == id);
            }
        }

        public Product AddProduct(Product product)
        {
            lock (_lock)
            {
                int nextId = _data.Products.Count > 0 ? _data.Products.Max(p => p.Id) + 1 : 1;
                product.Id = nextId;
                _data.Products.Add(product);
                Save();
                return product;
            }
        }

        public void UpdateProduct(Product product)
        {
            lock (_lock)
            {
                var existing = _data.Products.FirstOrDefault(p => p.Id == product.Id);
                if (existing != null)
                {
                    existing.Sku = product.Sku;
                    existing.Name = product.Name;
                    existing.CategoryId = product.CategoryId;
                    existing.CategoryName = product.CategoryName;
                    existing.Unit = product.Unit;
                    existing.PurchasePrice = product.PurchasePrice;
                    existing.SellingPrice = product.SellingPrice;
                    existing.Quantity = product.Quantity;
                    existing.MinQuantity = product.MinQuantity;
                    existing.StorageLocation = product.StorageLocation;
                    Save();
                }
            }
        }

        public bool DeleteProduct(int id)
        {
            lock (_lock)
            {
                var existing = _data.Products.FirstOrDefault(p => p.Id == id);
                if (existing != null)
                {
                    _data.Products.Remove(existing);
                    Save();
                    return true;
                }
                return false;
            }
        }

        public IReadOnlyList<Category> GetAllCategories()
        {
            lock (_lock)
            {
                return _data.Categories.ToList();
            }
        }

        public Category? GetCategoryById(int id)
        {
            lock (_lock)
            {
                return _data.Categories.FirstOrDefault(c => c.Id == id);
            }
        }

        public Category AddCategory(Category category)
        {
            lock (_lock)
            {
                int nextId = _data.Categories.Count > 0 ? _data.Categories.Max(c => c.Id) + 1 : 1;
                category.Id = nextId;
                _data.Categories.Add(category);
                Save();
                return category;
            }
        }

        public void UpdateCategory(Category category)
        {
            lock (_lock)
            {
                var existing = _data.Categories.FirstOrDefault(c => c.Id == category.Id);
                if (existing != null)
                {
                    existing.Name = category.Name;
                    existing.Description = category.Description;
                    Save();
                }
            }
        }

        public bool DeleteCategory(int id)
        {
            lock (_lock)
            {
                var existing = _data.Categories.FirstOrDefault(c => c.Id == id);
                if (existing != null)
                {
                    _data.Categories.Remove(existing);
                    Save();
                    return true;
                }
                return false;
            }
        }

        public IReadOnlyList<Counterparty> GetAllCounterparties()
        {
            lock (_lock)
            {
                return _data.Counterparties.ToList();
            }
        }

        public Counterparty AddCounterparty(Counterparty counterparty)
        {
            lock (_lock)
            {
                int nextId = _data.Counterparties.Count > 0 ? _data.Counterparties.Max(c => c.Id) + 1 : 1;
                counterparty.Id = nextId;
                _data.Counterparties.Add(counterparty);
                Save();
                return counterparty;
            }
        }

        public IReadOnlyList<WarehouseOperation> GetAllOperations()
        {
            lock (_lock)
            {
                return _data.Operations.OrderByDescending(o => o.Date).ToList();
            }
        }

        public void AddOperation(WarehouseOperation operation)
        {
            lock (_lock)
            {
                int nextId = _data.Operations.Count > 0 ? _data.Operations.Max(o => o.Id) + 1 : 1;
                operation.Id = nextId;
                _data.Operations.Add(operation);
                Save();
            }
        }

        public void Save()
        {
            lock (_lock)
            {
                try
                {
                    var dir = Path.GetDirectoryName(_filePath);
                    if (!string.IsNullOrEmpty(dir) && !Directory.Exists(dir))
                    {
                        Directory.CreateDirectory(dir);
                    }
                    var json = JsonSerializer.Serialize(_data, _jsonOptions);
                    File.WriteAllText(_filePath, json);
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"Ошибка сохранения базы данных: {ex.Message}");
                }
            }
        }

        public void Load()
        {
            lock (_lock)
            {
                if (File.Exists(_filePath))
                {
                    try
                    {
                        var json = File.ReadAllText(_filePath);
                        var loaded = JsonSerializer.Deserialize<WarehouseDataContainer>(json, _jsonOptions);
                        if (loaded != null && loaded.Products.Count > 0)
                        {
                            _data = loaded;
                            return;
                        }
                    }
                    catch
                    {
                        // При ошибке чтения файла создаем демо-данные
                    }
                }

                ResetToDemoData();
            }
        }

        public void ResetToDemoData()
        {
            lock (_lock)
            {
                _data = new WarehouseDataContainer();

                // 1. Категории
                _data.Categories = new List<Category>
                {
                    new() { Id = 1, Name = "Электроинструмент", Description = "Дрели, перфораторы, УШМ, шуруповерты" },
                    new() { Id = 2, Name = "Крепеж и метизы", Description = "Саморезы, болты, гайки, анкеры" },
                    new() { Id = 3, Name = "Ручной инструмент", Description = "Молотки, отвертки, ключи, рулетки" },
                    new() { Id = 4, Name = "Строительная химия", Description = "Герметики, пена монтажная, клеи, краски" },
                    new() { Id = 5, Name = "Электрика и кабель", Description = "Кабель ВВГнг, розетки, автоматы, гофра" }
                };

                // 2. Контрагенты
                _data.Counterparties = new List<Counterparty>
                {
                    new() { Id = 1, Name = "ООО 'ТехноСнабКомплект'", Type = CounterpartyType.Supplier, Phone = "+7 (495) 123-45-67", Email = "supply@technosnab.ru", Address = "г. Москва, ул. Складская, 15" },
                    new() { Id = 2, Name = "АО 'ИнструментТорг'", Type = CounterpartyType.Supplier, Phone = "+7 (812) 987-65-43", Email = "sales@instrtorg.ru", Address = "г. Санкт-Петербург, Заводской пр-т, 8" },
                    new() { Id = 3, Name = "ИП Сидоров А.П. (СтройРемонт)", Type = CounterpartyType.Customer, Phone = "+7 (916) 555-11-22", Email = "stroyremont@mail.ru", Address = "г. Москва, ул. Строителей, 4" },
                    new() { Id = 4, Name = "ООО 'Альфа-Строй'", Type = CounterpartyType.Customer, Phone = "+7 (495) 777-88-99", Email = "order@alfastroy.com", Address = "г. Подольск, ул. Промышленная, 1" }
                };

                // 3. Товары
                _data.Products = new List<Product>
                {
                    new() { Id = 1, Sku = "TL-00101", Name = "Дрель ударная Bosch GSB 13 RE", CategoryId = 1, CategoryName = "Электроинструмент", Unit = "шт.", PurchasePrice = 4500m, SellingPrice = 6200m, Quantity = 14m, MinQuantity = 5m, StorageLocation = "Стеллаж A-1" },
                    new() { Id = 2, Sku = "TL-00102", Name = "Шуруповерт аккумуляторный Makita DF333", CategoryId = 1, CategoryName = "Электроинструмент", Unit = "шт.", PurchasePrice = 5800m, SellingPrice = 7900m, Quantity = 3m, MinQuantity = 5m, StorageLocation = "Стеллаж A-2" }, // Дефицит!
                    new() { Id = 3, Sku = "TL-00103", Name = "УШМ (Болгарка) Интерскол 125/900", CategoryId = 1, CategoryName = "Электроинструмент", Unit = "шт.", PurchasePrice = 2900m, SellingPrice = 4100m, Quantity = 8m, MinQuantity = 4m, StorageLocation = "Стеллаж A-3" },
                    new() { Id = 4, Sku = "FX-00201", Name = "Саморезы по дереву 3.5х35 (пачка 1000 шт)", CategoryId = 2, CategoryName = "Крепеж и метизы", Unit = "упак.", PurchasePrice = 320m, SellingPrice = 550m, Quantity = 45m, MinQuantity = 15m, StorageLocation = "Стеллаж B-1" },
                    new() { Id = 5, Sku = "FX-00202", Name = "Анкер клиновой 10х100 (50 шт)", CategoryId = 2, CategoryName = "Крепеж и метизы", Unit = "упак.", PurchasePrice = 650m, SellingPrice = 980m, Quantity = 4m, MinQuantity = 10m, StorageLocation = "Стеллаж B-2" }, // Дефицит!
                    new() { Id = 6, Sku = "HT-00301", Name = "Набор отверток диэлектрических 6 шт Gross", CategoryId = 3, CategoryName = "Ручной инструмент", Unit = "компл.", PurchasePrice = 1100m, SellingPrice = 1650m, Quantity = 12m, MinQuantity = 5m, StorageLocation = "Стеллаж C-1" },
                    new() { Id = 7, Sku = "HT-00302", Name = "Рулетка строительная 5м магнитная Matrix", CategoryId = 3, CategoryName = "Ручной инструмент", Unit = "шт.", PurchasePrice = 280m, SellingPrice = 490m, Quantity = 25m, MinQuantity = 10m, StorageLocation = "Стеллаж C-2" },
                    new() { Id = 8, Sku = "CH-00401", Name = "Пена монтажная всесезонная Soudal 750 мл", CategoryId = 4, CategoryName = "Строительная химия", Unit = "баллон", PurchasePrice = 410m, SellingPrice = 650m, Quantity = 2m, MinQuantity = 12m, StorageLocation = "Стеллаж D-1" }, // Дефицит!
                    new() { Id = 9, Sku = "CH-00402", Name = "Герметик силиконовый санитарный белый 310 мл", CategoryId = 4, CategoryName = "Строительная химия", Unit = "шт.", PurchasePrice = 260m, SellingPrice = 420m, Quantity = 30m, MinQuantity = 10m, StorageLocation = "Стеллаж D-2" },
                    new() { Id = 10, Sku = "EL-00501", Name = "Кабель силовой ВВГ-Пнг(А) 3х2.5 бухта 100м", CategoryId = 5, CategoryName = "Электрика и кабель", Unit = "бухта", PurchasePrice = 7200m, SellingPrice = 9800m, Quantity = 6m, MinQuantity = 3m, StorageLocation = "Склад-Пол E" },
                    new() { Id = 11, Sku = "EL-00502", Name = "Автоматический выключатель 16A 1P Schneider", CategoryId = 5, CategoryName = "Электрика и кабель", Unit = "шт.", PurchasePrice = 190m, SellingPrice = 330m, Quantity = 55m, MinQuantity = 20m, StorageLocation = "Стеллаж E-1" }
                };

                // 4. Начальные операции
                var now = DateTime.Now;
                _data.Operations = new List<WarehouseOperation>
                {
                    new() { Id = 1, DocumentNumber = "ПР-0001", Date = now.AddDays(-10), Type = OperationType.Receipt, ProductId = 1, ProductSku = "TL-00101", ProductName = "Дрель ударная Bosch GSB 13 RE", Unit = "шт.", Quantity = 15m, Price = 4500m, CounterpartyId = 1, CounterpartyName = "ООО 'ТехноСнабКомплект'", ResponsiblePerson = "Ложкин", Comment = "Поставка по договору №108" },
                    new() { Id = 2, DocumentNumber = "ПР-0002", Date = now.AddDays(-9), Type = OperationType.Receipt, ProductId = 2, ProductSku = "TL-00102", ProductName = "Шуруповерт аккумуляторный Makita DF333", Unit = "шт.", Quantity = 10m, Price = 5800m, CounterpartyId = 2, CounterpartyName = "АО 'ИнструментТорг'", ResponsiblePerson = "Ложкин", Comment = "Плановая поставка инструмента" },
                    new() { Id = 3, DocumentNumber = "РХ-0001", Date = now.AddDays(-6), Type = OperationType.Expense, ProductId = 2, ProductSku = "TL-00102", ProductName = "Шуруповерт аккумуляторный Makita DF333", Unit = "шт.", Quantity = 7m, Price = 7900m, CounterpartyId = 4, CounterpartyName = "ООО 'Альфа-Строй'", ResponsiblePerson = "Барышев", Comment = "Отгрузка на объект ЖК 'Северный'" },
                    new() { Id = 4, DocumentNumber = "РХ-0002", Date = now.AddDays(-4), Type = OperationType.Expense, ProductId = 1, ProductSku = "TL-00101", ProductName = "Дрель ударная Bosch GSB 13 RE", Unit = "шт.", Quantity = 1m, Price = 6200m, CounterpartyId = 3, CounterpartyName = "ИП Сидоров А.П. (СтройРемонт)", ResponsiblePerson = "Барышев", Comment = "Заказ самовывозом" },
                    new() { Id = 5, DocumentNumber = "СП-0001", Date = now.AddDays(-2), Type = OperationType.WriteOff, ProductId = 8, ProductSku = "CH-00401", ProductName = "Пена монтажная всесезонная Soudal 750 мл", Unit = "баллон", Quantity = 1m, Price = 410m, CounterpartyId = null, CounterpartyName = "-", ResponsiblePerson = "Рейтер", Comment = "Повреждение клапана при транспортировке" },
                    new() { Id = 6, DocumentNumber = "ИНВ-0001", Date = now.AddDays(-1), Type = OperationType.InventoryAdjustment, ProductId = 11, ProductSku = "EL-00502", ProductName = "Автоматический выключатель 16A 1P Schneider", Unit = "шт.", Quantity = 55m, Price = 190m, CounterpartyId = null, CounterpartyName = "-", ResponsiblePerson = "Рейтер", Comment = "Плановая инвентаризация секции электрики" }
                };

                Save();
            }
        }
    }
}
