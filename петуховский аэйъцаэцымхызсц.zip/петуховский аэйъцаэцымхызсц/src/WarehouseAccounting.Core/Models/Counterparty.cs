using System;

namespace WarehouseAccounting.Core.Models
{
    public enum CounterpartyType
    {
        Supplier, // Поставщик
        Customer  // Покупатель / Заказчик
    }

    public class Counterparty
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public CounterpartyType Type { get; set; }
        public string Phone { get; set; } = string.Empty;
        public string Email { get; set; } = string.Empty;
        public string Address { get; set; } = string.Empty;

        public override string ToString() => $"{Name} ({(Type == CounterpartyType.Supplier ? "Поставщик" : "Покупатель")})";
    }
}
