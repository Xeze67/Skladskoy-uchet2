namespace WarehouseAccounting.Core.Models
{
    public enum OperationType
    {
        Receipt,              // Приход от поставщика
        Expense,              // Расход / Отгрузка клиенту
        WriteOff,             // Списание (порча, брак)
        InventoryAdjustment   // Инвентаризация / Корректировка
    }

    public static class OperationTypeExtensions
    {
        public static string ToFriendlyName(this OperationType type) => type switch
        {
            OperationType.Receipt => "Приход",
            OperationType.Expense => "Отгрузка (Расход)",
            OperationType.WriteOff => "Списание",
            OperationType.InventoryAdjustment => "Инвентаризация",
            _ => type.ToString()
        };
    }
}
