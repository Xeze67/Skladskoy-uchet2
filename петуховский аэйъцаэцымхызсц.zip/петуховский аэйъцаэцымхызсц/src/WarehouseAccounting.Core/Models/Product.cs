using System;

namespace WarehouseAccounting.Core.Models
{
    public class Product
    {
        public int Id { get; set; }
        public string Sku { get; set; } = string.Empty; // Артикул
        public string Name { get; set; } = string.Empty; // Наименование товара
        public int CategoryId { get; set; }
        public string CategoryName { get; set; } = string.Empty;
        public string Unit { get; set; } = "шт."; // Ед. измерения (шт, кг, л, уп.)
        public decimal PurchasePrice { get; set; } // Цена закупки
        public decimal SellingPrice { get; set; } // Цена реализации
        public decimal Quantity { get; set; } // Текущий остаток
        public decimal MinQuantity { get; set; } // Минимальный неснижаемый остаток
        public string StorageLocation { get; set; } = string.Empty; // Стеллаж / Ячейка хранения

        public bool IsLowStock => Quantity <= MinQuantity;
        public decimal TotalStockValue => Quantity * PurchasePrice;

        public override string ToString() => $"[{Sku}] {Name} ({Quantity} {Unit})";
    }
}
