using System;

namespace WarehouseAccounting.Core.Exceptions
{
    public class WarehouseValidationException : Exception
    {
        public WarehouseValidationException(string message) : base(message) { }
    }

    public class InsufficientStockException : Exception
    {
        public int ProductId { get; }
        public decimal RequestedQuantity { get; }
        public decimal AvailableQuantity { get; }

        public InsufficientStockException(int productId, string productName, decimal requested, decimal available)
            : base($"Недостаточно товара '{productName}' на складе! Запрошено: {requested}, доступно: {available}.")
        {
            ProductId = productId;
            RequestedQuantity = requested;
            AvailableQuantity = available;
        }
    }
}
