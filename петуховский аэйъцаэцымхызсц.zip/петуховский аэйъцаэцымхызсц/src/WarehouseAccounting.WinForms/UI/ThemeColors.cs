using System.Drawing;

namespace WarehouseAccounting.WinForms.UI
{
    public static class ThemeColors
    {
        public static Color DarkHeader = Color.FromArgb(30, 41, 59);      // Slate 800
        public static Color Background = Color.FromArgb(248, 250, 252);     // Slate 50
        public static Color CardBg = Color.White;
        public static Color CardBorder = Color.FromArgb(226, 232, 240);    // Slate 200
        public static Color Primary = Color.FromArgb(37, 99, 235);         // Blue 600
        public static Color PrimaryHover = Color.FromArgb(29, 78, 216);    // Blue 700
        public static Color Success = Color.FromArgb(16, 185, 129);        // Emerald 500
        public static Color Warning = Color.FromArgb(245, 158, 11);        // Amber 500
        public static Color Danger = Color.FromArgb(239, 68, 68);          // Red 500
        public static Color TextDark = Color.FromArgb(15, 23, 42);         // Slate 900
        public static Color TextMuted = Color.FromArgb(100, 116, 139);     // Slate 500
        public static Color GridHeaderBg = Color.FromArgb(241, 245, 249);  // Slate 100
        public static Color DeficitRowBg = Color.FromArgb(254, 226, 226);  // Light Red
        public static Color DeficitRowText = Color.FromArgb(153, 27, 27);  // Dark Red
    }
}
