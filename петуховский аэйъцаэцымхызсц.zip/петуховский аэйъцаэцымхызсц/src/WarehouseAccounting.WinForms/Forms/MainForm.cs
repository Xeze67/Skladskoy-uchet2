using System;
using System.Drawing;
using System.Linq;
using System.Windows.Forms;
using WarehouseAccounting.Core.Data;
using WarehouseAccounting.Core.Models;
using WarehouseAccounting.Core.Services;
using WarehouseAccounting.WinForms.UI;

namespace WarehouseAccounting.WinForms.Forms
{
    public class MainForm : Form
    {
        private readonly IWarehouseRepository _repository;
        private readonly IWarehouseService _warehouseService;
        private readonly IReportService _reportService;

        // KPI Карточки
        private Label _lblKpiTotalItems = null!;
        private Label _lblKpiTotalQuantity = null!;
        private Label _lblKpiTotalValue = null!;
        private Label _lblKpiDeficitCount = null!;

        // Фильтры
        private TextBox _txtSearch = null!;
        private ComboBox _cmbCategory = null!;
        private CheckBox _chkOnlyDeficit = null!;

        // Таблица товаров
        private DataGridView _gridProducts = null!;
        private StatusStrip _statusStrip = null!;
        private ToolStripStatusLabel _statusLabel = null!;

        public MainForm()
        {
            _repository = new AccessWarehouseRepository();
            _warehouseService = new WarehouseService(_repository);
            _reportService = new ReportService(_repository);

            InitializeComponent();
            RefreshCategoryFilter();
            LoadData();
        }

        private void InitializeComponent()
        {
            this.Text = "Складской учёт (мини-версия) — Автоматизированная система управления складом";
            this.Size = new Size(1280, 800);
            this.MinimumSize = new Size(1024, 600);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.BackColor = ThemeColors.Background;
            this.Font = new Font("Segoe UI", 9.5f);

            // Главный верхний контейнер (содержит 4 секции в строгом порядке сверху вниз)
            var tblHeader = new TableLayoutPanel
            {
                Dock = DockStyle.Top,
                Height = 280,
                RowCount = 4,
                ColumnCount = 1,
                BackColor = ThemeColors.Background,
                Margin = new Padding(0),
                Padding = new Padding(0)
            };
            tblHeader.RowStyles.Add(new RowStyle(SizeType.Absolute, 70f));   // 1. Темная шапка
            tblHeader.RowStyles.Add(new RowStyle(SizeType.Absolute, 105f));  // 2. Карточки KPI
            tblHeader.RowStyles.Add(new RowStyle(SizeType.Absolute, 55f));   // 3. Кнопки действий
            tblHeader.RowStyles.Add(new RowStyle(SizeType.Absolute, 50f));   // 4. Поиск и фильтры
            tblHeader.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100f));

            // 1. Верхний заголовок
            var pnlTop = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = ThemeColors.DarkHeader,
                Padding = new Padding(20, 10, 20, 10),
                Margin = new Padding(0)
            };

            var lblAppTitle = new Label
            {
                Text = "Складской учёт (мини-версия)",
                Font = new Font("Segoe UI", 14f, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = true,
                Location = new Point(20, 12)
            };

            var lblAppSubtitle = new Label
            {
                Text = "Групповой проект • Тема 9 • Разработчики: Ложкин, Барышев, Рейтер",
                Font = new Font("Segoe UI", 9f),
                ForeColor = Color.FromArgb(148, 163, 184),
                AutoSize = true,
                Location = new Point(22, 40)
            };

            var pnlTopButtons = new FlowLayoutPanel
            {
                Dock = DockStyle.Right,
                AutoSize = true,
                WrapContents = false,
                FlowDirection = FlowDirection.RightToLeft,
                Padding = new Padding(0, 12, 10, 0)
            };

            var btnAbout = CreateHeaderButton("ℹ О программе", (s, e) => new AboutForm().ShowDialog(this));
            var btnClear = CreateHeaderButton("🗑 Очистить склад", BtnResetDemo_Click);
            var btnCategories = CreateHeaderButton("📁 Категории", (s, e) => { new CategoriesForm(_warehouseService).ShowDialog(this); RefreshCategoryFilter(); LoadData(); });
            var btnReports = CreateHeaderButton("📊 Отчёты", (s, e) => new ReportsForm(_reportService).ShowDialog(this));
            var btnHistory = CreateHeaderButton("📋 Журнал операций", (s, e) => new OperationsHistoryForm(_warehouseService).ShowDialog(this));

            pnlTopButtons.Controls.Add(btnAbout);
            pnlTopButtons.Controls.Add(btnClear);
            pnlTopButtons.Controls.Add(btnCategories);
            pnlTopButtons.Controls.Add(btnReports);
            pnlTopButtons.Controls.Add(btnHistory);

            pnlTop.Controls.Add(lblAppTitle);
            pnlTop.Controls.Add(lblAppSubtitle);
            pnlTop.Controls.Add(pnlTopButtons);
            tblHeader.Controls.Add(pnlTop, 0, 0);

            // 2. Панель KPI карточек
            var pnlKpi = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = ThemeColors.Background,
                Padding = new Padding(20, 12, 20, 10),
                Margin = new Padding(0)
            };

            var tblKpi = new TableLayoutPanel
            {
                Dock = DockStyle.Fill,
                ColumnCount = 4,
                RowCount = 1
            };
            tblKpi.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25f));
            tblKpi.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25f));
            tblKpi.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25f));
            tblKpi.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 25f));

            var card1 = CreateKpiCard("Всего номенклатуры", "0 поз.", out _lblKpiTotalItems, Color.FromArgb(59, 130, 246));
            var card2 = CreateKpiCard("Общий остаток", "0 шт.", out _lblKpiTotalQuantity, Color.FromArgb(16, 185, 129));
            var card3 = CreateKpiCard("Оценка склада (руб)", "0.00 руб.", out _lblKpiTotalValue, Color.FromArgb(139, 92, 246));
            var card4 = CreateKpiCard("Дефицит (к дозаказу)", "0 поз.", out _lblKpiDeficitCount, Color.FromArgb(239, 68, 68));

            tblKpi.Controls.Add(card1, 0, 0);
            tblKpi.Controls.Add(card2, 1, 0);
            tblKpi.Controls.Add(card3, 2, 0);
            tblKpi.Controls.Add(card4, 3, 0);

            pnlKpi.Controls.Add(tblKpi);
            tblHeader.Controls.Add(pnlKpi, 0, 1);

            // 3. Панель операций и кнопок действий
            var pnlActions = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.White,
                Padding = new Padding(20, 8, 20, 8),
                Margin = new Padding(0)
            };

            var btnReceipt = CreateActionButton("+ Приход товара", ThemeColors.Success, (s, e) => ExecuteOperation(OperationType.Receipt));
            var btnExpense = CreateActionButton("- Отгрузка (Расход)", ThemeColors.Primary, (s, e) => ExecuteOperation(OperationType.Expense));
            var btnWriteOff = CreateActionButton("⚠ Списание брака", Color.FromArgb(217, 119, 6), (s, e) => ExecuteOperation(OperationType.WriteOff));
            var btnInventory = CreateActionButton("📋 Инвентаризация", Color.FromArgb(109, 40, 217), (s, e) => ExecuteOperation(OperationType.InventoryAdjustment));

            var btnAddProduct = CreateActionButton("+ Новый товар", Color.FromArgb(51, 65, 85), BtnAddProduct_Click);
            var btnEditProduct = CreateActionButton("✏ Редактировать", Color.FromArgb(71, 85, 105), BtnEditProduct_Click);
            var btnDeleteProduct = CreateActionButton("🗑 Удалить", Color.FromArgb(185, 28, 28), BtnDeleteProduct_Click);

            var flowActions = new FlowLayoutPanel
            {
                Dock = DockStyle.Fill,
                AutoSize = true
            };
            flowActions.Controls.Add(btnReceipt);
            flowActions.Controls.Add(btnExpense);
            flowActions.Controls.Add(btnWriteOff);
            flowActions.Controls.Add(btnInventory);
            flowActions.Controls.Add(new Label { Width = 20, Text = "" }); // разделитель
            flowActions.Controls.Add(btnAddProduct);
            flowActions.Controls.Add(btnEditProduct);
            flowActions.Controls.Add(btnDeleteProduct);

            pnlActions.Controls.Add(flowActions);
            tblHeader.Controls.Add(pnlActions, 0, 2);

            // 4. Панель поиска и фильтрации
            var pnlSearch = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = Color.FromArgb(241, 245, 249),
                Padding = new Padding(20, 10, 20, 10),
                Margin = new Padding(0)
            };

            var lblSearch = new Label { Text = "🔍 Поиск:", Location = new Point(20, 14), AutoSize = true, Font = new Font("Segoe UI", 9.5f, FontStyle.Bold) };
            _txtSearch = new TextBox { Location = new Point(85, 12), Size = new Size(260, 26), PlaceholderText = "Артикул, наименование, стеллаж..." };
            _txtSearch.TextChanged += (s, e) => LoadData();

            var lblCategory = new Label { Text = "Категория:", Location = new Point(365, 14), AutoSize = true, Font = new Font("Segoe UI", 9.5f, FontStyle.Bold) };
            _cmbCategory = new ComboBox { Location = new Point(450, 12), Size = new Size(200, 26), DropDownStyle = ComboBoxStyle.DropDownList };
            _cmbCategory.SelectedIndexChanged += (s, e) => LoadData();

            _chkOnlyDeficit = new CheckBox
            {
                Text = "⚠ Только позиции в дефиците",
                Location = new Point(670, 14),
                AutoSize = true,
                Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
                ForeColor = ThemeColors.Danger
            };
            _chkOnlyDeficit.CheckedChanged += (s, e) => LoadData();

            var btnClearFilters = new Button
            {
                Text = "Сбросить фильтры",
                Location = new Point(920, 10),
                Size = new Size(140, 30),
                BackColor = Color.White,
                ForeColor = ThemeColors.TextDark,
                FlatStyle = FlatStyle.Flat
            };
            btnClearFilters.Click += (s, e) =>
            {
                _txtSearch.Clear();
                _cmbCategory.SelectedIndex = 0;
                _chkOnlyDeficit.Checked = false;
            };

            pnlSearch.Controls.Add(lblSearch);
            pnlSearch.Controls.Add(_txtSearch);
            pnlSearch.Controls.Add(lblCategory);
            pnlSearch.Controls.Add(_cmbCategory);
            pnlSearch.Controls.Add(_chkOnlyDeficit);
            pnlSearch.Controls.Add(btnClearFilters);
            tblHeader.Controls.Add(pnlSearch, 0, 3);

            // 5. Таблица товаров
            _gridProducts = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None,
                RowHeadersVisible = false,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                EnableHeadersVisualStyles = false,
                ScrollBars = ScrollBars.Both
            };
            _gridProducts.ColumnHeadersDefaultCellStyle.BackColor = ThemeColors.GridHeaderBg;
            _gridProducts.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold);
            _gridProducts.ColumnHeadersDefaultCellStyle.ForeColor = ThemeColors.TextDark;
            _gridProducts.ColumnHeadersHeight = 38;
            _gridProducts.RowTemplate.Height = 30;
            _gridProducts.CellDoubleClick += (s, e) => BtnEditProduct_Click(s, e);
            _gridProducts.MouseEnter += (s, e) => { if (!_gridProducts.Focused) _gridProducts.Focus(); };

            ConfigureProductGridColumns();

            // 6. Строка состояния
            _statusStrip = new StatusStrip { Dock = DockStyle.Bottom };
            _statusLabel = new ToolStripStatusLabel { Text = "Готово" };
            _statusStrip.Items.Add(_statusLabel);

            // Порядок добавления на форму для строгого WinForms Docking:
            this.Controls.Add(_gridProducts);
            this.Controls.Add(tblHeader);
            this.Controls.Add(_statusStrip);
            _gridProducts.BringToFront();
        }

        private void ConfigureProductGridColumns()
        {
            _gridProducts.Columns.Add("Id", "ID");
            _gridProducts.Columns["Id"].Visible = false;

            _gridProducts.Columns.Add("Sku", "Артикул");
            _gridProducts.Columns["Sku"].FillWeight = 85;

            _gridProducts.Columns.Add("Name", "Наименование товара");
            _gridProducts.Columns["Name"].FillWeight = 220;

            _gridProducts.Columns.Add("Category", "Категория");
            _gridProducts.Columns["Category"].FillWeight = 110;

            _gridProducts.Columns.Add("Quantity", "Остаток");
            _gridProducts.Columns["Quantity"].FillWeight = 65;
            _gridProducts.Columns["Quantity"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            _gridProducts.Columns.Add("Unit", "Ед.");
            _gridProducts.Columns["Unit"].FillWeight = 40;

            _gridProducts.Columns.Add("PurchasePrice", "Цена закупки");
            _gridProducts.Columns["PurchasePrice"].FillWeight = 80;
            _gridProducts.Columns["PurchasePrice"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            _gridProducts.Columns.Add("SellingPrice", "Цена продажи");
            _gridProducts.Columns["SellingPrice"].FillWeight = 80;
            _gridProducts.Columns["SellingPrice"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            _gridProducts.Columns.Add("TotalValue", "Складская сумма");
            _gridProducts.Columns["TotalValue"].FillWeight = 95;
            _gridProducts.Columns["TotalValue"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            _gridProducts.Columns.Add("MinQuantity", "Мин. остаток");
            _gridProducts.Columns["MinQuantity"].FillWeight = 70;
            _gridProducts.Columns["MinQuantity"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;

            _gridProducts.Columns.Add("Location", "Место");
            _gridProducts.Columns["Location"].FillWeight = 75;

            _gridProducts.Columns.Add("Status", "Статус");
            _gridProducts.Columns["Status"].FillWeight = 80;
            _gridProducts.Columns["Status"].DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleCenter;
        }

        private Panel CreateKpiCard(string title, string initialValue, out Label valLabel, Color accentColor)
        {
            var pnl = new Panel
            {
                Dock = DockStyle.Fill,
                BackColor = ThemeColors.CardBg,
                Margin = new Padding(5),
                Padding = new Padding(15, 10, 15, 10)
            };

            // Левая цветная полоса
            var pnlAccent = new Panel
            {
                Dock = DockStyle.Left,
                Width = 5,
                BackColor = accentColor
            };
            pnl.Controls.Add(pnlAccent);

            var lblTitle = new Label
            {
                Text = title,
                ForeColor = ThemeColors.TextMuted,
                Font = new Font("Segoe UI", 8.5f, FontStyle.Bold),
                AutoSize = true,
                Location = new Point(15, 10)
            };

            valLabel = new Label
            {
                Text = initialValue,
                ForeColor = ThemeColors.TextDark,
                Font = new Font("Segoe UI", 13f, FontStyle.Bold),
                AutoSize = true,
                Location = new Point(15, 32)
            };

            pnl.Controls.Add(lblTitle);
            pnl.Controls.Add(valLabel);
            return pnl;
        }

        private Button CreateHeaderButton(string text, EventHandler onClick)
        {
            var btn = new Button
            {
                Text = text,
                Height = 34,
                AutoSize = true,
                BackColor = Color.FromArgb(51, 65, 85),
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                Cursor = Cursors.Hand,
                Margin = new Padding(4)
            };
            btn.FlatAppearance.BorderSize = 0;
            btn.Click += onClick;
            return btn;
        }

        private Button CreateActionButton(string text, Color backColor, EventHandler onClick)
        {
            var btn = new Button
            {
                Text = text,
                Height = 36,
                AutoSize = true,
                BackColor = backColor,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
                Cursor = Cursors.Hand,
                Margin = new Padding(3, 0, 8, 0)
            };
            btn.FlatAppearance.BorderSize = 0;
            btn.Click += onClick;
            return btn;
        }

        private void RefreshCategoryFilter()
        {
            _cmbCategory.Items.Clear();
            _cmbCategory.Items.Add(new Category { Id = 0, Name = "Все категории" });
            foreach (var cat in _warehouseService.GetCategories())
            {
                _cmbCategory.Items.Add(cat);
            }
            _cmbCategory.SelectedIndex = 0;
        }

        private void LoadData()
        {
            string search = _txtSearch.Text;
            int? categoryId = null;
            if (_cmbCategory.SelectedItem is Category cat && cat.Id > 0)
            {
                categoryId = cat.Id;
            }
            bool onlyDeficit = _chkOnlyDeficit.Checked;

            var products = _warehouseService.GetProducts(search, categoryId, onlyDeficit);

            _gridProducts.Rows.Clear();

            foreach (var p in products)
            {
                string status = p.IsLowStock ? "⚠ ДЕФИЦИТ" : "В норме";

                int rowIdx = _gridProducts.Rows.Add(
                    p.Id,
                    p.Sku,
                    p.Name,
                    p.CategoryName,
                    p.Quantity.ToString("G29"),
                    p.Unit,
                    p.PurchasePrice.ToString("N2"),
                    p.SellingPrice.ToString("N2"),
                    p.TotalStockValue.ToString("N2"),
                    p.MinQuantity.ToString("G29"),
                    p.StorageLocation,
                    status
                );

                var row = _gridProducts.Rows[rowIdx];
                if (p.IsLowStock)
                {
                    row.DefaultCellStyle.BackColor = ThemeColors.DeficitRowBg;
                    row.DefaultCellStyle.ForeColor = ThemeColors.DeficitRowText;
                    row.Cells["Status"].Style.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold);
                }
            }

            // Обновление карточек KPI
            var stats = _warehouseService.GetDashboardStats();
            _lblKpiTotalItems.Text = $"{stats.TotalItemTypes} поз.";
            _lblKpiTotalQuantity.Text = $"{stats.TotalStockQuantity:N0} ед.";
            _lblKpiTotalValue.Text = $"{stats.TotalStockValueRub:N2} ₽";
            _lblKpiDeficitCount.Text = $"{stats.LowStockCount} поз.";

            string dbInfo = _repository is AccessWarehouseRepository accessRepo 
                ? $"База данных MS Access: {accessRepo.DatabasePath}" 
                : "База данных: MS Access (warehouse.accdb)";
            _statusLabel.Text = $"{dbInfo} | Позиций: {products.Count} | Всего операций: {stats.TotalOperationsCount}";
        }

        private Product? GetSelectedProduct()
        {
            if (_gridProducts.SelectedRows.Count == 0) return null;
            int id = Convert.ToInt32(_gridProducts.SelectedRows[0].Cells["Id"].Value);
            return _warehouseService.GetProductById(id);
        }

        private void ExecuteOperation(OperationType type)
        {
            var selected = GetSelectedProduct();
            using var form = new OperationForm(_warehouseService, type, selected?.Id);
            if (form.ShowDialog(this) == DialogResult.OK)
            {
                LoadData();
            }
        }

        private void BtnAddProduct_Click(object? sender, EventArgs e)
        {
            using var form = new ProductEditForm(_warehouseService);
            if (form.ShowDialog(this) == DialogResult.OK)
            {
                LoadData();
            }
        }

        private void BtnEditProduct_Click(object? sender, EventArgs e)
        {
            var selected = GetSelectedProduct();
            if (selected == null)
            {
                MessageBox.Show("Выберите товар из списка для редактирования!", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            using var form = new ProductEditForm(_warehouseService, selected);
            if (form.ShowDialog(this) == DialogResult.OK)
            {
                LoadData();
            }
        }

        private void BtnDeleteProduct_Click(object? sender, EventArgs e)
        {
            var selected = GetSelectedProduct();
            if (selected == null)
            {
                MessageBox.Show("Выберите товар из списка для удаления!", "Информация", MessageBoxButtons.OK, MessageBoxIcon.Information);
                return;
            }

            var res = MessageBox.Show($"Вы действительно хотите удалить товар '{selected.Name}' (Артикул: {selected.Sku})?", "Подтверждение удаления", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (res == DialogResult.Yes)
            {
                _warehouseService.DeleteProduct(selected.Id);
                LoadData();
            }
        }

        private void BtnResetDemo_Click(object? sender, EventArgs e)
        {
            var res = MessageBox.Show("Очистить складские записи в базе данных Microsoft Access?", "Очистка данных", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
            if (res == DialogResult.Yes)
            {
                _warehouseService.ResetToDemo();
                RefreshCategoryFilter();
                LoadData();
                MessageBox.Show("База данных Microsoft Access очищена!", "Очистка", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
