using System;
using System.Drawing;
using System.Windows.Forms;
using WarehouseAccounting.Core.Models;
using WarehouseAccounting.Core.Services;
using WarehouseAccounting.WinForms.UI;

namespace WarehouseAccounting.WinForms.Forms
{
    public class CategoriesForm : Form
    {
        private readonly IWarehouseService _service;
        private ListBox _lstCategories = null!;
        private TextBox _txtName = null!;
        private TextBox _txtDesc = null!;
        private Button _btnAdd = null!;

        public CategoriesForm(IWarehouseService service)
        {
            _service = service;
            InitializeComponent();
            LoadCategories();
        }

        private void InitializeComponent()
        {
            this.Text = "Справочник категорий товаров";
            this.Size = new Size(500, 420);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = ThemeColors.Background;
            this.Font = new Font("Segoe UI", 9.5f);

            var lblTitle = new Label
            {
                Text = "Категории товаров на складе",
                Font = new Font("Segoe UI", 12f, FontStyle.Bold),
                ForeColor = ThemeColors.TextDark,
                Location = new Point(20, 15),
                AutoSize = true
            };
            this.Controls.Add(lblTitle);

            _lstCategories = new ListBox
            {
                Location = new Point(20, 50),
                Size = new Size(220, 310),
                Font = new Font("Segoe UI", 10f),
                BorderStyle = BorderStyle.FixedSingle
            };
            this.Controls.Add(_lstCategories);

            var grpAdd = new GroupBox
            {
                Text = "Добавить категорию",
                Location = new Point(255, 45),
                Size = new Size(215, 250),
                Font = new Font("Segoe UI", 9f, FontStyle.Bold)
            };

            var lblName = new Label { Text = "Название:", Location = new Point(15, 25), AutoSize = true, Font = new Font("Segoe UI", 9f) };
            _txtName = new TextBox { Location = new Point(15, 45), Size = new Size(185, 25), Font = new Font("Segoe UI", 9.5f) };

            var lblDesc = new Label { Text = "Описание:", Location = new Point(15, 80), AutoSize = true, Font = new Font("Segoe UI", 9f) };
            _txtDesc = new TextBox { Location = new Point(15, 100), Size = new Size(185, 75), Multiline = true, Font = new Font("Segoe UI", 9f) };

            _btnAdd = new Button
            {
                Text = "+ Добавить",
                Location = new Point(15, 190),
                Size = new Size(185, 34),
                BackColor = ThemeColors.Primary,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            _btnAdd.FlatAppearance.BorderSize = 0;
            _btnAdd.Click += BtnAdd_Click;

            grpAdd.Controls.Add(lblName);
            grpAdd.Controls.Add(_txtName);
            grpAdd.Controls.Add(lblDesc);
            grpAdd.Controls.Add(_txtDesc);
            grpAdd.Controls.Add(_btnAdd);
            this.Controls.Add(grpAdd);

            var btnClose = new Button
            {
                Text = "Закрыть",
                DialogResult = DialogResult.OK,
                Location = new Point(355, 325),
                Size = new Size(115, 35),
                BackColor = Color.White,
                ForeColor = ThemeColors.TextDark,
                FlatStyle = FlatStyle.Flat
            };
            this.Controls.Add(btnClose);
        }

        private void LoadCategories()
        {
            _lstCategories.Items.Clear();
            var categories = _service.GetCategories();
            foreach (var cat in categories)
            {
                _lstCategories.Items.Add(cat.Name);
            }
        }

        private void BtnAdd_Click(object? sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(_txtName.Text))
            {
                MessageBox.Show("Введите название категории!", "Внимание", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            try
            {
                _service.CreateCategory(_txtName.Text, _txtDesc.Text);
                _txtName.Clear();
                _txtDesc.Clear();
                LoadCategories();
                MessageBox.Show("Категория успешно добавлена!", "Успех", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка добавления категории: {ex.Message}", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}
