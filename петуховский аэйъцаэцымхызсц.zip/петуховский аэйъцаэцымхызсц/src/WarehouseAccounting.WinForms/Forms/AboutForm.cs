using System;
using System.Drawing;
using System.Windows.Forms;
using WarehouseAccounting.WinForms.UI;

namespace WarehouseAccounting.WinForms.Forms
{
    public class AboutForm : Form
    {
        public AboutForm()
        {
            InitializeComponent();
        }

        private void InitializeComponent()
        {
            this.Text = "О программе - Складской учёт";
            this.Size = new Size(520, 480);
            this.StartPosition = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.BackColor = ThemeColors.Background;
            this.Font = new Font("Segoe UI", 9.5f);

            var pnlHeader = new Panel
            {
                Dock = DockStyle.Top,
                Height = 80,
                BackColor = ThemeColors.DarkHeader,
                Padding = new Padding(20, 15, 20, 15)
            };

            var lblTitle = new Label
            {
                Text = "Складской учёт (мини-версия)",
                Font = new Font("Segoe UI", 14f, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = true,
                Location = new Point(20, 15)
            };

            var lblSubtitle = new Label
            {
                Text = "Групповой проект • Тема № 9 • Visual Studio + .NET + Git",
                Font = new Font("Segoe UI", 9.5f),
                ForeColor = Color.FromArgb(148, 163, 184),
                AutoSize = true,
                Location = new Point(22, 45)
            };

            pnlHeader.Controls.Add(lblTitle);
            pnlHeader.Controls.Add(lblSubtitle);
            this.Controls.Add(pnlHeader);

            var pnlContent = new Panel
            {
                Dock = DockStyle.Fill,
                Padding = new Padding(25, 20, 25, 20)
            };

            var lblTeamHeader = new Label
            {
                Text = "Состав группы разработчиков:",
                Font = new Font("Segoe UI", 10.5f, FontStyle.Bold),
                ForeColor = ThemeColors.TextDark,
                Location = new Point(25, 95),
                AutoSize = true
            };

            var lblTeam = new Label
            {
                Text = "• Ложкин — Тимлид, проектирование архитектуры, бизнес-логика (Services, Core), Git-координация\n\n" +
                       "• Барышев — Разработчик WinForms UI, формы ввода и валидации, UX дашборда\n\n" +
                       "• Рейтер — Хранилище данных JSON Repository, генерация отчетов и аналитика, модульное тестирование xUnit",
                Font = new Font("Segoe UI", 9.5f),
                ForeColor = ThemeColors.TextDark,
                Location = new Point(25, 125),
                Size = new Size(460, 140)
            };

            var lblTechHeader = new Label
            {
                Text = "Использованные технологии:",
                Font = new Font("Segoe UI", 10.5f, FontStyle.Bold),
                ForeColor = ThemeColors.TextDark,
                Location = new Point(25, 275),
                AutoSize = true
            };

            var lblTech = new Label
            {
                Text = "• Microsoft .NET 9.0 (C# 13)\n" +
                       "• Windows Forms (интерактивный графический интерфейс)\n" +
                       "• Многопроектное решение (Core + WinForms + Tests)\n" +
                       "• Фреймворк тестирования xUnit (14 автоматизированных тестов)\n" +
                       "• Контроль версий Git (Git Flow, ветки feature/*, осмысленная история)",
                Font = new Font("Segoe UI", 9f),
                ForeColor = ThemeColors.TextMuted,
                Location = new Point(25, 300),
                Size = new Size(460, 95)
            };

            var btnClose = new Button
            {
                Text = "Закрыть",
                DialogResult = DialogResult.OK,
                Size = new Size(110, 36),
                Location = new Point(375, 400),
                BackColor = ThemeColors.Primary,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9.5f, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnClose.FlatAppearance.BorderSize = 0;

            this.Controls.Add(lblTeamHeader);
            this.Controls.Add(lblTeam);
            this.Controls.Add(lblTechHeader);
            this.Controls.Add(lblTech);
            this.Controls.Add(btnClose);
            this.AcceptButton = btnClose;
        }
    }
}
