using System;
using System.Drawing;
using System.Windows.Forms;
using WarehouseAccounting.Core.Services;
using WarehouseAccounting.WinForms.UI;

namespace WarehouseAccounting.WinForms.Forms
{
    public class ReportsForm : Form
    {
        private readonly IReportService _reportService;

        private TabControl _tabControl = null!;
        private DataGridView _gridStock = null!;
        private DataGridView _gridDeficit = null!;
        private DataGridView _gridTurnover = null!;

        private DateTimePicker _dtpTurnoverFrom = null!;
        private DateTimePicker _dtpTurnoverTo = null!;
        private Label _lblStockSummary = null!;
        private Label _lblDeficitSummary = null!;

        public ReportsForm(IReportService reportService)
        {
            _reportService = reportService;
            InitializeComponent();
            LoadStockReport();
            LoadDeficitReport();
            LoadTurnoverReport();
        }

        private void InitializeComponent()
        {
            this.Text = "Аналитические отчеты и складская ведомость";
            this.Size = new Size(1100, 700);
            this.StartPosition = FormStartPosition.CenterParent;
            this.BackColor = ThemeColors.Background;
            this.Font = new Font("Segoe UI", 9.5f);

            var pnlHeader = new Panel
            {
                Dock = DockStyle.Top,
                Height = 60,
                BackColor = ThemeColors.DarkHeader,
                Padding = new Padding(20, 15, 20, 15)
            };

            var lblTitle = new Label
            {
                Text = "Аналитика склада и формирование ведомостей",
                Font = new Font("Segoe UI", 12f, FontStyle.Bold),
                ForeColor = Color.White,
                AutoSize = true,
                Location = new Point(20, 16)
            };
            pnlHeader.Controls.Add(lblTitle);
            this.Controls.Add(pnlHeader);

            _tabControl = new TabControl
            {
                Dock = DockStyle.Fill,
                Font = new Font("Segoe UI", 9.5f)
            };

            // Вкладка 1: Остатки
            var tabStock = new TabPage("📦 Остатки на складе");
            BuildStockTab(tabStock);
            _tabControl.TabPages.Add(tabStock);

            // Вкладка 2: Дефицит
            var tabDeficit = new TabPage("⚠ Ведомость дефицита (к заказу)");
            BuildDeficitTab(tabDeficit);
            _tabControl.TabPages.Add(tabDeficit);

            // Вкладка 3: Обороты
            var tabTurnover = new TabPage("📊 Движение товаров (обороты)");
            BuildTurnoverTab(tabTurnover);
            _tabControl.TabPages.Add(tabTurnover);

            this.Controls.Add(_tabControl);
        }

        private void BuildStockTab(TabPage tab)
        {
            var pnlTop = new Panel { Dock = DockStyle.Top, Height = 45, BackColor = Color.White, Padding = new Padding(15, 8, 15, 8) };
            _lblStockSummary = new Label { Dock = DockStyle.Left, AutoSize = true, Font = new Font("Segoe UI", 9.5f, FontStyle.Bold), ForeColor = ThemeColors.TextDark, Location = new Point(15, 12) };
            
            var btnExport = new Button
            {
                Text = "📄 Экспорт CSV",
                Dock = DockStyle.Right,
                Width = 130,
                BackColor = ThemeColors.Primary,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnExport.FlatAppearance.BorderSize = 0;
            btnExport.Click += (s, e) => ExportStockCsv();

            pnlTop.Controls.Add(_lblStockSummary);
            pnlTop.Controls.Add(btnExport);
            tab.Controls.Add(pnlTop);

            _gridStock = CreateStyledGrid();
            _gridStock.Columns.Add("Sku", "Артикул");
            _gridStock.Columns.Add("Name", "Наименование товара");
            _gridStock.Columns.Add("Category", "Категория");
            _gridStock.Columns.Add("Quantity", "Остаток");
            _gridStock.Columns.Add("Unit", "Ед.");
            _gridStock.Columns.Add("PurchasePrice", "Цена закупки (руб)");
            _gridStock.Columns.Add("TotalValue", "Сумма оценки (руб)");
            _gridStock.Columns.Add("MinQuantity", "Мин. запас");
            _gridStock.Columns.Add("Location", "Место");
            _gridStock.Columns.Add("Status", "Статус");

            tab.Controls.Add(_gridStock);
        }

        private void BuildDeficitTab(TabPage tab)
        {
            var pnlTop = new Panel { Dock = DockStyle.Top, Height = 45, BackColor = Color.White, Padding = new Padding(15, 8, 15, 8) };
            _lblDeficitSummary = new Label { Dock = DockStyle.Left, AutoSize = true, Font = new Font("Segoe UI", 9.5f, FontStyle.Bold), ForeColor = ThemeColors.Danger, Location = new Point(15, 12) };

            var btnExport = new Button
            {
                Text = "📄 Экспорт CSV",
                Dock = DockStyle.Right,
                Width = 130,
                BackColor = ThemeColors.Primary,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnExport.FlatAppearance.BorderSize = 0;
            btnExport.Click += (s, e) => ExportDeficitCsv();

            pnlTop.Controls.Add(_lblDeficitSummary);
            pnlTop.Controls.Add(btnExport);
            tab.Controls.Add(pnlTop);

            _gridDeficit = CreateStyledGrid();
            _gridDeficit.Columns.Add("Sku", "Артикул");
            _gridDeficit.Columns.Add("Name", "Наименование товара");
            _gridDeficit.Columns.Add("Category", "Категория");
            _gridDeficit.Columns.Add("CurrentStock", "Текущий остаток");
            _gridDeficit.Columns.Add("MinStock", "Неснижаемый минимум");
            _gridDeficit.Columns.Add("Deficit", "Нехватка");
            _gridDeficit.Columns.Add("Recommended", "Рекомендуемый заказ");
            _gridDeficit.Columns.Add("EstCost", "Ориентировочная сумма (руб)");

            tab.Controls.Add(_gridDeficit);
        }

        private void BuildTurnoverTab(TabPage tab)
        {
            var pnlTop = new Panel { Dock = DockStyle.Top, Height = 50, BackColor = Color.White, Padding = new Padding(15, 10, 15, 10) };
            var lblFrom = new Label { Text = "Период с:", Location = new Point(15, 14), AutoSize = true };
            _dtpTurnoverFrom = new DateTimePicker { Location = new Point(85, 12), Size = new Size(115, 25), Format = DateTimePickerFormat.Short, Value = DateTime.Today.AddDays(-30) };
            var lblTo = new Label { Text = "по:", Location = new Point(210, 14), AutoSize = true };
            _dtpTurnoverTo = new DateTimePicker { Location = new Point(235, 12), Size = new Size(115, 25), Format = DateTimePickerFormat.Short, Value = DateTime.Today.AddDays(1) };

            var btnApply = new Button { Text = "Сформировать", Location = new Point(365, 10), Size = new Size(130, 29), BackColor = ThemeColors.DarkHeader, ForeColor = Color.White, FlatStyle = FlatStyle.Flat };
            btnApply.Click += (s, e) => LoadTurnoverReport();

            var btnExport = new Button
            {
                Text = "📄 Экспорт CSV",
                Dock = DockStyle.Right,
                Width = 130,
                BackColor = ThemeColors.Primary,
                ForeColor = Color.White,
                FlatStyle = FlatStyle.Flat,
                Font = new Font("Segoe UI", 9f, FontStyle.Bold),
                Cursor = Cursors.Hand
            };
            btnExport.FlatAppearance.BorderSize = 0;
            btnExport.Click += (s, e) => ExportTurnoverCsv();

            pnlTop.Controls.Add(lblFrom);
            pnlTop.Controls.Add(_dtpTurnoverFrom);
            pnlTop.Controls.Add(lblTo);
            pnlTop.Controls.Add(_dtpTurnoverTo);
            pnlTop.Controls.Add(btnApply);
            pnlTop.Controls.Add(btnExport);
            tab.Controls.Add(pnlTop);

            _gridTurnover = CreateStyledGrid();
            _gridTurnover.Columns.Add("Sku", "Артикул");
            _gridTurnover.Columns.Add("Name", "Наименование товара");
            _gridTurnover.Columns.Add("ReceivedQty", "Приход (кол-во)");
            _gridTurnover.Columns.Add("ReceivedAmount", "Приход (сумма руб)");
            _gridTurnover.Columns.Add("ShippedQty", "Расход (кол-во)");
            _gridTurnover.Columns.Add("ShippedAmount", "Расход (сумма руб)");
            _gridTurnover.Columns.Add("WrittenOffQty", "Списано (кол-во)");
            _gridTurnover.Columns.Add("CurrentStock", "Текущий остаток");

            tab.Controls.Add(_gridTurnover);
        }

        private DataGridView CreateStyledGrid()
        {
            var grid = new DataGridView
            {
                Dock = DockStyle.Fill,
                BackgroundColor = Color.White,
                BorderStyle = BorderStyle.None,
                RowHeadersVisible = false,
                AllowUserToAddRows = false,
                AllowUserToDeleteRows = false,
                ReadOnly = true,
                SelectionMode = DataGridViewSelectionMode.FullRowSelect,
                MultiSelect = false,
                AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill,
                EnableHeadersVisualStyles = false
            };
            grid.ColumnHeadersDefaultCellStyle.BackColor = ThemeColors.GridHeaderBg;
            grid.ColumnHeadersDefaultCellStyle.Font = new Font("Segoe UI", 9.5f, FontStyle.Bold);
            grid.ColumnHeadersDefaultCellStyle.ForeColor = ThemeColors.TextDark;
            grid.ColumnHeadersHeight = 36;
            grid.RowTemplate.Height = 28;
            return grid;
        }

        private void LoadStockReport()
        {
            var rows = _reportService.GenerateStockBalanceReport();
            _gridStock.Rows.Clear();

            decimal totalSum = 0;
            decimal totalQty = 0;

            foreach (var r in rows)
            {
                int idx = _gridStock.Rows.Add(r.Sku, r.Name, r.Category, r.Quantity.ToString("G29"), r.Unit, r.PurchasePrice.ToString("N2"), r.TotalValue.ToString("N2"), r.MinQuantity.ToString("G29"), r.Location, r.Status);
                var gridRow = _gridStock.Rows[idx];

                if (r.Status == "ДЕФИЦИТ")
                {
                    gridRow.DefaultCellStyle.BackColor = ThemeColors.DeficitRowBg;
                    gridRow.DefaultCellStyle.ForeColor = ThemeColors.DeficitRowText;
                }

                totalSum += r.TotalValue;
                totalQty += r.Quantity;
            }

            _lblStockSummary.Text = $"Всего позиций: {rows.Count} | Общее количество: {totalQty:G29} | Общая складская стоимость: {totalSum:N2} руб.";
        }

        private void LoadDeficitReport()
        {
            var rows = _reportService.GenerateDeficitReport();
            _gridDeficit.Rows.Clear();

            decimal estTotal = 0;
            foreach (var r in rows)
            {
                int idx = _gridDeficit.Rows.Add(r.Sku, r.Name, r.Category, r.CurrentStock.ToString("G29"), r.MinStock.ToString("G29"), r.DeficitQuantity.ToString("G29"), r.RecommendedOrderQuantity.ToString("G29"), r.EstimatedCostRub.ToString("N2"));
                _gridDeficit.Rows[idx].DefaultCellStyle.BackColor = ThemeColors.DeficitRowBg;
                _gridDeficit.Rows[idx].DefaultCellStyle.ForeColor = ThemeColors.DeficitRowText;

                estTotal += r.EstimatedCostRub;
            }

            _lblDeficitSummary.Text = $"Товаров ниже минимального остатка: {rows.Count} поз. | Требуемый бюджет на пополнение: {estTotal:N2} руб.";
        }

        private void LoadTurnoverReport()
        {
            var rows = _reportService.GenerateTurnoverReport(_dtpTurnoverFrom.Value, _dtpTurnoverTo.Value);
            _gridTurnover.Rows.Clear();

            foreach (var r in rows)
            {
                _gridTurnover.Rows.Add(r.Sku, r.Name, r.ReceivedQty.ToString("G29"), r.ReceivedAmount.ToString("N2"), r.ShippedQty.ToString("G29"), r.ShippedAmount.ToString("N2"), r.WrittenOffQty.ToString("G29"), r.CurrentStock.ToString("G29"));
            }
        }

        private void ExportStockCsv()
        {
            using var sfd = new SaveFileDialog { Filter = "CSV файлы (*.csv)|*.csv", FileName = "stock_balance.csv" };
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                _reportService.ExportStockBalanceCsv(sfd.FileName);
                MessageBox.Show("Ведомость остатков экспортирована!", "Экспорт", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void ExportDeficitCsv()
        {
            using var sfd = new SaveFileDialog { Filter = "CSV файлы (*.csv)|*.csv", FileName = "deficit_report.csv" };
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                _reportService.ExportDeficitCsv(sfd.FileName);
                MessageBox.Show("Ведомость дефицита экспортирована!", "Экспорт", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void ExportTurnoverCsv()
        {
            using var sfd = new SaveFileDialog { Filter = "CSV файлы (*.csv)|*.csv", FileName = "turnover_report.csv" };
            if (sfd.ShowDialog() == DialogResult.OK)
            {
                _reportService.ExportTurnoverCsv(sfd.FileName, _dtpTurnoverFrom.Value, _dtpTurnoverTo.Value);
                MessageBox.Show("Движение товаров экспортировано!", "Экспорт", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
