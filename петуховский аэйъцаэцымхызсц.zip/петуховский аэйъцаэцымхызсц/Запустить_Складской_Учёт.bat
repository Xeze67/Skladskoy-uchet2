@echo off
chcp 65001 > nul
title Складской учёт (мини-версия)
cd /d "%~dp0"
echo ====================================================
echo   Запуск приложения "Складской учёт (мини-версия)"
echo   Тема № 9 • Разработчики: Ложкин, Барышев, Рейтер
echo ====================================================
echo.
start "" "%~dp0src\WarehouseAccounting.WinForms\bin\Debug\net9.0-windows\WarehouseAccounting.WinForms.exe"
